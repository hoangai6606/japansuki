export interface SessionManager {
  getSessionId(): string;
  setSessionId(id: string): void;
}

export class LocalSessionManager implements SessionManager {
  private readonly SESSION_KEY = 'japansuki_session_id';

  getSessionId(): string {
    let sessionId = localStorage.getItem(this.SESSION_KEY);
    if (!sessionId) {
      sessionId = `guest_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      this.setSessionId(sessionId);
    }
    return sessionId;
  }

  setSessionId(id: string): void {
    localStorage.setItem(this.SESSION_KEY, id);
  }
}

export const sessionManager = new LocalSessionManager();

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  suggestions?: string[];
}

export interface Product {
  id: number;
  name: string;
  slug: string;
  description?: string;
  shortDescription?: string;
  price: string;
  originalPrice?: string;
  stock: number;
  categoryId: number;
  brand?: string;
  weight?: string;
  origin?: string;
  imageUrl?: string;
  images?: string[];
  isFeatured?: boolean;
  isHot?: boolean;
  soldCount?: number;
  createdAt: Date;
}

export interface Category {
  id: number;
  name: string;
  slug: string;
  description?: string;
  icon?: string;
  imageUrl?: string;
  parentId?: number;
}

export interface CartItem {
  id: number;
  productId: number;
  quantity: number;
  product: Product;
}

export interface WishlistItem {
  id: number;
  productId: number;
  product: Product;
}
