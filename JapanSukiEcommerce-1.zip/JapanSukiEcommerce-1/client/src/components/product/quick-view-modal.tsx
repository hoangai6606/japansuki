import { useState } from 'react';
import { X, Plus, Minus, ShoppingCart, Heart } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useCart } from '@/hooks/use-cart';
import { useWishlist } from '@/hooks/use-wishlist';
import { useToast } from '@/hooks/use-toast';
import type { Product } from '@/lib/types';

interface QuickViewModalProps {
  product: Product;
  isOpen: boolean;
  onClose: () => void;
}

export default function QuickViewModal({ product, isOpen, onClose }: QuickViewModalProps) {
  const [quantity, setQuantity] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const { addItem } = useCart();
  const { toggleItem, isInWishlist } = useWishlist();
  const { toast } = useToast();

  const handleAddToCart = async () => {
    try {
      setIsLoading(true);
      await addItem(product.id, quantity);
      toast({
        title: "Đã thêm vào giỏ hàng",
        description: `${quantity} x ${product.name} đã được thêm vào giỏ hàng của bạn.`,
      });
      onClose();
    } catch (error) {
      toast({
        title: "Lỗi",
        description: "Không thể thêm sản phẩm vào giỏ hàng. Vui lòng thử lại.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleToggleWishlist = async () => {
    try {
      await toggleItem(product.id);
      toast({
        title: isInWishlist(product.id) ? "Đã xóa khỏi yêu thích" : "Đã thêm vào yêu thích",
        description: `${product.name} ${isInWishlist(product.id) ? 'đã được xóa khỏi' : 'đã được thêm vào'} danh sách yêu thích.`,
      });
    } catch (error) {
      toast({
        title: "Lỗi",
        description: "Không thể cập nhật danh sách yêu thích. Vui lòng thử lại.",
        variant: "destructive",
      });
    }
  };

  const formatPrice = (price: string) => {
    return parseInt(price).toLocaleString('vi-VN');
  };

  const incrementQuantity = () => {
    if (quantity < product.stock) {
      setQuantity(prev => prev + 1);
    }
  };

  const decrementQuantity = () => {
    if (quantity > 1) {
      setQuantity(prev => prev - 1);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-6">
          <DialogTitle className="text-2xl font-bold text-gray-800">
            Xem nhanh sản phẩm
          </DialogTitle>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <X className="w-5 h-5" />
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Product Image */}
          <div>
            <img
              src={product.imageUrl || 'https://via.placeholder.com/600x500'}
              alt={product.name}
              className="w-full rounded-lg"
            />
          </div>

          {/* Product Info */}
          <div>
            <h4 className="text-xl font-semibold text-gray-800 mb-4">
              {product.name}
            </h4>

            <div className="flex items-center space-x-4 mb-4">
              <div className="flex items-center space-x-2">
                <span className="text-3xl font-bold text-cherry">
                  {formatPrice(product.price)}₫
                </span>
                {product.originalPrice && (
                  <span className="text-lg text-gray-500 line-through">
                    {formatPrice(product.originalPrice)}₫
                  </span>
                )}
              </div>
              <span className={`font-medium ${
                product.stock > 0 ? 'text-green-600' : 'text-red-600'
              }`}>
                {product.stock > 0 ? 'Còn hàng' : 'Hết hàng'}
              </span>
            </div>

            <div className="space-y-4 mb-6">
              {product.description && (
                <div>
                  <h5 className="font-semibold text-gray-700 mb-2">Mô tả sản phẩm:</h5>
                  <p className="text-gray-600 text-sm leading-relaxed">
                    {product.description}
                  </p>
                </div>
              )}

              <div>
                <h5 className="font-semibold text-gray-700 mb-2">Thông tin chi tiết:</h5>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Xuất xứ: {product.origin || 'Nhật Bản'}</li>
                  {product.weight && <li>• Trọng lượng: {product.weight}</li>}
                  {product.brand && <li>• Thương hiệu: {product.brand}</li>}
                  <li>• Tình trạng: {product.stock > 0 ? `Còn ${product.stock} sản phẩm` : 'Hết hàng'}</li>
                </ul>
              </div>

              {/* Badges */}
              <div className="flex flex-wrap gap-2">
                {product.isFeatured && (
                  <Badge variant="secondary">Nổi bật</Badge>
                )}
                {product.isHot && (
                  <Badge variant="destructive">Hot</Badge>
                )}
                {product.soldCount && product.soldCount > 0 && (
                  <Badge variant="outline">Đã bán {product.soldCount} sp</Badge>
                )}
              </div>
            </div>

            {/* Quantity Selector */}
            <div className="flex items-center space-x-4 mb-6">
              <span className="text-gray-700">Số lượng:</span>
              <div className="flex items-center border border-gray-300 rounded-lg">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={decrementQuantity}
                  disabled={quantity <= 1}
                  className="px-3 py-1 hover:bg-gray-100"
                >
                  <Minus className="w-4 h-4" />
                </Button>
                <span className="px-4 py-1 border-x border-gray-300 min-w-[3rem] text-center">
                  {quantity}
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={incrementQuantity}
                  disabled={quantity >= product.stock}
                  className="px-3 py-1 hover:bg-gray-100"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex space-x-4">
              <Button
                onClick={handleAddToCart}
                disabled={isLoading || product.stock === 0}
                className="flex-1 cherry-gradient text-white py-3 hover:opacity-90 transition-opacity"
              >
                {isLoading ? (
                  "Đang thêm..."
                ) : (
                  <>
                    <ShoppingCart className="w-4 h-4 mr-2" />
                    Thêm vào giỏ hàng
                  </>
                )}
              </Button>
              <Button
                onClick={handleToggleWishlist}
                variant="outline"
                className="py-3 px-6 border-gray-300 hover:bg-gray-50"
              >
                <Heart className={`w-4 h-4 ${isInWishlist(product.id) ? 'fill-current text-red-500' : ''}`} />
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
