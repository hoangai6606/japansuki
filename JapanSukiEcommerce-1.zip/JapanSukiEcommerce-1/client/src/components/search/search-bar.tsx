import { useState, useEffect, useRef } from 'react';
import { Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';

interface SearchSuggestion {
  id: number;
  name: string;
  price: string;
  imageUrl?: string;
}

export default function SearchBar() {
  const [query, setQuery] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [, setLocation] = useLocation();
  const searchRef = useRef<HTMLDivElement>(null);

  const { data: suggestions = [] } = useQuery({
    queryKey: ['/api/search/suggestions', query],
    queryFn: async () => {
      if (query.length < 2) return [];
      const response = await fetch(`/api/search/suggestions?q=${encodeURIComponent(query)}`);
      if (!response.ok) throw new Error('Failed to fetch suggestions');
      return response.json();
    },
    enabled: query.length >= 2
  });

  const handleSearch = (searchQuery: string = query) => {
    if (searchQuery.trim()) {
      setLocation(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
      setShowSuggestions(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  const handleSuggestionClick = (suggestion: SearchSuggestion) => {
    setQuery(suggestion.name);
    handleSearch(suggestion.name);
  };

  // Close suggestions when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div ref={searchRef} className="relative w-full">
      <div className="relative">
        <Input
          type="text"
          placeholder="Vui lòng nhập từ khóa vào ô tìm kiếm"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setShowSuggestions(true);
          }}
          onKeyPress={handleKeyPress}
          className="w-full pr-12 border-2 border-pink-200 focus:border-white rounded-full text-gray-700"
        />
        <Button
          onClick={() => handleSearch()}
          className="absolute right-1 top-1/2 transform -translate-y-1/2 cherry-gradient text-white px-4 py-1 rounded-full hover:opacity-90 transition-opacity"
          size="sm"
        >
          <Search className="w-4 h-4" />
        </Button>
      </div>

      {/* Search Suggestions */}
      {showSuggestions && suggestions.length > 0 && (
        <div className="absolute top-full left-0 right-0 bg-white border border-gray-200 rounded-lg shadow-lg mt-1 z-50 max-h-80 overflow-y-auto">
          {suggestions.map((suggestion: SearchSuggestion) => (
            <button
              key={suggestion.id}
              onClick={() => handleSuggestionClick(suggestion)}
              className="w-full flex items-center space-x-3 p-3 hover:bg-gray-50 transition-colors text-left"
            >
              {suggestion.imageUrl && (
                <img
                  src={suggestion.imageUrl}
                  alt={suggestion.name}
                  className="w-10 h-10 object-cover rounded"
                />
              )}
              <div className="flex-1">
                <div className="font-medium text-gray-900 text-sm">{suggestion.name}</div>
                <div className="text-cherry font-semibold text-sm">{parseInt(suggestion.price).toLocaleString('vi-VN')}₫</div>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
