import { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { Phone, Heart, ShoppingCart, Menu, X, User, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import SearchBar from '@/components/search/search-bar';
import CartSidebar from '@/components/cart/cart-sidebar';
import { useCart } from '@/hooks/use-cart';
import { useWishlist } from '@/hooks/use-wishlist';
import { useToast } from '@/hooks/use-toast';

const navigation = [
  { name: 'THỰC PHẨM', href: '/category/thuc-pham', icon: '🍱' },
  { name: 'MỸ PHẨM', href: '/category/my-pham', icon: '💄' },
  { name: 'GIẶT GIŨ VỆ SINH', href: '/category/giat-giu-ve-sinh', icon: '🧽' },
  { name: 'NHÀ BẾP', href: '/category/nha-bep', icon: '🍳' },
  { name: 'MẸ & BÉ', href: '/category/me-be', icon: '👶' },
];

export default function Header() {
  const [location, setLocation] = useLocation();
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [user, setUser] = useState(null);
  const { itemCount } = useCart();
  const { itemCount: wishlistCount } = useWishlist();
  const { toast } = useToast();

  // Check user authentication status
  useEffect(() => {
    const userToken = localStorage.getItem('userToken');
    const userData = localStorage.getItem('user');
    if (userToken && userData) {
      setUser(JSON.parse(userData));
    }
  }, [location]);

  const handleLogout = () => {
    localStorage.removeItem('userToken');
    localStorage.removeItem('user');
    setUser(null);
    toast({
      title: "Đăng xuất thành công",
      description: "Hẹn gặp lại bạn!",
    });
    setLocation('/');
  };

  return (
    <header className="bg-cherry shadow-lg relative">
      {/* Top Bar */}
      <div className="bg-pink-100 py-2">
        <div className="container mx-auto px-4 flex justify-between items-center text-sm">
          <div className="text-gray-700">
            <span>Chào mừng bạn đến với hàng Nhật nội địa JAPAN SUKI</span>
          </div>
          <div className="hidden md:flex space-x-4 text-gray-700">
            <Link href="/store" className="hover:text-cherry transition-colors">Cửa Hàng</Link>
            <span>|</span>
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger className="hover:text-cherry transition-colors flex items-center">
                  <User className="w-4 h-4 mr-1" />
                  Xin chào, {user.firstName || user.email}
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem asChild>
                    <Link href="/account" className="w-full">Tài khoản của tôi</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="w-4 h-4 mr-2" />
                    Đăng xuất
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <>
                <Link href="/register" className="hover:text-cherry transition-colors">Đăng ký</Link>
                <span>|</span>
                <Link href="/login" className="hover:text-cherry transition-colors">Đăng nhập</Link>
              </>
            )}
          </div>
        </div>
      </div>
      {/* Main Header */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center font-bold text-2xl text-[#ff7a98]">
            <span className="mr-2">🌸</span>
            JapanSuki
          </Link>

          {/* Search Bar - Desktop */}
          <div className="hidden md:block flex-1 max-w-2xl mx-8">
            <SearchBar />
          </div>

          {/* Header Actions */}
          <div className="flex items-center space-x-6 text-[#000000]">
            {/* Hotline */}
            <div className="hidden lg:flex items-center">
              <Phone className="w-5 h-5 mr-2" />
              <div>
                <div className="text-sm">Hotline</div>
                <div className="font-semibold">0384.323.829</div>
              </div>
            </div>

            {/* Wishlist */}
            <Link href="/wishlist" className="flex flex-col items-center hover:text-pink-200 transition-colors relative">
              <Heart className="w-6 h-6" />
              <span className="text-xs mt-1 hidden sm:block">Yêu thích</span>
              {wishlistCount > 0 && (
                <Badge variant="destructive" className="absolute -top-2 -right-2 w-5 h-5 flex items-center justify-center p-0 text-xs">
                  {wishlistCount}
                </Badge>
              )}
            </Link>

            {/* Cart */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="flex flex-col items-center hover:text-pink-200 transition-colors relative"
            >
              <ShoppingCart className="w-6 h-6" />
              <span className="text-xs mt-1 hidden sm:block">Giỏ hàng</span>
              {itemCount > 0 && (
                <Badge variant="secondary" className="absolute -top-2 -right-2 w-5 h-5 flex items-center justify-center p-0 text-xs bg-yellow-400 text-cherry">
                  {itemCount}
                </Badge>
              )}
            </button>

            {/* Mobile Menu */}
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden text-white">
                  <Menu className="w-6 h-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px]">
                <div className="flex flex-col space-y-4 mt-6">
                  <SearchBar />
                  <div className="space-y-2">
                    {navigation.map((item) => (
                      <Link
                        key={item.name}
                        href={item.href}
                        className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-100 transition-colors"
                      >
                        <span className="text-xl">{item.icon}</span>
                        <span className="font-medium">{item.name}</span>
                      </Link>
                    ))}
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>

        {/* Mobile Search */}
        <div className="md:hidden mt-4">
          <SearchBar />
        </div>
      </div>
      {/* Navigation Menu */}
      <nav className="bg-white border-t border-pink-200 shadow-sm">
        <div className="container mx-auto px-4">
          <ul className="hidden md:flex space-x-8 py-4">
            {navigation.map((item) => (
              <li key={item.name}>
                <Link
                  href={item.href}
                  className={`flex items-center text-gray-700 hover:text-cherry font-medium transition-colors ${
                    location === item.href ? 'text-cherry' : ''
                  }`}
                >
                  <span className="mr-2">{item.icon}</span>
                  {item.name}
                </Link>
              </li>
            ))}
            <li>
              <Link
                href="/contact"
                className="flex items-center text-gray-700 hover:text-cherry font-medium transition-colors"
              >
                <Phone className="w-4 h-4 mr-2 text-cherry" />
                LIÊN HỆ
              </Link>
            </li>
          </ul>
        </div>
      </nav>
      {/* Cart Sidebar */}
      <CartSidebar isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
    </header>
  );
}
