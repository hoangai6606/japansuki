import { Link } from 'wouter';
import { ArrowLeft, Shield, Clock, CheckCircle, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function WarrantyPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-cherry text-white py-12">
        <div className="container mx-auto px-4">
          <Link href="/">
            <Button variant="ghost" className="text-white mb-4 hover:bg-white/10">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Về trang chủ
            </Button>
          </Link>
          <h1 className="text-4xl font-bold mb-4">Chính sách bảo hành</h1>
          <p className="text-xl text-pink-100">
            Cam kết bảo hành chất lượng sản phẩm từ JapanSuki
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        {/* Overview */}
        <section className="mb-12">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-2xl">
                <Shield className="w-6 h-6 mr-2 text-cherry" />
                Cam kết bảo hành
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 leading-relaxed">
                JapanSuki cam kết bảo hành chất lượng cho tất cả sản phẩm được bán tại cửa hàng. 
                Chúng tôi đảm bảo sản phẩm chính hãng, không lỗi từ nhà sản xuất và hỗ trợ 
                khách hàng trong quá trình sử dụng.
              </p>
            </CardContent>
          </Card>
        </section>

        {/* Warranty Terms */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-8">Điều kiện bảo hành</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-green-600">
                  <CheckCircle className="w-5 h-5 mr-2" />
                  Được bảo hành
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-gray-600">
                  <li>• Sản phẩm còn nguyên tem, nhãn mác</li>
                  <li>• Lỗi do nhà sản xuất</li>
                  <li>• Sản phẩm chưa hết hạn sử dụng</li>
                  <li>• Có hóa đơn mua hàng</li>
                  <li>• Trong thời gian bảo hành</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-red-600">
                  <AlertCircle className="w-5 h-5 mr-2" />
                  Không được bảo hành
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-gray-600">
                  <li>• Sản phẩm đã sử dụng hết</li>
                  <li>• Hư hỏng do người dùng</li>
                  <li>• Sản phẩm quá hạn sử dụng</li>
                  <li>• Không có hóa đơn</li>
                  <li>• Quá thời gian bảo hành</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Warranty Period */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-8">Thời gian bảo hành</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardContent className="p-6 text-center">
                <Clock className="w-12 h-12 text-cherry mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">Thực phẩm</h3>
                <p className="text-gray-600">7 ngày từ ngày mua</p>
                <p className="text-sm text-gray-500 mt-2">
                  Áp dụng cho sản phẩm còn nguyên seal
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <Clock className="w-12 h-12 text-cherry mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">Mỹ phẩm</h3>
                <p className="text-gray-600">30 ngày từ ngày mua</p>
                <p className="text-sm text-gray-500 mt-2">
                  Sản phẩm chưa bóc seal
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <Clock className="w-12 h-12 text-cherry mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">Đồ gia dụng</h3>
                <p className="text-gray-600">90 ngày từ ngày mua</p>
                <p className="text-sm text-gray-500 mt-2">
                  Lỗi kỹ thuật từ nhà sản xuất
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Warranty Process */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-8">Quy trình bảo hành</h2>
          <Card>
            <CardContent className="p-8">
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="bg-cherry text-white rounded-full w-8 h-8 flex items-center justify-center font-bold mr-4 mt-1">1</div>
                  <div>
                    <h3 className="font-semibold mb-2">Liên hệ bảo hành</h3>
                    <p className="text-gray-600">Gọi hotline 0384.323.829 hoặc email info@japansuki.vn</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-cherry text-white rounded-full w-8 h-8 flex items-center justify-center font-bold mr-4 mt-1">2</div>
                  <div>
                    <h3 className="font-semibold mb-2">Cung cấp thông tin</h3>
                    <p className="text-gray-600">Gửi hình ảnh sản phẩm, hóa đơn và mô tả vấn đề</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-cherry text-white rounded-full w-8 h-8 flex items-center justify-center font-bold mr-4 mt-1">3</div>
                  <div>
                    <h3 className="font-semibold mb-2">Xác nhận bảo hành</h3>
                    <p className="text-gray-600">Nhân viên xác nhận điều kiện và hướng dẫn gửi hàng</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-cherry text-white rounded-full w-8 h-8 flex items-center justify-center font-bold mr-4 mt-1">4</div>
                  <div>
                    <h3 className="font-semibold mb-2">Xử lý bảo hành</h3>
                    <p className="text-gray-600">Đổi mới hoặc hoàn tiền trong vòng 3-7 ngày làm việc</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Contact */}
        <section>
          <Card className="bg-cherry-gradient text-white">
            <CardContent className="p-8 text-center">
              <h2 className="text-2xl font-bold mb-4">Cần hỗ trợ bảo hành?</h2>
              <p className="mb-6">Liên hệ ngay với chúng tôi để được tư vấn</p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button className="bg-white text-cherry hover:bg-gray-100">
                  Gọi: 0384.323.829
                </Button>
                <Button variant="outline" className="border-white text-white hover:bg-white/10">
                  Email: info@japansuki.vn
                </Button>
              </div>
            </CardContent>
          </Card>
        </section>
      </div>
    </div>
  );
}