import { Link } from 'wouter';
import { ArrowLeft, MapPin, Phone, Mail, Users, Award, Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-cherry text-white py-12">
        <div className="container mx-auto px-4">
          <Link href="/">
            <Button variant="ghost" className="text-white mb-4 hover:bg-white/10">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Về trang chủ
            </Button>
          </Link>
          <h1 className="text-4xl font-bold mb-4 text-black">Về chúng tôi</h1>
          <p className="text-xl text-black">
            JapanSuki - Hàng Nhật nội địa chính hãng, chất lượng cao
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        {/* Company Story */}
        <section className="mb-16">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-gray-800 mb-8 text-center">Câu chuyện của chúng tôi</h2>
            <div className="prose prose-lg max-w-none text-gray-600">
              <p className="mb-6">
                JapanSuki được thành lập với sứ mệnh mang đến cho khách hàng Việt Nam những sản phẩm 
                chính hãng từ Nhật Bản với chất lượng tốt nhất và giá cả hợp lý. Chúng tôi hiểu rằng 
                sản phẩm Nhật Bản luôn được đánh giá cao về chất lượng, độ bền và tính thẩm mỹ.
              </p>
              <p className="mb-6">
                Với hơn 5 năm kinh nghiệm trong việc nhập khẩu và phân phối hàng Nhật Bản, 
                JapanSuki đã xây dựng được mạng lưới đối tác tin cậy tại Nhật Bản để đảm bảo 
                nguồn hàng chính hãng, đa dạng từ thực phẩm, mỹ phẩm đến đồ gia dụng.
              </p>
              <p>
                Chúng tôi cam kết mang đến trải nghiệm mua sắm tuyệt vời với dịch vụ chăm sóc 
                khách hàng chu đáo và chính sách bảo hành đáng tin cậy.
              </p>
            </div>
          </div>
        </section>

        {/* Values */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-gray-800 mb-12 text-center">Giá trị cốt lõi</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="text-center">
              <CardContent className="p-8">
                <Award className="w-12 h-12 text-cherry mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-4">Chất lượng</h3>
                <p className="text-gray-600">
                  Cam kết 100% hàng chính hãng từ Nhật Bản với chất lượng được kiểm định nghiêm ngặt
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="p-8">
                <Users className="w-12 h-12 text-cherry mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-4">Dịch vụ</h3>
                <p className="text-gray-600">
                  Đội ngũ tư vấn chuyên nghiệp, nhiệt tình hỗ trợ khách hàng 24/7
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="p-8">
                <Heart className="w-12 h-12 text-cherry mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-4">Tin cậy</h3>
                <p className="text-gray-600">
                  Xây dựng niềm tin với khách hàng qua từng sản phẩm và dịch vụ
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Contact Information */}
        <section className="bg-white rounded-xl p-8 shadow-sm">
          <h2 className="text-3xl font-bold text-gray-800 mb-8 text-center">Thông tin liên hệ</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <MapPin className="w-8 h-8 text-cherry mx-auto mb-4" />
              <h3 className="font-semibold mb-2">Địa chỉ</h3>
              <p className="text-gray-600">123 Đường ABC, Quận 1, TP.HCM</p>
            </div>

            <div className="text-center">
              <Phone className="w-8 h-8 text-cherry mx-auto mb-4" />
              <h3 className="font-semibold mb-2">Hotline</h3>
              <p className="text-gray-600">0384.323.829</p>
            </div>

            <div className="text-center">
              <Mail className="w-8 h-8 text-cherry mx-auto mb-4" />
              <h3 className="font-semibold mb-2">Email</h3>
              <p className="text-gray-600">info@japansuki.vn</p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}