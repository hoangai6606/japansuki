
import { Link, useLocation } from 'wouter';
import { XCircle, ArrowLeft, RefreshCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';

export default function PaymentFailedPage() {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(location.split('?')[1] || '');
  const orderId = searchParams.get('orderId');
  const status = searchParams.get('status');

  const getErrorMessage = () => {
    switch (status) {
      case 'failed':
        return 'Thanh toán đã bị hủy hoặc không thành công.';
      case 'invalid':
        return 'Thông tin thanh toán không hợp lệ.';
      case 'error':
        return 'Có lỗi xảy ra trong quá trình thanh toán.';
      default:
        return 'Thanh toán không thành công.';
    }
  };

  return (
    <>
      <Header />
      <div className="min-h-screen bg-gray-50">
        <main className="container mx-auto px-4 py-16">
          <div className="max-w-md mx-auto">
            <Card>
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <XCircle className="w-8 h-8 text-red-600" />
                </div>
                <CardTitle className="text-2xl text-red-600">
                  Thanh toán thất bại
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center space-y-4">
                <p className="text-gray-600">
                  {getErrorMessage()}
                </p>
                {orderId && (
                  <p className="text-sm text-gray-500">
                    Đơn hàng #{orderId}
                  </p>
                )}
                <p className="text-sm text-gray-500">
                  Vui lòng thử lại hoặc liên hệ với chúng tôi để được hỗ trợ.
                </p>
                <div className="space-y-2 pt-4">
                  <Link href="/cart">
                    <Button className="w-full bg-cherry">
                      <RefreshCcw className="w-4 h-4 mr-2" />
                      Thử lại
                    </Button>
                  </Link>
                  <Link href="/">
                    <Button variant="outline" className="w-full">
                      <ArrowLeft className="w-4 h-4 mr-2" />
                      Về trang chủ
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
      <Footer />
    </>
  );
}
