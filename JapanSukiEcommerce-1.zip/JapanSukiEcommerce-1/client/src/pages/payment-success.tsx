
import { useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { CheckCircle, ArrowLeft, Package } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';

export default function PaymentSuccessPage() {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(location.split('?')[1] || '');
  const orderId = searchParams.get('orderId');
  const status = searchParams.get('status');

  useEffect(() => {
    // Clear cart from localStorage if payment successful
    if (status === 'success') {
      localStorage.removeItem('cart');
    }
  }, [status]);

  return (
    <>
      <Header />
      <div className="min-h-screen bg-gray-50">
        <main className="container mx-auto px-4 py-16">
          <div className="max-w-md mx-auto">
            <Card>
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="w-8 h-8 text-green-600" />
                </div>
                <CardTitle className="text-2xl text-green-600">
                  Thanh toán thành công!
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center space-y-4">
                <p className="text-gray-600">
                  Cảm ơn bạn đã đặt hàng. Đơn hàng #{orderId} của bạn đã được thanh toán thành công.
                </p>
                <p className="text-sm text-gray-500">
                  Chúng tôi sẽ gửi email xác nhận đơn hàng và thông tin vận chuyển cho bạn trong thời gian sớm nhất.
                </p>
                <div className="space-y-2 pt-4">
                  <Link href="/account?tab=orders">
                    <Button className="w-full bg-cherry">
                      <Package className="w-4 h-4 mr-2" />
                      Xem đơn hàng
                    </Button>
                  </Link>
                  <Link href="/">
                    <Button variant="outline" className="w-full">
                      <ArrowLeft className="w-4 h-4 mr-2" />
                      Về trang chủ
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
      <Footer />
    </>
  );
}
