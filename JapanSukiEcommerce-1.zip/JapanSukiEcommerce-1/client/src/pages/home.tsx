import { useState } from 'react';
import { Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Gift, Flame, Zap, ArrowRight, Shield, Truck, RotateCcw, Star, Timer, TrendingUp, Eye, Filter, ShoppingCart, Plus, Award, Heart, Users, Lock, Headphones, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import ProductGrid from '@/components/product/product-grid';
import Chatbot from '@/components/chat/chatbot';
import type { Category, Product } from '@/lib/types';

export default function Home() {
  const [copiedCoupon, setCopiedCoupon] = useState(false);

  // Fetch categories
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  // Fetch hot products
  const { data: hotProducts = [] } = useQuery<Product[]>({
    queryKey: ['/api/products', { hot: 'true' }],
    queryFn: async () => {
      const response = await fetch('/api/products?hot=true&limit=5');
      if (!response.ok) throw new Error('Failed to fetch hot products');
      return response.json();
    }
  });

  // Fetch featured products (toothpaste category)
  const { data: toothpasteProducts = [] } = useQuery<Product[]>({
    queryKey: ['/api/products', { category: 'kem-danh-rang' }],
    queryFn: async () => {
      const response = await fetch('/api/products?category=kem-danh-rang&limit=6');
      if (!response.ok) throw new Error('Failed to fetch toothpaste products');
      return response.json();
    }
  });

  const handleCopyCoupon = () => {
    navigator.clipboard.writeText('GZY1AOLYK2E0').then(() => {
      setCopiedCoupon(true);
      setTimeout(() => setCopiedCoupon(false), 2000);
    });
  };

  const formatPrice = (price: string) => {
    return parseInt(price).toLocaleString('vi-VN');
  };

  return (
    <div className="min-h-screen page-gradient">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <section className="mb-12">
          <div className="bg-gradient-to-br from-white via-pink-50 to-red-50 rounded-3xl p-8 lg:p-12 relative overflow-hidden shadow-xl">
            {/* Background Pattern */}
            <div className="absolute inset-0 opacity-5">
              <div className="absolute top-10 left-10 text-6xl">🌸</div>
              <div className="absolute top-32 right-20 text-4xl">🌸</div>
              <div className="absolute bottom-20 left-1/4 text-5xl">🌸</div>
              <div className="absolute bottom-10 right-10 text-3xl">🌸</div>
            </div>
            
            <div className="relative z-10 grid lg:grid-cols-2 gap-8 items-center">
              {/* Left Content */}
              <div className="space-y-6">
                {/* Main Headline */}
                <div className="space-y-3">
                  <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 leading-tight">
                    Hàng Tạp Hóa Nhật Bản 
                    <span className="text-[#DC143C] block">Chính Hãng</span>
                    <span className="text-[#7FB069] text-3xl lg:text-4xl block">
                      Trực Tiếp Từ Xứ Sở Hoa Anh Đào
                    </span>
                  </h1>
                  <p className="text-lg lg:text-xl text-gray-600 leading-relaxed">
                    Khám phá hương vị đích thực của Nhật Bản với hơn 500+ sản phẩm cao cấp được nhập khẩu trực tiếp
                  </p>
                </div>

                {/* CTA Buttons */}
                <div className="flex flex-col sm:flex-row gap-4">
                  <Link href="/category/thuc-pham">
                    <Button className="bg-[#DC143C] hover:bg-red-700 text-white px-8 py-4 rounded-full font-semibold text-lg shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
                      Khám Phá Ngay
                    </Button>
                  </Link>
                  <Link href="/products">
                    <Button variant="outline" className="border-2 border-[#DC143C] text-[#DC143C] hover:bg-[#DC143C] hover:text-white px-8 py-4 rounded-full font-semibold text-lg transition-all duration-300">
                      Xem Sản Phẩm Hot
                    </Button>
                  </Link>
                </div>

                {/* Quick Categories */}
                <div className="space-y-3">
                  <h3 className="text-sm font-semibold text-gray-700 uppercase tracking-wide">
                    Danh mục phổ biến
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {['Snacks & Kẹo', 'Nước Uống', 'Mì Tôm', 'Gia Vị', 'Thực Phẩm Đông Lạnh'].map((category) => (
                      <Link key={category} href="/category/thuc-pham">
                        <Badge variant="secondary" className="px-4 py-2 text-sm font-medium bg-white hover:bg-gray-100 text-gray-700 border border-gray-200 rounded-full cursor-pointer transition-all hover:shadow-md">
                          {category}
                        </Badge>
                      </Link>
                    ))}
                  </div>
                </div>

                {/* Trust Indicators */}
                <div className="grid grid-cols-3 gap-4 pt-4">
                  <div className="flex items-center gap-2 text-center">
                    <div className="bg-[#7FB069] p-2 rounded-full">
                      <Shield className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-gray-900">100% Chính Hãng</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-center">
                    <div className="bg-[#DC143C] p-2 rounded-full">
                      <Truck className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-gray-900">Free Ship 99k+</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-center">
                    <div className="bg-[#7FB069] p-2 rounded-full">
                      <RotateCcw className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-gray-900">Đổi Trả 7 Ngày</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Content - Testimonials */}
              <div className="space-y-6">
                <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
                  <div className="flex items-start gap-4">
                    <img 
                      src="https://images.unsplash.com/photo-1494790108755-2616b9c4c4cc?w=60&h=60&fit=crop&crop=face&auto=format" 
                      alt="Khách hàng" 
                      className="w-12 h-12 rounded-full object-cover"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-1 mb-2">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                      <p className="text-gray-700 text-sm leading-relaxed">
                        "Sản phẩm chất lượng tuyệt vời! Đúng như mô tả và giao hàng nhanh chóng. Tôi rất hài lòng với dịch vụ của JapanSuki."
                      </p>
                      <div className="mt-3 text-sm">
                        <span className="font-semibold text-gray-900">Nguyễn Thị Mai</span>
                        <span className="text-gray-500 ml-2">Khách hàng thân thiết</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
                  <div className="flex items-start gap-4">
                    <img 
                      src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=60&h=60&fit=crop&crop=face&auto=format" 
                      alt="Khách hàng" 
                      className="w-12 h-12 rounded-full object-cover"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-1 mb-2">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                      <p className="text-gray-700 text-sm leading-relaxed">
                        "Đã mua nhiều lần, sản phẩm luôn tươi ngon và đóng gói cẩn thận. Giá cả hợp lý so với chất lượng."
                      </p>
                      <div className="mt-3 text-sm">
                        <span className="font-semibold text-gray-900">Trần Minh Hoàng</span>
                        <span className="text-gray-500 ml-2">Đã mua 15+ đơn hàng</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Enhanced Product Categories */}
        <section className="mb-16">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Danh Mục Sản Phẩm
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Khám phá bộ sưu tập đa dạng các sản phẩm chính hãng từ Nhật Bản
            </p>
          </div>

          {/* Main Categories Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {[
              {
                name: 'Snacks & Kẹo Nhật',
                subtitle: 'Kit Kat, Ramune candy, Melty kiss',
                count: 120,
                color: 'from-pink-400 to-red-400',
                bgColor: 'bg-pink-50',
                icon: '🍭',
                href: '/category/thuc-pham'
              },
              {
                name: 'Nước Uống',
                subtitle: 'Ramune, Coca, Trà xanh',
                count: 85,
                color: 'from-blue-400 to-cyan-400',
                bgColor: 'bg-blue-50',
                icon: '🥤',
                href: '/category/thuc-pham'
              },
              {
                name: 'Mì Tôm & Mì Ăn Liền',
                subtitle: 'Nissin, Maruchan premium',
                count: 65,
                color: 'from-orange-400 to-yellow-400',
                bgColor: 'bg-orange-50',
                icon: '🍜',
                href: '/category/thuc-pham'
              },
              {
                name: 'Gia Vị & Sauce',
                subtitle: 'Miso, Wasabi, Teriyaki',
                count: 45,
                color: 'from-green-400 to-emerald-400',
                bgColor: 'bg-green-50',
                icon: '🥢',
                href: '/category/thuc-pham'
              }
            ].map((category, index) => (
              <Link key={index} href={category.href}>
                <Card className={`${category.bgColor} hover:shadow-2xl transition-all duration-300 cursor-pointer group border-0 overflow-hidden transform hover:-translate-y-2`}>
                  <CardContent className="p-6 relative">
                    {/* Category Icon */}
                    <div className="text-4xl mb-4 transform group-hover:scale-110 transition-transform duration-300">
                      {category.icon}
                    </div>
                    
                    {/* Category Info */}
                    <div className="space-y-2">
                      <h3 className="text-xl font-bold text-gray-900 group-hover:text-[#DC143C] transition-colors">
                        {category.name}
                      </h3>
                      <p className="text-sm text-gray-600 leading-relaxed">
                        {category.subtitle}
                      </p>
                      <div className="flex items-center justify-between pt-3">
                        <Badge className={`bg-gradient-to-r ${category.color} text-white px-3 py-1 text-xs font-semibold`}>
                          {category.count} sản phẩm
                        </Badge>
                        <Eye className="w-5 h-5 text-gray-400 group-hover:text-[#DC143C] transition-colors" />
                      </div>
                    </div>

                    {/* Hover Overlay */}
                    <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>

          {/* Special Sections Row */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* New Arrivals */}
            <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-6 border border-purple-100">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold text-gray-900 flex items-center">
                  <Plus className="w-5 h-5 mr-2 text-purple-600" />
                  Sản Phẩm Mới Nhập
                </h3>
                <Badge className="bg-purple-600 text-white px-3 py-1 text-xs font-semibold animate-pulse">
                  NEW
                </Badge>
              </div>
              <p className="text-gray-600 text-sm mb-4">
                Cập nhật hàng tuần từ Nhật Bản
              </p>
              <div className="grid grid-cols-2 gap-3">
                {hotProducts.slice(0, 4).map((product: Product) => (
                  <Link key={product.id} href={`/product/${product.slug}`}>
                    <div className="bg-white rounded-lg p-3 hover:shadow-md transition-shadow cursor-pointer group">
                      <img 
                        src={product.imageUrl || 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=150&h=150&fit=crop&auto=format'} 
                        alt={product.name}
                        className="w-full h-20 object-cover rounded-md mb-2 group-hover:scale-105 transition-transform"
                        loading="lazy"
                      />
                      <h4 className="text-xs font-medium text-gray-900 line-clamp-2">
                        {product.name}
                      </h4>
                      <p className="text-xs font-bold text-[#DC143C] mt-1">
                        {formatPrice(product.price)}đ
                      </p>
                    </div>
                  </Link>
                ))}
              </div>
            </div>

            {/* Best Sellers */}
            <div className="bg-gradient-to-br from-yellow-50 to-orange-50 rounded-2xl p-6 border border-yellow-100">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold text-gray-900 flex items-center">
                  <TrendingUp className="w-5 h-5 mr-2 text-yellow-600" />
                  Best Sellers Tuần Này
                </h3>
                <Badge className="bg-yellow-600 text-white px-3 py-1 text-xs font-semibold">
                  HOT
                </Badge>
              </div>
              <p className="text-gray-600 text-sm mb-4">
                Top sản phẩm bán chạy nhất
              </p>
              <div className="space-y-3">
                {hotProducts.slice(0, 3).map((product: Product, index) => (
                  <Link key={product.id} href={`/product/${product.slug}`}>
                    <div className="bg-white rounded-lg p-3 hover:shadow-md transition-shadow cursor-pointer group flex items-center gap-3">
                      <div className="bg-yellow-600 text-white text-xs font-bold w-6 h-6 rounded-full flex items-center justify-center">
                        {index + 1}
                      </div>
                      <img 
                        src={product.imageUrl || 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=60&h=60&fit=crop&auto=format'} 
                        alt={product.name}
                        className="w-12 h-12 object-cover rounded-md group-hover:scale-105 transition-transform"
                        loading="lazy"
                      />
                      <div className="flex-1">
                        <h4 className="text-sm font-medium text-gray-900 line-clamp-1">
                          {product.name}
                        </h4>
                        <div className="flex items-center gap-2 mt-1">
                          <p className="text-sm font-bold text-[#DC143C]">
                            {formatPrice(product.price)}đ
                          </p>
                          <div className="flex items-center">
                            <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                            <span className="text-xs text-gray-500 ml-1">4.8</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>

            {/* Flash Sale */}
            <div className="bg-gradient-to-br from-red-50 to-pink-50 rounded-2xl p-6 border border-red-100">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold text-gray-900 flex items-center">
                  <Timer className="w-5 h-5 mr-2 text-red-600" />
                  Flash Sale
                </h3>
                <Badge className="bg-red-600 text-white px-3 py-1 text-xs font-semibold animate-bounce">
                  -50%
                </Badge>
              </div>
              
              {/* Countdown Timer */}
              <div className="bg-white rounded-lg p-3 mb-4 border border-red-100">
                <p className="text-xs text-gray-600 mb-2">Kết thúc sau:</p>
                <div className="grid grid-cols-4 gap-2 text-center">
                  {['12', '04', '35', '22'].map((time, index) => (
                    <div key={index} className="bg-red-600 text-white rounded-md p-2">
                      <div className="text-lg font-bold">{time}</div>
                      <div className="text-xs">
                        {['Giờ', 'Phút', 'Giây', 'MS'][index]}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                {hotProducts.slice(0, 2).map((product: Product) => (
                  <Link key={product.id} href={`/product/${product.slug}`}>
                    <div className="bg-white rounded-lg p-3 hover:shadow-md transition-shadow cursor-pointer group">
                      <div className="flex items-center gap-3">
                        <img 
                          src={product.imageUrl || 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=60&h=60&fit=crop&auto=format'} 
                          alt={product.name}
                          className="w-16 h-16 object-cover rounded-md group-hover:scale-105 transition-transform"
                          loading="lazy"
                        />
                        <div className="flex-1">
                          <h4 className="text-sm font-medium text-gray-900 line-clamp-1">
                            {product.name}
                          </h4>
                          <div className="flex items-center gap-2 mt-1">
                            <p className="text-sm font-bold text-red-600">
                              {Math.floor(parseInt(product.price) * 0.5).toLocaleString('vi-VN')}đ
                            </p>
                            <p className="text-xs text-gray-400 line-through">
                              {formatPrice(product.price)}đ
                            </p>
                          </div>
                          <Button size="sm" className="w-full mt-2 bg-red-600 hover:bg-red-700 text-white text-xs py-1 h-7">
                            <ShoppingCart className="w-3 h-3 mr-1" />
                            Mua ngay
                          </Button>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* About Us & Trust Section */}
        <section className="mb-16 bg-gradient-to-br from-gray-50 to-white rounded-3xl p-8 lg:p-12 shadow-lg">
          {/* Story Section */}
          <div className="text-center mb-16">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-[#DC143C] to-red-600 rounded-full mb-6">
              <Heart className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              Câu Chuyện Của JapanSuki
            </h2>
            <div className="max-w-4xl mx-auto space-y-6">
              <p className="text-xl text-gray-700 leading-relaxed">
                Xuất phát từ tình yêu sâu sắc với văn hóa và ẩm thực Nhật Bản, chúng tôi đã dành nhiều năm nghiên cứu 
                và xây dựng mối quan hệ trực tiếp với các nhà sản xuất uy tín tại Nhật Bản.
              </p>
              <div className="grid md:grid-cols-2 gap-8 mt-12">
                <div className="bg-white rounded-2xl p-6 shadow-md border border-gray-100">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-[#DC143C] rounded-full flex items-center justify-center mr-4">
                      <Award className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900">Mission</h3>
                  </div>
                  <p className="text-gray-700 leading-relaxed">
                    "Mang hương vị chân thực Nhật Bản đến từng gia đình Việt Nam, 
                    giúp mọi người khám phá và trải nghiệm văn hóa ẩm thực độc đáo của xứ sở hoa anh đào."
                  </p>
                </div>
                <div className="bg-white rounded-2xl p-6 shadow-md border border-gray-100">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-[#7FB069] rounded-full flex items-center justify-center mr-4">
                      <Users className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900">Vision</h3>
                  </div>
                  <p className="text-gray-700 leading-relaxed">
                    "Trở thành cầu nối ẩm thực Nhật-Việt đáng tin cậy nhất, 
                    nơi khách hàng có thể hoàn toàn yên tâm về chất lượng và nguồn gốc sản phẩm."
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Trust Indicators Grid */}
          <div className="mb-16">
            <h3 className="text-3xl font-bold text-gray-900 text-center mb-12">
              Cam Kết Chất Lượng
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                {
                  icon: <Shield className="w-8 h-8 text-white" />,
                  title: "100% Hàng Chính Hãng",
                  description: "Chứng nhận từ các nhà sản xuất Nhật Bản",
                  bgColor: "bg-gradient-to-br from-green-500 to-emerald-600",
                  badge: "CERTIFIED"
                },
                {
                  icon: <Truck className="w-8 h-8 text-white" />,
                  title: "Nhập Khẩu Trực Tiếp",
                  description: "Đối tác chính thức với 50+ thương hiệu Nhật",
                  bgColor: "bg-gradient-to-br from-blue-500 to-cyan-600",
                  badge: "OFFICIAL"
                },
                {
                  icon: <RotateCcw className="w-8 h-8 text-white" />,
                  title: "Đổi Trả Dễ Dàng",
                  description: "Chính sách đổi trả trong 7 ngày",
                  bgColor: "bg-gradient-to-br from-purple-500 to-violet-600",
                  badge: "7 DAYS"
                },
                {
                  icon: <Headphones className="w-8 h-8 text-white" />,
                  title: "Customer Service 24/7",
                  description: "AI Assistant + tư vấn viên chuyên nghiệp",
                  bgColor: "bg-gradient-to-br from-orange-500 to-red-600",
                  badge: "24/7"
                }
              ].map((item, index) => (
                <Card key={index} className="hover:shadow-xl transition-all duration-300 border-0 overflow-hidden group cursor-pointer transform hover:-translate-y-2">
                  <CardContent className="p-0">
                    <div className={`${item.bgColor} p-6 text-center relative`}>
                      <div className="absolute top-2 right-2">
                        <Badge className="bg-white/20 text-white text-xs font-semibold px-2 py-1">
                          {item.badge}
                        </Badge>
                      </div>
                      <div className="flex justify-center mb-4">
                        {item.icon}
                      </div>
                      <h4 className="text-white font-bold text-lg mb-2">
                        {item.title}
                      </h4>
                    </div>
                    <div className="p-6 bg-white">
                      <p className="text-gray-600 text-sm leading-relaxed">
                        {item.description}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Guarantee Section */}
          <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100">
            <h3 className="text-3xl font-bold text-gray-900 text-center mb-12">
              Bảo Đảm & Chính Sách
            </h3>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Left Column - Policies */}
              <div className="space-y-6">
                {[
                  {
                    icon: <CheckCircle className="w-6 h-6 text-green-600" />,
                    title: "Cam Kết Chất Lượng",
                    content: "Mỗi sản phẩm đều được kiểm tra kỹ lưỡng trước khi gửi đến khách hàng. Chúng tôi đảm bảo 100% hàng chính hãng với tem nhãn rõ ràng."
                  },
                  {
                    icon: <RotateCcw className="w-6 h-6 text-blue-600" />,
                    title: "Chính Sách Đổi Trả",
                    content: "Đổi trả miễn phí trong 7 ngày nếu sản phẩm lỗi do nhà sản xuất. Quy trình đơn giản, nhanh chóng chỉ với vài bước."
                  },
                  {
                    icon: <Lock className="w-6 h-6 text-purple-600" />,
                    title: "Bảo Mật Thanh Toán",
                    content: "Hệ thống thanh toán được mã hóa SSL 256-bit. Hỗ trợ đa dạng phương thức: VNPay, MoMo, ZaloPay, COD."
                  },
                  {
                    icon: <Truck className="w-6 h-6 text-orange-600" />,
                    title: "Giao Hàng Tin Cậy",
                    content: "Đối tác với các đơn vị vận chuyển uy tín: Giao Hàng Nhanh, Viettel Post, J&T Express. Theo dõi đơn hàng real-time."
                  }
                ].map((policy, index) => (
                  <div key={index} className="flex items-start gap-4 p-4 rounded-lg hover:bg-gray-50 transition-colors">
                    <div className="flex-shrink-0 mt-1">
                      {policy.icon}
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">
                        {policy.title}
                      </h4>
                      <p className="text-gray-600 text-sm leading-relaxed">
                        {policy.content}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Right Column - Customer Reviews */}
              <div className="space-y-6">
                <h4 className="text-xl font-bold text-gray-900 mb-6">
                  Khách Hàng Nói Gì Về Chúng Tôi
                </h4>
                <div className="space-y-4">
                  {[
                    {
                      name: "Lê Thị Hương",
                      role: "Khách hàng thân thiết",
                      content: "Đã mua sắm tại JapanSuki được 2 năm. Chất lượng sản phẩm luôn đảm bảo, giao hàng nhanh và đóng gói cẩn thận. Rất tin tưởng!",
                      rating: 5,
                      avatar: "https://images.unsplash.com/photo-1494790108755-2616b9c4c4cc?w=50&h=50&fit=crop&crop=face&auto=format"
                    },
                    {
                      name: "Nguyễn Minh Đức",
                      role: "Người yêu ẩm thực Nhật",
                      content: "Tìm được những sản phẩm khó tìm từ Nhật Bản. Customer service nhiệt tình, tư vấn chi tiết. Sẽ tiếp tục ủng hộ!",
                      rating: 5,
                      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=50&h=50&fit=crop&crop=face&auto=format"
                    },
                    {
                      name: "Trần Thị Mai",
                      role: "Đầu bếp chuyên nghiệp",
                      content: "Là đầu bếp, tôi rất khó tính về nguyên liệu. JapanSuki cung cấp những sản phẩm chất lượng cao, đúng chuẩn Nhật Bản.",
                      rating: 5,
                      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=50&h=50&fit=crop&crop=face&auto=format"
                    }
                  ].map((review, index) => (
                    <Card key={index} className="border border-gray-200 hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                          <img 
                            src={review.avatar} 
                            alt={review.name}
                            className="w-12 h-12 rounded-full object-cover"
                          />
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <h5 className="font-semibold text-gray-900 text-sm">
                                {review.name}
                              </h5>
                              <span className="text-xs text-gray-500">
                                {review.role}
                              </span>
                            </div>
                            <div className="flex items-center gap-1 mb-2">
                              {[...Array(review.rating)].map((_, i) => (
                                <Star key={i} className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                              ))}
                            </div>
                            <p className="text-gray-600 text-sm leading-relaxed">
                              "{review.content}"
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Promotion Banner */}
        <section className="mb-12">
          <div className="cherry-gradient rounded-xl p-6 text-white">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Gift className="w-8 h-8 mr-4" />
                <div>
                  <h3 className="text-xl font-bold mb-1">FreeShip</h3>
                  <p className="text-sm opacity-90">NHẬP MÃ: GZY1AOLYK2E0 - Miễn phí vận chuyển</p>
                </div>
              </div>
              <Button
                onClick={handleCopyCoupon}
                className={`px-6 py-2 rounded-full font-semibold transition-all ${
                  copiedCoupon 
                    ? 'bg-green-500 text-white' 
                    : 'bg-white text-cherry hover:bg-gray-100'
                }`}
              >
                {copiedCoupon ? 'Đã sao chép!' : 'Sao chép mã'}
              </Button>
            </div>
          </div>
        </section>

        {/* Hot Deals Section */}
        <section className="mb-12">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl font-bold text-gray-800 flex items-center">
              <Zap className="w-8 h-8 mr-3 text-yellow-500" />
              Giá Tốt
            </h2>
            <Link href="/category/thuc-pham">
              <Button variant="ghost" className="text-cherry font-semibold hover:text-cherry-gradient-end transition-colors">
                Xem tất cả <ArrowRight className="w-4 h-4 ml-1" />
              </Button>
            </Link>
          </div>

          <ProductGrid products={hotProducts} columns={5} />
        </section>

        {/* Toothpaste Category */}
        <section className="mb-12">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl font-bold text-gray-800 flex items-center">
              <span className="mr-3 text-blue-500">🦷</span>
              KEM ĐÁNH RĂNG
            </h2>
            <Link href="/category/kem-danh-rang">
              <Button variant="ghost" className="text-cherry font-semibold hover:text-cherry-gradient-end transition-colors">
                Xem tất cả <ArrowRight className="w-4 h-4 ml-1" />
              </Button>
            </Link>
          </div>

          <ProductGrid products={toothpasteProducts} columns={6} />
        </section>

        {/* Newsletter Subscription */}
        <section className="mb-12">
          <div className="cherry-gradient rounded-2xl p-8 text-white text-center">
            <h3 className="text-2xl font-bold mb-4 text-black">Đăng ký nhận tin khuyến mãi</h3>
            <p className="mb-6 opacity-90 text-black">Nhận thông tin sản phẩm mới và ưu đãi đặc biệt từ JapanSuki</p>
            <div className="flex max-w-md mx-auto">
              <input 
                type="email" 
                placeholder="Nhập email của bạn" 
                className="flex-1 px-4 py-3 rounded-l-full text-gray-700 focus:outline-none h-12"
              />
              <Button className="bg-black text-white px-6 py-3 rounded-r-full font-semibold hover:bg-gray-800 transition-colors h-12">
                Đăng ký
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
      <Chatbot />
    </div>
  );
}
