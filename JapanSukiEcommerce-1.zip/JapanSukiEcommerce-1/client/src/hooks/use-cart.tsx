import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { sessionManager, type CartItem } from '@/lib/types';

export interface UseCartReturn {
  items: CartItem[];
  isLoading: boolean;
  itemCount: number;
  total: number;
  addItem: (productId: number, quantity?: number) => Promise<void>;
  updateItem: (id: number, quantity: number) => Promise<void>;
  removeItem: (id: number) => Promise<void>;
  clearCart: () => Promise<void>;
}

export function useCart(): UseCartReturn {
  const queryClient = useQueryClient();
  const sessionId = sessionManager.getSessionId();

  const { data: items = [], isLoading } = useQuery({
    queryKey: ['/api/cart'],
    queryFn: async () => {
      const response = await fetch('/api/cart', {
        headers: {
          'X-Session-ID': sessionId
        }
      });
      if (!response.ok) {
        throw new Error('Failed to fetch cart');
      }
      return response.json();
    }
  });

  const addItemMutation = useMutation({
    mutationFn: async ({ productId, quantity = 1 }: { productId: number; quantity?: number }) => {
      const response = await fetch('/api/cart', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Session-ID': sessionId
        },
        body: JSON.stringify({
          productId,
          quantity
        })
      });
      if (!response.ok) {
        throw new Error('Failed to add item to cart');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
    }
  });

  const updateItemMutation = useMutation({
    mutationFn: async ({ id, quantity }: { id: number; quantity: number }) => {
      const response = await fetch(`/api/cart/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'X-Session-ID': sessionId
        },
        body: JSON.stringify({ quantity })
      });
      if (!response.ok) {
        throw new Error('Failed to update cart item');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
    }
  });

  const removeItemMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/cart/${id}`, {
        method: 'DELETE',
        headers: {
          'X-Session-ID': sessionId
        }
      });
      if (!response.ok) {
        throw new Error('Failed to remove cart item');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
    }
  });

  const clearCartMutation = useMutation({
    mutationFn: async () => {
      // Remove all items one by one (in a real app, you'd have a clear endpoint)
      await Promise.all(items.map((item: CartItem) => 
        fetch(`/api/cart/${item.id}`, {
          method: 'DELETE',
          headers: {
            'X-Session-ID': sessionId
          }
        })
      ));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
    }
  });

  const itemCount = items.reduce((sum: number, item: CartItem) => sum + item.quantity, 0);
  const total = items.reduce((sum: number, item: CartItem) => 
    sum + (parseFloat(item.product.price) * item.quantity), 0
  );

  return {
    items,
    isLoading,
    itemCount,
    total,
    addItem: async (productId: number, quantity?: number) => {
      await addItemMutation.mutateAsync({ productId, quantity });
    },
    updateItem: async (id: number, quantity: number) => {
      await updateItemMutation.mutateAsync({ id, quantity });
    },
    removeItem: async (id: number) => {
      await removeItemMutation.mutateAsync(id);
    },
    clearCart: async () => {
      await clearCartMutation.mutateAsync();
    }
  };
}
