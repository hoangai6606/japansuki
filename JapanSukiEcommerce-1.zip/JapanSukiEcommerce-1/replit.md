# JapanSuki E-commerce Platform

## Overview

JapanSuki is a Vietnamese e-commerce web application specializing in authentic Japanese products. The platform features a modern full-stack architecture built with React frontend, Express.js backend, and PostgreSQL database. The application offers product browsing, shopping cart functionality, wishlist management, and an AI-powered chatbot for customer support.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query for server state management
- **UI Components**: shadcn/ui component library with Radix UI primitives
- **Styling**: Tailwind CSS with cherry blossom themed color palette
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Pattern**: RESTful API with WebSocket support for real-time chat
- **Session Management**: Guest session management for anonymous users
- **File Structure**: Modular architecture with separate routes, services, and storage layers

### Database Architecture
- **Database**: PostgreSQL with Neon serverless connection
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema**: Structured tables for users, categories, products, cart items, wishlist items, orders, and coupons
- **Migrations**: Drizzle Kit for database schema management

## Key Components

### Product Management
- Hierarchical category system with parent-child relationships
- Product variants with detailed attributes (price, stock, brand, origin)
- Featured and hot product classifications
- Image management with multiple product images support
- Inventory tracking with stock levels and sold count

### Shopping Experience
- Guest and user session-based shopping cart
- Wishlist functionality for product saving
- Real-time inventory updates
- Product search and filtering capabilities
- Price range filtering and sorting options

### Payment Integration
- Mock payment service supporting multiple Vietnamese payment methods:
  - VNPay
  - MoMo
  - ZaloPay
  - Bank transfer
  - Cash on delivery (COD)
- Order management with status tracking
- Coupon system for discounts

### AI Customer Support
- OpenAI GPT-4o powered chatbot
- WebSocket-based real-time communication
- Vietnamese language support
- Product recommendation capabilities
- Company-specific knowledge base integration

## Data Flow

### Client-Server Communication
1. Frontend makes API requests to Express.js backend
2. Backend processes requests through route handlers
3. Storage layer interfaces with PostgreSQL via Drizzle ORM
4. Responses are cached and managed by TanStack Query on frontend

### Session Management
1. Guest users receive auto-generated session IDs
2. Session data persists in localStorage for client-side tracking
3. Backend correlates cart/wishlist data with session IDs
4. User registration/login can merge guest session data

### Real-time Features
1. WebSocket connections established for chat functionality
2. Bidirectional message exchange between client and server
3. Chat history maintained per session
4. AI responses generated via OpenAI API integration

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL serverless connection
- **drizzle-orm**: Type-safe ORM for database operations
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Headless UI component primitives
- **openai**: AI chatbot integration
- **ws**: WebSocket server implementation

### Development Tools
- **tsx**: TypeScript execution for development
- **esbuild**: Fast JavaScript bundler for production
- **tailwindcss**: Utility-first CSS framework
- **vite**: Frontend build tool and dev server

### Payment & External Services
- Mock implementations for Vietnamese payment gateways
- OpenAI API for conversational AI
- Image hosting capabilities (URLs stored in database)

## Deployment Strategy

### Development Environment
- Replit-based development with hot reloading
- PostgreSQL module integration
- Environment variable management for API keys
- Development server on port 5000

### Production Build
1. Vite builds optimized frontend assets
2. esbuild bundles server code for Node.js
3. Static assets served from dist/public directory
4. Production server runs compiled JavaScript

### Environment Configuration
- Database connection via DATABASE_URL environment variable
- OpenAI API key configuration
- Payment gateway credentials (when implemented)
- Session management configuration

### Scaling Considerations
- Serverless-ready architecture with Neon PostgreSQL
- Stateless session management approach
- CDN-ready static asset serving
- WebSocket connection pooling for chat features

## Changelog
- June 15, 2025. Initial setup
- June 16, 2025. Added comprehensive admin panel system with authentication, product management, order tracking, and user management. Integrated Gemini AI for Vietnamese customer support chatbot.
- June 16, 2025. Major UI/UX improvements: Fixed sticky category navigation, updated footer with black text, created functional footer pages (About, Warranty, Returns, Guide). Implemented complete customer authentication system with login/register pages and user account management. Enhanced admin panel with real user management capabilities.
- June 17, 2025. Enhanced admin panel with advanced category and user management features. Added full CRUD operations for categories (add/edit/delete with form validation and parent category support). Implemented comprehensive member account management with detailed user editing (username, email, full name, phone, address, account status). Added sample user data for testing admin functionality. Created corresponding backend API routes for all admin operations.

## User Preferences

Preferred communication style: Simple, everyday language.