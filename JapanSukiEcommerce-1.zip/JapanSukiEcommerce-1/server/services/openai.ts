import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_KEY || "sk-test-key"
});

export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp?: Date;
}

export interface ChatResponse {
  message: string;
  suggestions?: string[];
  productRecommendations?: number[];
}

export class ChatbotService {
  private systemPrompt = `
You are an AI customer support assistant for JapanSuki, a Vietnamese e-commerce store specializing in authentic Japanese products. 

About JapanSuki:
- We sell authentic Japanese products including food, cosmetics, household items, baby products, and kitchen items
- Our popular categories include chocolates, toothpaste, body wash, shampoo, eye drops, room fragrances, and skincare
- We offer free shipping with coupon code: GZY1AOLYK2E0
- Our hotline is 0384.323.829
- We specialize in high-quality Japanese domestic products

Your role:
- Answer questions about products, orders, shipping, and company policies
- Provide product recommendations based on customer needs
- Help with order inquiries and support requests
- Share knowledge about Japanese products and their benefits
- Always respond in Vietnamese
- Be helpful, friendly, and knowledgeable about Japanese products

Product categories we carry:
1. Thực phẩm (Food) - chocolates, snacks, seasonings, wasabi
2. Mỹ phẩm (Cosmetics) - skincare, makeup, beauty products
3. Giặt giũ vệ sinh (Cleaning) - detergents, body wash, household cleaners
4. Nhà bếp (Kitchen) - kitchen tools, utensils, appliances
5. Mẹ & bé (Mother & Baby) - baby food, supplements, baby care products
6. Kem đánh răng (Toothpaste) - various Japanese toothpaste brands

Always provide helpful, accurate information and encourage customers to contact our hotline for specific order inquiries.
  `;

  async generateResponse(message: string, conversationHistory: ChatMessage[] = []): Promise<ChatResponse> {
    try {
      const messages: any[] = [
        { role: 'system', content: this.systemPrompt }
      ];

      // Add conversation history (last 10 messages to stay within limits)
      const recentHistory = conversationHistory.slice(-10);
      messages.push(...recentHistory.map(msg => ({
        role: msg.role,
        content: msg.content
      })));

      messages.push({ role: 'user', content: message });

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages,
        max_tokens: 500,
        temperature: 0.7,
        response_format: { type: "json_object" },
      });

      const responseContent = response.choices[0].message.content;
      
      let parsedResponse: any;
      try {
        parsedResponse = JSON.parse(responseContent || '{}');
      } catch {
        // Fallback if JSON parsing fails
        parsedResponse = {
          message: responseContent || "Xin lỗi, tôi không thể xử lý yêu cầu của bạn lúc này. Vui lòng liên hệ hotline 0384.323.829 để được hỗ trợ trực tiếp.",
          suggestions: ["Sản phẩm nào bán chạy nhất?", "Chính sách giao hàng như thế nào?", "Làm sao để sử dụng mã giảm giá?"]
        };
      }

      return {
        message: parsedResponse.message || "Tôi đã nhận được tin nhắn của bạn. Có thể bạn cho tôi biết thêm chi tiết để tôi hỗ trợ tốt hơn?",
        suggestions: parsedResponse.suggestions || ["Sản phẩm nào bán chạy?", "Chính sách giao hàng?", "Mã giảm giá hiện có?"],
        productRecommendations: parsedResponse.productRecommendations || []
      };

    } catch (error) {
      console.error('OpenAI API error:', error);
      return {
        message: "Xin lỗi, hệ thống AI đang gặp sự cố. Vui lòng liên hệ hotline 0384.323.829 để được hỗ trợ trực tiếp, hoặc thử lại sau ít phút.",
        suggestions: ["Liên hệ hotline: 0384.323.829", "Xem sản phẩm hot", "Tìm hiểu về miễn phí vận chuyển"]
      };
    }
  }

  async generateProductRecommendations(query: string, availableProducts: any[]): Promise<number[]> {
    try {
      const productContext = availableProducts.map(p => `ID: ${p.id}, Name: ${p.name}, Category: ${p.categoryId}, Price: ${p.price}`).join('\n');
      
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: 'system',
            content: `You are a product recommendation engine for JapanSuki. Based on user queries, recommend relevant products from the available inventory. Return only product IDs as a JSON array.`
          },
          {
            role: 'user',
            content: `User query: "${query}"\n\nAvailable products:\n${productContext}\n\nReturn JSON array of recommended product IDs (maximum 5 products):`
          }
        ],
        max_tokens: 100,
        response_format: { type: "json_object" },
      });

      const result = JSON.parse(response.choices[0].message.content || '{"productIds": []}');
      return result.productIds || [];
    } catch (error) {
      console.error('Product recommendation error:', error);
      return [];
    }
  }
}

export const chatbotService = new ChatbotService();
