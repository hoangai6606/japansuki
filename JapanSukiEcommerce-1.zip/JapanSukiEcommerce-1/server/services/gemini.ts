import { GoogleGenerativeAI } from "@google/generative-ai";

export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp?: Date;
}

export interface ChatResponse {
  message: string;
  suggestions?: string[];
  productRecommendations?: number[];
}

export class ChatbotService {
  private genAI: GoogleGenerativeAI;
  private model: any;

  constructor() {
    this.genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || '');
    this.model = this.genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
  }

  private systemPrompt = `
Bạn là AI hỗ trợ khách hàng của JapanSuki - website bán hàng Nhật Bản tại Việt Nam.

THÔNG TIN VỀ JAPANSUKI:
- Website thương mại điện tử chuyên bán các sản phẩm Nhật Bản chính hãng
- Các sản phẩm phổ biến: chocolate, kem đánh răng, sữa tắm, dầu gội, thuốc nhỏ mắt, nước hoa phòng, mỹ phẩm
- Miễn phí vận chuyển với mã: GZY1AOLYK2E0
- Hotline hỗ trợ: 0384.323.829
- Chuyên về sản phẩm nội địa Nhật Bản chất lượng cao

CÁC DANH MỤC SẢN PHẨM:
1. Thực phẩm - chocolate, snack, gia vị, wasabi
2. Mỹ phẩm - chăm sóc da, makeup, sản phẩm làm đẹp
3. Giặt giũ vệ sinh - chất tẩy rửa, sữa tắm, đồ dọn dẹp
4. Nhà bếp - dụng cụ, đồ gia dụng nhà bếp
5. Mẹ & bé - thức ăn trẻ em, thực phẩm bổ sung, chăm sóc em bé
6. Kem đánh răng - các thương hiệu Nhật Bản

VAI TRÒ CỦA BẠN:
- Trả lời câu hỏi về sản phẩm, đơn hàng, giao hàng, chính sách
- Tư vấn sản phẩm phù hợp với nhu cầu khách hàng
- Hỗ trợ các yêu cầu về đơn hàng
- Chia sẻ kiến thức về sản phẩm Nhật Bản và lợi ích
- Luôn trả lời bằng tiếng Việt thân thiện, hữu ích

Hãy luôn khuyến khích khách hàng liên hệ hotline 0384.323.829 cho các câu hỏi cụ thể về đơn hàng.

Trả lời theo định dạng JSON: {"message": "nội dung trả lời", "suggestions": ["gợi ý 1", "gợi ý 2", "gợi ý 3"], "productRecommendations": []}
`;

  async generateResponse(message: string, conversationHistory: ChatMessage[] = []): Promise<ChatResponse> {
    try {
      // Build conversation context
      const contextHistory = conversationHistory.slice(-5).map(msg => 
        `${msg.role === 'user' ? 'Khách hàng' : 'AI'}: ${msg.content}`
      ).join('\n');

      const prompt = `${this.systemPrompt}

Lịch sử hội thoại gần đây:
${contextHistory}

Câu hỏi mới của khách hàng: ${message}

Hãy trả lời theo định dạng JSON chính xác:
{"message": "nội dung trả lời bằng tiếng Việt", "suggestions": ["gợi ý 1", "gợi ý 2", "gợi ý 3"], "productRecommendations": []}`;

      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      const text = response.text();

      // Extract JSON from response
      let parsedResponse;
      try {
        const jsonMatch = text.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          parsedResponse = JSON.parse(jsonMatch[0]);
        } else {
          // Fallback if no JSON structure found
          parsedResponse = {
            message: text.trim(),
            suggestions: ['Sản phẩm nào bán chạy nhất?', 'Chính sách giao hàng như thế nào?', 'Mã giảm giá hiện có?'],
            productRecommendations: []
          };
        }
      } catch (parseError) {
        console.log('JSON parsing failed, using fallback:', parseError);
        parsedResponse = {
          message: text.trim() || 'Tôi đã nhận được tin nhắn của bạn. Có thể bạn cho tôi biết thêm chi tiết để tôi hỗ trợ tốt hơn?',
          suggestions: ['Sản phẩm nào bán chạy?', 'Chính sách giao hàng?', 'Mã giảm giá hiện có?'],
          productRecommendations: []
        };
      }
      
      return {
        message: parsedResponse.message || 'Tôi đã nhận được tin nhắn của bạn. Có thể bạn cho tôi biết thêm chi tiết để tôi hỗ trợ tốt hơn?',
        suggestions: parsedResponse.suggestions || ['Sản phẩm nào bán chạy?', 'Chính sách giao hàng?', 'Mã giảm giá hiện có?'],
        productRecommendations: parsedResponse.productRecommendations || []
      };

    } catch (error) {
      console.error('Gemini AI error:', error);
      return {
        message: 'Xin lỗi, hệ thống AI đang gặp sự cố. Vui lòng liên hệ hotline 0384.323.829 để được hỗ trợ trực tiếp, hoặc thử lại sau ít phút.',
        suggestions: ['Liên hệ hotline: 0384.323.829', 'Xem sản phẩm hot', 'Tìm hiểu về miễn phí vận chuyển'],
        productRecommendations: []
      };
    }
  }

  async generateProductRecommendations(query: string, availableProducts: any[]): Promise<number[]> {
    try {
      const productContext = availableProducts.map(p => 
        `ID: ${p.id}, Tên: ${p.name}, Danh mục: ${p.categoryId}, Giá: ${p.price}`
      ).join('\n');
      
      const prompt = `Bạn là hệ thống gợi ý sản phẩm cho JapanSuki. Dựa trên yêu cầu của khách hàng, hãy gợi ý các sản phẩm phù hợp từ danh sách có sẵn.

Yêu cầu của khách hàng: "${query}"

Danh sách sản phẩm có sẵn:
${productContext}

Trả về JSON với danh sách ID sản phẩm được gợi ý (tối đa 5 sản phẩm):
{"productIds": [1, 2, 3]}`;

      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      const text = response.text();

      const jsonMatch = text.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        return parsed.productIds || [];
      }
      return [];
    } catch (error) {
      console.error('Product recommendation error:', error);
      return [];
    }
  }
}

export const chatbotService = new ChatbotService();