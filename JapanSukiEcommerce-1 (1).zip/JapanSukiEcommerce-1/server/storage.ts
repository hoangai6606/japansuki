import { 
  users, categories, products, cartItems, wishlistItems, orders, orderItems, coupons,
  type User, type InsertUser, type Category, type InsertCategory, 
  type Product, type InsertProduct, type CartItem, type InsertCartItem,
  type WishlistItem, type InsertWishlistItem, type Order, type InsertOrder,
  type OrderItem, type Coupon, type InsertCoupon
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUsers(): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined>;
  validateUserCredentials(email: string, password: string): Promise<User | undefined>;

  // Categories
  getCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;

  // Products
  getProducts(limit?: number, offset?: number): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  getProductBySlug(slug: string): Promise<Product | undefined>;
  getProductsByCategory(categoryId: number): Promise<Product[]>;
  getFeaturedProducts(): Promise<Product[]>;
  getHotProducts(): Promise<Product[]>;
  searchProducts(query: string): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProductStock(id: number, stock: number): Promise<void>;
  incrementSoldCount(id: number, count: number): Promise<void>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<void>;

  // Cart
  getCartItems(userId?: number, sessionId?: string): Promise<(CartItem & { product: Product })[]>;
  addToCart(item: InsertCartItem): Promise<CartItem>;
  updateCartItem(id: number, quantity: number): Promise<void>;
  removeFromCart(id: number): Promise<void>;
  clearCart(userId?: number, sessionId?: string): Promise<void>;

  // Wishlist
  getWishlistItems(userId?: number, sessionId?: string): Promise<(WishlistItem & { product: Product })[]>;
  addToWishlist(item: InsertWishlistItem): Promise<WishlistItem>;
  removeFromWishlist(id: number): Promise<void>;

  // Orders
  getOrders(userId?: number): Promise<Order[]>;
  getOrder(id: number): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrderStatus(id: number, status: string): Promise<void>;

  // Coupons
  getCoupon(code: string): Promise<Coupon | undefined>;
  createCoupon(coupon: InsertCoupon): Promise<Coupon>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User> = new Map();
  private categories: Map<number, Category> = new Map();
  private products: Map<number, Product> = new Map();
  private cartItems: Map<number, CartItem> = new Map();
  private wishlistItems: Map<number, WishlistItem> = new Map();
  private orders: Map<number, Order> = new Map();
  private orderItems: Map<number, OrderItem> = new Map();
  private coupons: Map<number, Coupon> = new Map();
  
  private currentUserId = 1;
  private currentCategoryId = 1;
  private currentProductId = 1;
  private currentCartItemId = 1;
  private currentWishlistItemId = 1;
  private currentOrderId = 1;
  private currentOrderItemId = 1;
  private currentCouponId = 1;

  constructor() {
    this.seedData();
  }

  private seedData() {
    // Seed categories
    const categoriesData = [
      { name: "Thực phẩm", slug: "thuc-pham", icon: "fas fa-utensils", imageUrl: "https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" },
      { name: "Mỹ phẩm", slug: "my-pham", icon: "fas fa-spa", imageUrl: "https://images.unsplash.com/photo-1596462502278-27bfdc403348?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" },
      { name: "Giặt giũ vệ sinh", slug: "giat-giu-ve-sinh", icon: "fas fa-spray-can", imageUrl: "https://images.unsplash.com/photo-1556228720-195a672e8a03?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" },
      { name: "Nhà bếp", slug: "nha-bep", icon: "fas fa-blender", imageUrl: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" },
      { name: "Mẹ & bé", slug: "me-be", icon: "fas fa-baby", imageUrl: "https://images.unsplash.com/photo-1555252333-9f8e92e65df9?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" },
      { name: "Socola", slug: "socola", icon: "fas fa-candy-cane", imageUrl: "https://images.unsplash.com/photo-1511381939415-e44015466834?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" },
      { name: "Kem Đánh Răng", slug: "kem-danh-rang", icon: "fas fa-tooth", imageUrl: "https://images.unsplash.com/photo-1607613009820-a29f7bb81c04?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" },
    ];

    categoriesData.forEach(cat => {
      const category: Category = {
        id: this.currentCategoryId++,
        ...cat,
        description: `Danh mục ${cat.name} chất lượng cao từ Nhật Bản`,
        parentId: null,
      };
      this.categories.set(category.id, category);
    });

    // Seed products
    const productsData = [
      {
        name: "Bánh quy Bourbon socola hình gốc cây 66g (10 cái)",
        slug: "banh-quy-bourbon-socola-hinh-goc-cay-66g",
        description: "Bánh quy Bourbon socola hình gốc cây là sản phẩm nổi tiếng từ Nhật Bản với hương vị socola đậm đà, giòn tan. Thiết kế độc đáo hình gốc cây tạo nên sự thú vị khi thưởng thức.",
        shortDescription: "Bánh quy socola Nhật Bản hình gốc cây độc đáo",
        price: "44000",
        stock: 100,
        categoryId: 6,
        brand: "Bourbon",
        weight: "66g",
        imageUrl: "https://images.unsplash.com/photo-1558961363-fa8fdf82db35?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        isHot: true,
        soldCount: 0,
      },
      {
        name: "Kẹo siêu chua Super vị chanh 90gr",
        slug: "keo-sieu-chua-super-vi-chanh-90gr",
        description: "Kẹo siêu chua Super vị chanh mang lại cảm giác chua ngọt đặc trưng, là lựa chọn hoàn hảo cho những ai yêu thích vị chua tươi mát.",
        shortDescription: "Kẹo chua vị chanh từ Nhật Bản",
        price: "54000",
        stock: 50,
        categoryId: 1,
        brand: "Super",
        weight: "90g",
        imageUrl: "https://images.unsplash.com/photo-1582058091505-f87a2e55a40f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        isHot: true,
        soldCount: 0,
      },
      {
        name: "Kem đánh răng muối Sunstar Nhật Bản trắng răng, giảm hôi miệng, sạch sâu 170gr",
        slug: "kem-danh-rang-muoi-sunstar-170gr",
        description: "Kem đánh răng muối Sunstar giúp làm trắng răng tự nhiên, giảm hôi miệng và làm sạch sâu mảng bám. Công thức đặc biệt với muối biển tự nhiên.",
        shortDescription: "Kem đánh răng muối Sunstar làm trắng răng",
        price: "43000",
        stock: 200,
        categoryId: 7,
        brand: "Sunstar",
        weight: "170g",
        imageUrl: "https://images.unsplash.com/photo-1607613009820-a29f7bb81c04?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        isFeatured: true,
        soldCount: 1265,
      },
      {
        name: "Kem đánh răng Nhật bản White White làm trắng răng thơm miệng 150gr",
        slug: "kem-danh-rang-white-white-150gr",
        description: "Kem đánh răng White White với công thức đặc biệt làm trắng răng hiệu quả, mang lại hơi thở thơm mát suốt cả ngày.",
        shortDescription: "Kem đánh răng White White làm trắng răng",
        price: "44000",
        stock: 150,
        categoryId: 7,
        brand: "White White",
        weight: "150g",
        imageUrl: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        isFeatured: true,
        soldCount: 1675,
      },
      {
        name: "Mù Tạt Nhật SB Wasabi Neri 43g",
        slug: "mu-tat-nhat-sb-wasabi-neri-43g",
        description: "Mù tạt wasabi SB chính hãng từ Nhật Bản, mang lại vị cay nồng đặc trưng, phù hợp để ăn kèm sushi, sashimi và các món ăn Nhật Bản.",
        shortDescription: "Mù tạt wasabi SB chính hãng từ Nhật Bản",
        price: "36000",
        stock: 80,
        categoryId: 1,
        brand: "SB",
        weight: "43g",
        imageUrl: "https://images.unsplash.com/photo-1579952163873-27909798c2ba?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        isHot: true,
        soldCount: 0,
      },
      {
        name: "THỰC PHẨM BỔ SUNG KẸO MÚT IQ BỔ SUNG DHA CHO BÉ UNIMAT RIKEN",
        slug: "keo-mut-iq-bo-sung-dha-cho-be-unimat-riken",
        description: "Kẹo mút bổ sung DHA giúp phát triển trí não cho trẻ em, với hương vị thơm ngon, dễ sử dụng và an toàn cho bé.",
        shortDescription: "Kẹo mút bổ sung DHA cho bé",
        price: "71000",
        stock: 60,
        categoryId: 5,
        brand: "UNIMAT RIKEN",
        weight: "90g",
        imageUrl: "https://images.unsplash.com/photo-1559757175-0eb30cd8c063?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        isHot: true,
        soldCount: 283,
      },
    ];

    productsData.forEach(prod => {
      const product: Product = {
        id: this.currentProductId++,
        ...prod,
        originalPrice: null,
        origin: prod.origin || "Nhật Bản",
        images: [prod.imageUrl],
        createdAt: new Date(),
      };
      this.products.set(product.id, product);
    });

    // Seed sample users for admin management
    const usersData = [
      {
        username: "nguyenvana",
        email: "nguyenvana@email.com",
        password: "password123",
        fullName: "Nguyễn Văn A",
        phone: "0123456789",
        address: "123 Đường ABC, Quận 1, TP.HCM",
        role: "customer",
        isActive: true
      },
      {
        username: "tranthib",
        email: "tranthib@email.com", 
        password: "password123",
        fullName: "Trần Thị B",
        phone: "0987654321",
        address: "456 Đường XYZ, Quận 3, TP.HCM",
        role: "customer",
        isActive: true
      },
      {
        username: "lequangc",
        email: "lequangc@email.com",
        password: "password123", 
        fullName: "Lê Quang C",
        phone: "0369852147",
        address: "789 Đường DEF, Quận 7, TP.HCM",
        role: "customer",
        isActive: false
      }
    ];

    usersData.forEach(userData => {
      const user: User = {
        id: this.currentUserId++,
        ...userData,
        createdAt: new Date(),
      };
      this.users.set(user.id, user);
    });

    // Seed coupon
    const coupon: Coupon = {
      id: this.currentCouponId++,
      code: "GZY1AOLYK2E0",
      description: "Miễn phí vận chuyển",
      discountType: "shipping",
      discountValue: "0",
      minAmount: null,
      isActive: true,
      expiresAt: null,
      createdAt: new Date(),
    };
    this.coupons.set(coupon.id, coupon);
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const user: User = {
      id: this.currentUserId++,
      ...insertUser,
      fullName: insertUser.fullName || `${insertUser.firstName || ''} ${insertUser.lastName || ''}`.trim(),
      role: insertUser.role || "customer",
      isActive: insertUser.isActive !== false,
      createdAt: new Date(),
    };
    this.users.set(user.id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;

    const updatedUser: User = {
      ...user,
      ...userData,
      fullName: userData.firstName || userData.lastName ? 
        `${userData.firstName || user.firstName || ''} ${userData.lastName || user.lastName || ''}`.trim() :
        user.fullName,
      id: user.id,
    };

    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async validateUserCredentials(email: string, password: string): Promise<User | undefined> {
    const user = await this.getUserByEmail(email);
    if (!user || !user.isActive) return undefined;
    
    // In production, use proper password hashing (bcrypt)
    if (user.password === password) {
      return user;
    }
    return undefined;
  }

  // Categories
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getCategory(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }

  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    return Array.from(this.categories.values()).find(cat => cat.slug === slug);
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const category: Category = {
      id: this.currentCategoryId++,
      ...insertCategory,
    };
    this.categories.set(category.id, category);
    return category;
  }

  // Products
  async getProducts(limit: number = 50, offset: number = 0): Promise<Product[]> {
    const products = Array.from(this.products.values());
    return products.slice(offset, offset + limit);
  }

  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProductBySlug(slug: string): Promise<Product | undefined> {
    return Array.from(this.products.values()).find(prod => prod.slug === slug);
  }

  async getProductsByCategory(categoryId: number): Promise<Product[]> {
    return Array.from(this.products.values()).filter(prod => prod.categoryId === categoryId);
  }

  async getFeaturedProducts(): Promise<Product[]> {
    return Array.from(this.products.values()).filter(prod => prod.isFeatured);
  }

  async getHotProducts(): Promise<Product[]> {
    return Array.from(this.products.values()).filter(prod => prod.isHot);
  }

  async searchProducts(query: string): Promise<Product[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.products.values()).filter(prod => 
      prod.name.toLowerCase().includes(lowerQuery) ||
      prod.description?.toLowerCase().includes(lowerQuery) ||
      prod.brand?.toLowerCase().includes(lowerQuery)
    );
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const product: Product = {
      id: this.currentProductId++,
      ...insertProduct,
      soldCount: 0,
      createdAt: new Date(),
    };
    this.products.set(product.id, product);
    return product;
  }

  async updateProductStock(id: number, stock: number): Promise<void> {
    const product = this.products.get(id);
    if (product) {
      product.stock = stock;
      this.products.set(id, product);
    }
  }

  async incrementSoldCount(id: number, count: number): Promise<void> {
    const product = this.products.get(id);
    if (product) {
      product.soldCount = (product.soldCount || 0) + count;
      this.products.set(id, product);
    }
  }

  async updateProduct(id: number, productData: Partial<InsertProduct>): Promise<Product | undefined> {
    const product = this.products.get(id);
    if (!product) return undefined;

    const updatedProduct: Product = {
      ...product,
      ...productData,
      id: product.id,
      createdAt: product.createdAt
    };

    this.products.set(id, updatedProduct);
    return updatedProduct;
  }

  async deleteProduct(id: number): Promise<void> {
    this.products.delete(id);
    // Also remove from cart and wishlist
    for (const [cartId, cartItem] of this.cartItems.entries()) {
      if (cartItem.productId === id) {
        this.cartItems.delete(cartId);
      }
    }
    for (const [wishlistId, wishlistItem] of this.wishlistItems.entries()) {
      if (wishlistItem.productId === id) {
        this.wishlistItems.delete(wishlistId);
      }
    }
  }

  // Cart
  async getCartItems(userId?: number, sessionId?: string): Promise<(CartItem & { product: Product })[]> {
    const items = Array.from(this.cartItems.values()).filter(item => {
      if (userId) {
        return item.userId === userId;
      }
      if (sessionId) {
        return item.sessionId === sessionId;
      }
      return false;
    });
    
    return items.map(item => {
      const product = this.products.get(item.productId);
      return { ...item, product: product! };
    }).filter(item => item.product);
  }

  async addToCart(insertItem: InsertCartItem): Promise<CartItem> {
    // Check if item already exists
    const existingItem = Array.from(this.cartItems.values()).find(item =>
      item.productId === insertItem.productId &&
      ((insertItem.userId && item.userId === insertItem.userId) ||
       (insertItem.sessionId && item.sessionId === insertItem.sessionId))
    );

    if (existingItem) {
      existingItem.quantity += insertItem.quantity || 1;
      this.cartItems.set(existingItem.id, existingItem);
      return existingItem;
    }

    const cartItem: CartItem = {
      id: this.currentCartItemId++,
      ...insertItem,
      createdAt: new Date(),
    };
    this.cartItems.set(cartItem.id, cartItem);
    return cartItem;
  }

  async updateCartItem(id: number, quantity: number): Promise<void> {
    const item = this.cartItems.get(id);
    if (item) {
      if (quantity <= 0) {
        this.cartItems.delete(id);
      } else {
        item.quantity = quantity;
        this.cartItems.set(id, item);
      }
    }
  }

  async removeFromCart(id: number): Promise<void> {
    this.cartItems.delete(id);
  }

  async clearCart(userId?: number, sessionId?: string): Promise<void> {
    const itemsToDelete = Array.from(this.cartItems.entries()).filter(([, item]) =>
      (userId && item.userId === userId) || (sessionId && item.sessionId === sessionId)
    );
    
    itemsToDelete.forEach(([id]) => this.cartItems.delete(id));
  }

  // Wishlist
  async getWishlistItems(userId?: number, sessionId?: string): Promise<(WishlistItem & { product: Product })[]> {
    const items = Array.from(this.wishlistItems.values()).filter(item => {
      if (userId) {
        return item.userId === userId;
      }
      if (sessionId) {
        return item.sessionId === sessionId;
      }
      return false;
    });
    
    return items.map(item => {
      const product = this.products.get(item.productId);
      return { ...item, product: product! };
    }).filter(item => item.product);
  }

  async addToWishlist(insertItem: InsertWishlistItem): Promise<WishlistItem> {
    const wishlistItem: WishlistItem = {
      id: this.currentWishlistItemId++,
      ...insertItem,
      createdAt: new Date(),
    };
    this.wishlistItems.set(wishlistItem.id, wishlistItem);
    return wishlistItem;
  }

  async removeFromWishlist(id: number): Promise<void> {
    this.wishlistItems.delete(id);
  }

  // Orders
  async getOrders(userId?: number): Promise<Order[]> {
    if (userId) {
      return Array.from(this.orders.values()).filter(order => order.userId === userId);
    }
    return Array.from(this.orders.values());
  }

  async getOrder(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const order: Order = {
      id: this.currentOrderId++,
      ...insertOrder,
      createdAt: new Date(),
    };
    this.orders.set(order.id, order);
    return order;
  }

  async updateOrderStatus(id: number, status: string): Promise<void> {
    const order = this.orders.get(id);
    if (order) {
      order.status = status;
      this.orders.set(id, order);
    }
  }

  // Coupons
  async getCoupon(code: string): Promise<Coupon | undefined> {
    return Array.from(this.coupons.values()).find(coupon => coupon.code === code);
  }

  async createCoupon(insertCoupon: InsertCoupon): Promise<Coupon> {
    const coupon: Coupon = {
      id: this.currentCouponId++,
      ...insertCoupon,
      createdAt: new Date(),
    };
    this.coupons.set(coupon.id, coupon);
    return coupon;
  }
}

export const storage = new MemStorage();
