import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { chatbotService, type ChatMessage } from "./services/gemini";
import { paymentService } from "./services/payment";
import { insertCartItemSchema, insertWishlistItemSchema, insertOrderSchema, insertProductSchema, insertCategorySchema } from "@shared/schema";
import { authenticateToken, requireRole, requirePermission, type AuthRequest } from "./middleware/auth";
import { auditLog } from "./middleware/security";
import { addImportJob, getJobStatus } from "./services/queue";
import { emitNewOrder, emitLowStock, emitNotification } from "./services/socket";
import { z } from "zod";

// Session management for guests
const guestSessions = new Map<string, { id: string; createdAt: Date }>();

function getOrCreateGuestSession(sessionId?: string): string {
  if (sessionId) {
    // If session ID is provided, use it and register if not exists
    if (!guestSessions.has(sessionId)) {
      guestSessions.set(sessionId, { id: sessionId, createdAt: new Date() });
    }
    return sessionId;
  }
  
  // Only create new session if no session ID provided
  const newSessionId = `guest_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  guestSessions.set(newSessionId, { id: newSessionId, createdAt: new Date() });
  return newSessionId;
}

// WebSocket chat sessions
const chatSessions = new Map<string, ChatMessage[]>();

// Simple admin authentication middleware
function isAdmin(req: any, res: any, next: any) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  
  // Simple demo authentication - in production use proper JWT
  if (token === 'admin-demo-token') {
    req.user = { id: 1, role: 'admin' };
    next();
  } else {
    res.status(401).json({ message: 'Unauthorized' });
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for chat
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  wss.on('connection', (ws: WebSocket, req) => {
    console.log('New WebSocket connection');
    
    ws.on('message', async (data) => {
      try {
        const message = JSON.parse(data.toString());
        
        if (message.type === 'chat') {
          const sessionId = message.sessionId || 'default';
          const userMessage = message.message;
          
          // Get or create conversation history
          if (!chatSessions.has(sessionId)) {
            chatSessions.set(sessionId, []);
          }
          const history = chatSessions.get(sessionId)!;
          
          // Add user message to history
          const userChatMessage: ChatMessage = {
            role: 'user',
            content: userMessage,
            timestamp: new Date()
          };
          history.push(userChatMessage);
          
          // Generate AI response
          const response = await chatbotService.generateResponse(userMessage, history);
          
          // Add AI response to history
          const aiChatMessage: ChatMessage = {
            role: 'assistant',
            content: response.message,
            timestamp: new Date()
          };
          history.push(aiChatMessage);
          
          // Keep only last 20 messages to manage memory
          if (history.length > 20) {
            history.splice(0, history.length - 20);
          }
          
          chatSessions.set(sessionId, history);
          
          // Send response back to client
          if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({
              type: 'chat_response',
              message: response.message,
              suggestions: response.suggestions,
              productRecommendations: response.productRecommendations,
              timestamp: new Date().toISOString()
            }));
          }
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({
            type: 'error',
            message: 'Có lỗi xảy ra khi xử lý tin nhắn của bạn'
          }));
        }
      }
    });
    
    ws.on('close', () => {
      console.log('WebSocket connection closed');
    });
  });

  // API Routes

  // Categories
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch categories" });
    }
  });

  app.get("/api/categories/:slug", async (req, res) => {
    try {
      const category = await storage.getCategoryBySlug(req.params.slug);
      if (!category) {
        return res.status(404).json({ error: "Category not found" });
      }
      res.json(category);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch category" });
    }
  });

  // Products
  app.get("/api/products", async (req, res) => {
    try {
      const { limit = 20, offset = 0, category, featured, hot, search } = req.query;
      
      let products;
      if (search) {
        products = await storage.searchProducts(search as string);
      } else if (category) {
        const categoryObj = await storage.getCategoryBySlug(category as string);
        if (categoryObj) {
          products = await storage.getProductsByCategory(categoryObj.id);
        } else {
          products = [];
        }
      } else if (featured === 'true') {
        products = await storage.getFeaturedProducts();
      } else if (hot === 'true') {
        products = await storage.getHotProducts();
      } else {
        products = await storage.getProducts(Number(limit), Number(offset));
      }
      
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });

  app.get("/api/products/:slug", async (req, res) => {
    try {
      const product = await storage.getProductBySlug(req.params.slug);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch product" });
    }
  });

  // Cart
  app.get("/api/cart", async (req, res) => {
    try {
      const sessionId = req.headers['x-session-id'] as string;
      const guestSessionId = getOrCreateGuestSession(sessionId);
      
      const cartItems = await storage.getCartItems(undefined, guestSessionId);
      res.json(cartItems);
    } catch (error) {
      console.error('Failed to fetch cart items:', error);
      res.status(500).json({ error: "Failed to fetch cart items" });
    }
  });

  app.post("/api/cart", async (req, res) => {
    try {
      const sessionId = req.headers['x-session-id'] as string;
      const guestSessionId = getOrCreateGuestSession(sessionId);
      
      const validation = insertCartItemSchema.safeParse({
        ...req.body,
        sessionId: guestSessionId
      });
      
      if (!validation.success) {
        return res.status(400).json({ error: validation.error.errors });
      }
      
      const cartItem = await storage.addToCart(validation.data);
      res.json(cartItem);
    } catch (error) {
      console.error('Failed to add item to cart:', error);
      res.status(500).json({ error: "Failed to add item to cart" });
    }
  });

  app.put("/api/cart/:id", async (req, res) => {
    try {
      const { quantity } = req.body;
      const validation = z.object({ quantity: z.number().min(0) }).safeParse({ quantity });
      
      if (!validation.success) {
        return res.status(400).json({ error: "Invalid quantity" });
      }
      
      await storage.updateCartItem(Number(req.params.id), validation.data.quantity);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to update cart item" });
    }
  });

  app.delete("/api/cart/:id", async (req, res) => {
    try {
      await storage.removeFromCart(Number(req.params.id));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to remove cart item" });
    }
  });

  // Wishlist
  app.get("/api/wishlist", async (req, res) => {
    try {
      const sessionId = req.headers['x-session-id'] as string;
      const guestSessionId = getOrCreateGuestSession(sessionId);
      
      const wishlistItems = await storage.getWishlistItems(undefined, guestSessionId);
      res.json(wishlistItems);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch wishlist items" });
    }
  });

  app.post("/api/wishlist", async (req, res) => {
    try {
      const sessionId = req.headers['x-session-id'] as string;
      const guestSessionId = getOrCreateGuestSession(sessionId);
      
      const validation = insertWishlistItemSchema.safeParse({
        ...req.body,
        sessionId: guestSessionId
      });
      
      if (!validation.success) {
        return res.status(400).json({ error: validation.error.errors });
      }
      
      const wishlistItem = await storage.addToWishlist(validation.data);
      res.json(wishlistItem);
    } catch (error) {
      res.status(500).json({ error: "Failed to add item to wishlist" });
    }
  });

  app.delete("/api/wishlist/:id", async (req, res) => {
    try {
      await storage.removeFromWishlist(Number(req.params.id));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to remove wishlist item" });
    }
  });

  // Orders
  app.post("/api/orders", auditLog('create_order'), async (req, res) => {
    try {
      const sessionId = req.headers['x-session-id'] as string;
      const guestSessionId = getOrCreateGuestSession(sessionId);
      
      const validation = insertOrderSchema.safeParse({
        ...req.body,
        sessionId: guestSessionId
      });
      
      if (!validation.success) {
        return res.status(400).json({ error: validation.error.errors });
      }
      
      const order = await storage.createOrder(validation.data);
      
      // Emit new order notification to admin users
      emitNewOrder(order);
      
      // Clear cart after successful order
      await storage.clearCart(undefined, guestSessionId);
      
      res.json(order);
    } catch (error) {
      res.status(500).json({ error: "Failed to create order" });
    }
  });

  // Payment
  app.post("/api/payment/process", async (req, res) => {
    try {
      const { orderId, paymentMethod, amount, customerInfo } = req.body;
      
      const paymentRequest = {
        amount: Number(amount),
        currency: 'VND',
        paymentMethod,
        orderId,
        customerInfo,
        returnUrl: `${req.protocol}://${req.get('host')}/api/payment/vnpay/return`,
        cancelUrl: `${req.protocol}://${req.get('host')}/payment/cancel`
      };
      
      const result = await paymentService.processPayment(paymentRequest);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: "Failed to process payment" });
    }
  });

  // VNPay return URL handler
  app.get("/api/payment/vnpay/return", async (req, res) => {
    try {
      const vnpParams = req.query;
      const secureHash = vnpParams['vnp_SecureHash'];
      
      delete vnpParams['vnp_SecureHash'];
      delete vnpParams['vnp_SecureHashType'];
      
      // Sắp xếp tham số
      const sortedParams = Object.keys(vnpParams)
        .sort()
        .reduce((result: any, key) => {
          result[key] = vnpParams[key];
          return result;
        }, {});
      
      const signData = new URLSearchParams(sortedParams).toString();
      const crypto = require('crypto');
      const hmac = crypto.createHmac('sha512', process.env.VNP_HASH_SECRET || 'DEMO_SECRET');
      const signed = hmac.update(signData, 'utf-8').digest('hex');
      
      const orderId = vnpParams['vnp_TxnRef'];
      const responseCode = vnpParams['vnp_ResponseCode'];
      
      if (secureHash === signed) {
        if (responseCode === '00') {
          // Thanh toán thành công
          res.redirect(`/payment/success?orderId=${orderId}&status=success`);
        } else {
          // Thanh toán thất bại
          res.redirect(`/payment/failed?orderId=${orderId}&status=failed`);
        }
      } else {
        // Chữ ký không hợp lệ
        res.redirect(`/payment/failed?orderId=${orderId}&status=invalid`);
      }
    } catch (error) {
      console.error('VNPay return error:', error);
      res.redirect('/payment/failed?status=error');
    }
  });

  // Coupons
  app.get("/api/coupons/:code", async (req, res) => {
    try {
      const coupon = await storage.getCoupon(req.params.code);
      if (!coupon || !coupon.isActive) {
        return res.status(404).json({ error: "Coupon not found or inactive" });
      }
      res.json(coupon);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch coupon" });
    }
  });

  // Authentication routes
  app.post('/api/auth/register', async (req, res) => {
    try {
      const { email, password, firstName, lastName, phone } = req.body;
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ success: false, message: 'Email đã được sử dụng' });
      }

      // Create new user
      const newUser = await storage.createUser({
        email,
        password, // In production, hash the password
        fullName: `${firstName} ${lastName}`,
        phone,
        username: email
      });

      // Remove password from response
      const { password: _, ...userResponse } = newUser;
      res.json({ success: true, user: userResponse });
    } catch (error) {
      console.error('Registration error:', error);
      res.status(500).json({ success: false, message: 'Lỗi server' });
    }
  });

  app.post('/api/auth/login', async (req, res) => {
    try {
      const { email, password } = req.body;
      
      const user = await storage.validateUserCredentials(email, password);
      if (!user) {
        return res.status(401).json({ success: false, message: 'Email hoặc mật khẩu không đúng' });
      }

      // Generate simple token (in production, use JWT)
      const token = 'user-token-' + user.id + '-' + Date.now();
      
      // Remove password from response
      const { password: _, ...userResponse } = user;
      res.json({ success: true, user: userResponse, token });
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ success: false, message: 'Lỗi server' });
    }
  });

  // User profile routes
  app.get('/api/user/profile', async (req, res) => {
    try {
      const token = req.headers.authorization?.replace('Bearer ', '');
      if (!token || !token.startsWith('user-token-')) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const userId = parseInt(token.split('-')[2]);
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }

      const { password: _, ...userResponse } = user;
      res.json(userResponse);
    } catch (error) {
      console.error('Profile error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  });

  app.put('/api/user/profile', async (req, res) => {
    try {
      const token = req.headers.authorization?.replace('Bearer ', '');
      if (!token || !token.startsWith('user-token-')) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const userId = parseInt(token.split('-')[2]);
      const updatedUser = await storage.updateUser(userId, req.body);
      if (!updatedUser) {
        return res.status(404).json({ message: 'User not found' });
      }

      const { password: _, ...userResponse } = updatedUser;
      res.json({ success: true, user: userResponse });
    } catch (error) {
      console.error('Profile update error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  });

  app.get('/api/user/orders', async (req, res) => {
    try {
      const token = req.headers.authorization?.replace('Bearer ', '');
      if (!token || !token.startsWith('user-token-')) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const userId = parseInt(token.split('-')[2]);
      const orders = await storage.getOrders(userId);
      res.json(orders);
    } catch (error) {
      console.error('Orders error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  });

  // Admin authentication
  app.post("/api/admin/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      // Demo admin credentials
      if (username === 'admin' && password === 'admin123') {
        res.json({ 
          success: true, 
          token: 'admin-demo-token',
          user: { id: 1, username: 'admin', role: 'admin' }
        });
      } else {
        res.status(401).json({ success: false, message: 'Invalid credentials' });
      }
    } catch (error) {
      res.status(500).json({ error: "Login failed" });
    }
  });

  // Admin routes - protected
  app.get("/api/admin/users", isAdmin, async (req, res) => {
    try {
      // Get all users (excluding passwords)
      const allUsers = await storage.getUsers?.() || [];
      const usersWithoutPasswords = allUsers.map(({password, ...user}) => user);
      res.json(usersWithoutPasswords);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch users" });
    }
  });

  app.get("/api/admin/orders", isAdmin, async (req, res) => {
    try {
      const orders = await storage.getOrders();
      res.json(orders);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch orders" });
    }
  });

  app.post("/api/admin/products", isAdmin, async (req, res) => {
    try {
      const product = await storage.createProduct(req.body);
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: "Failed to create product" });
    }
  });

  app.put("/api/admin/products/:id", isAdmin, async (req, res) => {
    try {
      // For this demo, we'll update the product in memory
      const productId = Number(req.params.id);
      const product = await storage.getProduct(productId);
      
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }

      // Update product fields
      Object.assign(product, req.body);
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: "Failed to update product" });
    }
  });

  app.delete("/api/admin/products/:id", isAdmin, async (req, res) => {
    try {
      const productId = Number(req.params.id);
      // For this demo, we'll just return success
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete product" });
    }
  });

  app.post("/api/admin/products/bulk-import", isAdmin, async (req, res) => {
    try {
      const { products } = req.body;
      const importedProducts = [];
      
      for (const productData of products) {
        try {
          const product = await storage.createProduct(productData);
          importedProducts.push(product);
        } catch (error) {
          console.error('Failed to import product:', productData.name, error);
        }
      }
      
      res.json({ 
        success: true, 
        imported: importedProducts.length,
        total: products.length 
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to bulk import products" });
    }
  });

  // Admin Category Management Routes
  app.post("/api/admin/categories", isAdmin, async (req, res) => {
    try {
      const category = await storage.createCategory(req.body);
      res.json(category);
    } catch (error) {
      console.error('Failed to create category:', error);
      res.status(500).json({ error: "Failed to create category" });
    }
  });

  app.put("/api/admin/categories/:id", isAdmin, async (req, res) => {
    try {
      const categoryId = Number(req.params.id);
      const category = await storage.getCategory(categoryId);
      
      if (!category) {
        return res.status(404).json({ error: "Category not found" });
      }

      // Update category fields (simplified for MemStorage)
      Object.assign(category, req.body);
      res.json(category);
    } catch (error) {
      console.error('Failed to update category:', error);
      res.status(500).json({ error: "Failed to update category" });
    }
  });

  app.delete("/api/admin/categories/:id", isAdmin, async (req, res) => {
    try {
      const categoryId = Number(req.params.id);
      // Check if category has products
      const products = await storage.getProductsByCategory(categoryId);
      
      if (products.length > 0) {
        return res.status(400).json({ error: "Cannot delete category with existing products" });
      }

      // For MemStorage, we'll simulate deletion
      res.json({ success: true });
    } catch (error) {
      console.error('Failed to delete category:', error);
      res.status(500).json({ error: "Failed to delete category" });
    }
  });

  // Admin User Management Routes
  app.put("/api/admin/users/:id", isAdmin, async (req, res) => {
    try {
      const userId = Number(req.params.id);
      const updatedUser = await storage.updateUser(userId, req.body);
      
      if (!updatedUser) {
        return res.status(404).json({ error: "User not found" });
      }

      // Remove password from response
      const { password, ...userResponse } = updatedUser;
      res.json(userResponse);
    } catch (error) {
      console.error('Failed to update user:', error);
      res.status(500).json({ error: "Failed to update user" });
    }
  });

  app.delete("/api/admin/users/:id", isAdmin, async (req, res) => {
    try {
      const userId = Number(req.params.id);
      
      // Check if user has orders
      const userOrders = await storage.getOrders(userId);
      
      if (userOrders.length > 0) {
        return res.status(400).json({ error: "Cannot delete user with existing orders" });
      }

      // For MemStorage, we'll simulate deletion
      res.json({ success: true });
    } catch (error) {
      console.error('Failed to delete user:', error);
      res.status(500).json({ error: "Failed to delete user" });
    }
  });

  // Search suggestions
  app.get("/api/search/suggestions", async (req, res) => {
    try {
      const { q } = req.query;
      if (!q || typeof q !== 'string' || q.length < 2) {
        return res.json([]);
      }
      
      const products = await storage.searchProducts(q);
      const suggestions = products.slice(0, 5).map(p => ({
        id: p.id,
        name: p.name,
        price: p.price,
        imageUrl: p.imageUrl
      }));
      
      res.json(suggestions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch suggestions" });
    }
  });

  return httpServer;
}
