import type { Express } from 'express';
import { authenticateToken, requireRole, type AuthRequest } from '../middleware/auth';
import { auditLog } from '../middleware/security';
import { storage } from '../storage';

export function setupReportsRoutes(app: Express) {
  // Analytics endpoint
  app.get('/api/admin/analytics', authenticateToken, requireRole(['admin', 'manager']), auditLog('view_analytics'), async (req: AuthRequest, res) => {
    try {
      const range = req.query.range as string || '7d';
      
      // Get date range
      const endDate = new Date();
      const startDate = new Date();
      
      switch (range) {
        case '7d':
          startDate.setDate(endDate.getDate() - 7);
          break;
        case '30d':
          startDate.setDate(endDate.getDate() - 30);
          break;
        case '90d':
          startDate.setDate(endDate.getDate() - 90);
          break;
        case '1y':
          startDate.setFullYear(endDate.getFullYear() - 1);
          break;
      }

      // Get all data
      const products = await storage.getProducts();
      const orders = await storage.getOrders();
      const users = await storage.getUsers();

      // Calculate metrics
      const totalRevenue = orders.reduce((sum, order) => sum + order.total, 0);
      const totalOrders = orders.length;
      const totalProducts = products.length;
      const lowStockProducts = products.filter(p => p.stock < 10).length;
      const totalCustomers = users.filter(u => u.role !== 'admin').length;
      const newCustomers = users.filter(u => 
        u.role !== 'admin' && 
        new Date(u.createdAt) >= startDate
      ).length;

      // Generate chart data for revenue
      const revenueByDay = generateDailyData(startDate, endDate, orders, 'revenue');
      const ordersByDay = generateDailyData(startDate, endDate, orders, 'count');

      // Top selling products
      const topSelling = products
        .sort((a, b) => (b.soldCount || 0) - (a.soldCount || 0))
        .slice(0, 5);

      const analytics = {
        revenue: {
          total: totalRevenue,
          change: calculateChange(orders, startDate, 'revenue'),
          chartData: {
            labels: revenueByDay.labels,
            datasets: [{
              label: 'Doanh thu',
              data: revenueByDay.data,
              borderColor: 'rgb(59, 130, 246)',
              backgroundColor: 'rgba(59, 130, 246, 0.1)',
              tension: 0.4
            }]
          }
        },
        orders: {
          total: totalOrders,
          change: calculateChange(orders, startDate, 'count'),
          chartData: {
            labels: ordersByDay.labels,
            datasets: [{
              label: 'Đơn hàng',
              data: ordersByDay.data,
              backgroundColor: 'rgba(34, 197, 94, 0.8)',
              borderColor: 'rgb(34, 197, 94)',
              borderWidth: 1
            }]
          }
        },
        products: {
          total: totalProducts,
          lowStock: lowStockProducts,
          topSelling
        },
        customers: {
          total: totalCustomers,
          new: newCustomers
        }
      };

      res.json(analytics);
    } catch (error) {
      console.error('Analytics error:', error);
      res.status(500).json({ error: 'Failed to fetch analytics' });
    }
  });

  // Revenue report
  app.get('/api/admin/reports/revenue', authenticateToken, requireRole(['admin', 'manager']), auditLog('view_revenue_report'), async (req: AuthRequest, res) => {
    try {
      const { startDate, endDate, groupBy = 'day' } = req.query;
      
      const orders = await storage.getOrders();
      const filteredOrders = orders.filter(order => {
        const orderDate = new Date(order.createdAt);
        return (!startDate || orderDate >= new Date(startDate as string)) &&
               (!endDate || orderDate <= new Date(endDate as string));
      });

      const report = generateRevenueReport(filteredOrders, groupBy as string);
      res.json(report);
    } catch (error) {
      res.status(500).json({ error: 'Failed to generate revenue report' });
    }
  });
}

function generateDailyData(startDate: Date, endDate: Date, orders: any[], type: 'revenue' | 'count') {
  const labels: string[] = [];
  const data: number[] = [];
  
  const currentDate = new Date(startDate);
  
  while (currentDate <= endDate) {
    const dayOrders = orders.filter(order => {
      const orderDate = new Date(order.createdAt);
      return orderDate.toDateString() === currentDate.toDateString();
    });
    
    labels.push(currentDate.toLocaleDateString('vi-VN', { month: 'short', day: 'numeric' }));
    
    if (type === 'revenue') {
      data.push(dayOrders.reduce((sum, order) => sum + order.total, 0));
    } else {
      data.push(dayOrders.length);
    }
    
    currentDate.setDate(currentDate.getDate() + 1);
  }
  
  return { labels, data };
}

function calculateChange(orders: any[], startDate: Date, type: 'revenue' | 'count'): number {
  const periodLength = Date.now() - startDate.getTime();
  const previousPeriodStart = new Date(startDate.getTime() - periodLength);
  
  const currentPeriod = orders.filter(order => 
    new Date(order.createdAt) >= startDate
  );
  
  const previousPeriod = orders.filter(order => {
    const orderDate = new Date(order.createdAt);
    return orderDate >= previousPeriodStart && orderDate < startDate;
  });
  
  let currentValue, previousValue;
  
  if (type === 'revenue') {
    currentValue = currentPeriod.reduce((sum, order) => sum + order.total, 0);
    previousValue = previousPeriod.reduce((sum, order) => sum + order.total, 0);
  } else {
    currentValue = currentPeriod.length;
    previousValue = previousPeriod.length;
  }
  
  if (previousValue === 0) return currentValue > 0 ? 100 : 0;
  
  return Math.round(((currentValue - previousValue) / previousValue) * 100);
}

function generateRevenueReport(orders: any[], groupBy: string) {
  const grouped: { [key: string]: { revenue: number; orders: number } } = {};
  
  orders.forEach(order => {
    const date = new Date(order.createdAt);
    let key: string;
    
    switch (groupBy) {
      case 'day':
        key = date.toDateString();
        break;
      case 'week':
        const weekStart = new Date(date);
        weekStart.setDate(date.getDate() - date.getDay());
        key = weekStart.toDateString();
        break;
      case 'month':
        key = `${date.getFullYear()}-${date.getMonth() + 1}`;
        break;
      default:
        key = date.toDateString();
    }
    
    if (!grouped[key]) {
      grouped[key] = { revenue: 0, orders: 0 };
    }
    
    grouped[key].revenue += order.total;
    grouped[key].orders += 1;
  });
  
  return Object.entries(grouped)
    .map(([period, data]) => ({
      period,
      revenue: data.revenue,
      orders: data.orders,
      averageOrderValue: data.orders > 0 ? data.revenue / data.orders : 0
    }))
    .sort((a, b) => new Date(a.period).getTime() - new Date(b.period).getTime());
}