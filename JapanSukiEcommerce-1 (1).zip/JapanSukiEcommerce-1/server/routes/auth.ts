import type { Express } from 'express';
import bcrypt from 'bcryptjs';
import { generateTokens, verifyRefreshToken, authenticateToken, type AuthRequest } from '../middleware/auth';
import { auditLog } from '../middleware/security';
import { storage } from '../storage';

export function setupAuthRoutes(app: Express) {
  // Login endpoint
  app.post('/api/auth/login', auditLog('login'), async (req, res) => {
    try {
      const { email, password } = req.body;

      if (!email || !password) {
        return res.status(400).json({ message: 'Email and password required' });
      }

      // Get user from storage
      const user = await storage.getUserByEmail(email);
      if (!user || !user.isActive) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }

      // Verify password (in production, use bcrypt.compare)
      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }

      // Generate tokens
      const { accessToken, refreshToken } = generateTokens({
        id: user.id,
        username: user.username,
        role: user.role || 'viewer'
      });

      // Set refresh token as httpOnly cookie
      res.cookie('refreshToken', refreshToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
      });

      res.json({
        success: true,
        accessToken,
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          role: user.role || 'viewer',
          fullName: user.fullName
        }
      });

    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  // Refresh token endpoint
  app.post('/api/auth/refresh', auditLog('token_refresh'), async (req, res) => {
    try {
      const refreshToken = req.cookies.refreshToken;
      
      if (!refreshToken) {
        return res.status(401).json({ message: 'Refresh token required' });
      }

      const decoded = verifyRefreshToken(refreshToken);
      const user = await storage.getUser(decoded.id);
      
      if (!user || !user.isActive) {
        return res.status(401).json({ message: 'Invalid refresh token' });
      }

      // Generate new access token
      const { accessToken } = generateTokens({
        id: user.id,
        username: user.username,
        role: user.role || 'viewer'
      });

      res.json({
        success: true,
        accessToken,
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          role: user.role || 'viewer',
          fullName: user.fullName
        }
      });

    } catch (error) {
      console.error('Token refresh error:', error);
      res.status(401).json({ message: 'Invalid refresh token' });
    }
  });

  // Logout endpoint
  app.post('/api/auth/logout', authenticateToken, auditLog('logout'), (req: AuthRequest, res) => {
    // Clear refresh token cookie
    res.clearCookie('refreshToken');
    res.json({ success: true, message: 'Logged out successfully' });
  });

  // Get current user profile
  app.get('/api/auth/me', authenticateToken, async (req: AuthRequest, res) => {
    try {
      const user = await storage.getUser(req.user!.id);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }

      res.json({
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role || 'viewer',
        fullName: user.fullName
      });
    } catch (error) {
      console.error('Get profile error:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
}