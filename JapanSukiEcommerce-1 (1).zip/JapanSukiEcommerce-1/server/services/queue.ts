import { Queue, Worker } from 'bullmq';
import Redis from 'ioredis';
import { storage } from '../storage';

// Redis connection
const redisConnection = new Redis({
  host: process.env.REDIS_HOST || 'localhost',
  port: parseInt(process.env.REDIS_PORT || '6379'),
  maxRetriesPerRequest: 3,
  lazyConnect: true
});

// Import queue for processing bulk data imports
export const importQueue = new Queue('import', { 
  connection: redisConnection,
  defaultJobOptions: {
    removeOnComplete: 10,
    removeOnFail: 5,
    attempts: 3,
    backoff: {
      type: 'exponential',
      delay: 2000
    }
  }
});

// Worker to process import jobs
const importWorker = new Worker('import', async (job) => {
  const { type, data, userId } = job.data;
  
  try {
    switch (type) {
      case 'products':
        return await processProductImport(data, userId);
      case 'categories':
        return await processCategoryImport(data, userId);
      case 'users':
        return await processUserImport(data, userId);
      default:
        throw new Error(`Unknown import type: ${type}`);
    }
  } catch (error) {
    console.error('Import job failed:', error);
    throw error;
  }
}, { 
  connection: redisConnection,
  concurrency: 2
});

async function processProductImport(products: any[], userId: number) {
  const results = {
    success: 0,
    failed: 0,
    errors: [] as string[]
  };

  for (const productData of products) {
    try {
      await storage.createProduct({
        ...productData,
        createdBy: userId
      });
      results.success++;
    } catch (error) {
      results.failed++;
      results.errors.push(`Product ${productData.name}: ${error}`);
    }
  }

  return results;
}

async function processCategoryImport(categories: any[], userId: number) {
  const results = {
    success: 0,
    failed: 0,
    errors: [] as string[]
  };

  for (const categoryData of categories) {
    try {
      await storage.createCategory({
        ...categoryData,
        createdBy: userId
      });
      results.success++;
    } catch (error) {
      results.failed++;
      results.errors.push(`Category ${categoryData.name}: ${error}`);
    }
  }

  return results;
}

async function processUserImport(users: any[], userId: number) {
  const results = {
    success: 0,
    failed: 0,
    errors: [] as string[]
  };

  for (const userData of users) {
    try {
      await storage.createUser({
        ...userData,
        createdBy: userId
      });
      results.success++;
    } catch (error) {
      results.failed++;
      results.errors.push(`User ${userData.email}: ${error}`);
    }
  }

  return results;
}

// Add import job
export async function addImportJob(type: string, data: any[], userId: number) {
  const job = await importQueue.add('import', {
    type,
    data,
    userId,
    timestamp: new Date().toISOString()
  });

  return job.id;
}

// Get job status
export async function getJobStatus(jobId: string) {
  const job = await importQueue.getJob(jobId);
  if (!job) return null;

  return {
    id: job.id,
    name: job.name,
    data: job.data,
    progress: job.progress,
    processedOn: job.processedOn,
    finishedOn: job.finishedOn,
    failedReason: job.failedReason,
    returnvalue: job.returnvalue
  };
}

export { redisConnection };