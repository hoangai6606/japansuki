import { Server as SocketIOServer } from 'socket.io';
import type { Server } from 'http';
import { verifyToken } from '../middleware/auth';

let io: SocketIOServer;

export function initializeSocket(server: Server) {
  io = new SocketIOServer(server, {
    cors: {
      origin: process.env.CLIENT_URL || "http://localhost:3000",
      methods: ["GET", "POST"]
    },
    path: '/socket.io'
  });

  // Authentication middleware for socket connections
  io.use((socket, next) => {
    const token = socket.handshake.auth.token;
    
    if (!token) {
      return next(new Error('Authentication error: No token provided'));
    }

    try {
      const decoded = verifyToken(token);
      socket.data.user = decoded;
      next();
    } catch (error) {
      next(new Error('Authentication error: Invalid token'));
    }
  });

  io.on('connection', (socket) => {
    console.log(`User ${socket.data.user?.username} connected via Socket.IO`);

    // Join user to their role-based room
    socket.join(socket.data.user.role);
    
    // Join admin users to admin room
    if (socket.data.user.role === 'admin') {
      socket.join('admin');
    }

    socket.on('disconnect', () => {
      console.log(`User ${socket.data.user?.username} disconnected from Socket.IO`);
    });

    // Handle real-time notifications subscription
    socket.on('subscribe-notifications', () => {
      socket.join('notifications');
    });

    socket.on('unsubscribe-notifications', () => {
      socket.leave('notifications');
    });
  });

  return io;
}

// Emit new order notification
export function emitNewOrder(orderData: any) {
  if (io) {
    io.to('admin').emit('newOrder', {
      type: 'newOrder',
      data: orderData,
      timestamp: new Date().toISOString()
    });
  }
}

// Emit low stock alert
export function emitLowStock(productData: any) {
  if (io) {
    io.to('admin').to('manager').emit('lowStock', {
      type: 'lowStock',
      data: productData,
      timestamp: new Date().toISOString()
    });
  }
}

// Emit import job status update
export function emitImportStatus(jobId: string, status: any, userId?: number) {
  if (io) {
    if (userId) {
      // Send to specific user
      io.to('admin').emit('importStatus', {
        type: 'importStatus',
        jobId,
        status,
        timestamp: new Date().toISOString()
      });
    } else {
      // Broadcast to all admin users
      io.to('admin').emit('importStatus', {
        type: 'importStatus',
        jobId,
        status,
        timestamp: new Date().toISOString()
      });
    }
  }
}

// Emit general notification
export function emitNotification(message: string, type: 'info' | 'success' | 'warning' | 'error' = 'info', rooms: string[] = ['notifications']) {
  if (io) {
    rooms.forEach(room => {
      io.to(room).emit('notification', {
        type: 'notification',
        message,
        level: type,
        timestamp: new Date().toISOString()
      });
    });
  }
}

export { io };