import helmet from 'helmet';
import csrf from 'csurf';
import morgan from 'morgan';
import winston from 'winston';
import type { Express } from 'express';

// Configure Winston logger for audit logs
export const auditLogger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  defaultMeta: { service: 'japansuki-audit' },
  transports: [
    new winston.transports.File({ 
      filename: 'logs/audit.log',
      maxsize: 10485760, // 10MB
      maxFiles: 5
    }),
    new winston.transports.Console({
      format: winston.format.simple()
    })
  ]
});

// Audit middleware to log user actions
export function auditLog(action: string) {
  return (req: any, res: any, next: any) => {
    const originalSend = res.send;
    
    res.send = function(data: any) {
      const logData = {
        timestamp: new Date().toISOString(),
        action,
        user: req.user || 'anonymous',
        ip: req.ip || req.connection.remoteAddress,
        userAgent: req.get('User-Agent'),
        method: req.method,
        url: req.originalUrl,
        body: req.method !== 'GET' ? req.body : undefined,
        statusCode: res.statusCode
      };
      
      auditLogger.info('User action', logData);
      return originalSend.call(this, data);
    };
    
    next();
  };
}

// Security middleware setup
export function setupSecurity(app: Express) {
  // Helmet for security headers
  app.use(helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
        fontSrc: ["'self'", "https://fonts.gstatic.com"],
        imgSrc: ["'self'", "data:", "https:", "blob:"],
        scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
        connectSrc: ["'self'", "ws:", "wss:"]
      }
    },
    crossOriginEmbedderPolicy: false
  }));

  // Morgan for HTTP request logging
  app.use(morgan('combined', {
    stream: {
      write: (message: string) => {
        auditLogger.info(message.trim());
      }
    }
  }));

  // CSRF protection (disabled for API endpoints, enabled for forms)
  const csrfProtection = csrf({ 
    cookie: {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict'
    }
  });

  // Apply CSRF to form endpoints only
  app.use('/admin/forms', csrfProtection);
  
  // CSRF token endpoint
  app.get('/api/csrf-token', csrfProtection, (req, res) => {
    res.json({ csrfToken: req.csrfToken() });
  });
}