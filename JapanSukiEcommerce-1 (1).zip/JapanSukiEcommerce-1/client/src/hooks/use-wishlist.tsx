import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { sessionManager, type WishlistItem } from '@/lib/types';

export interface UseWishlistReturn {
  items: WishlistItem[];
  isLoading: boolean;
  itemCount: number;
  isInWishlist: (productId: number) => boolean;
  addItem: (productId: number) => Promise<void>;
  removeItem: (productId: number) => Promise<void>;
  toggleItem: (productId: number) => Promise<void>;
}

export function useWishlist(): UseWishlistReturn {
  const queryClient = useQueryClient();
  const sessionId = sessionManager.getSessionId();

  const { data: items = [], isLoading } = useQuery({
    queryKey: ['/api/wishlist'],
    queryFn: async () => {
      const response = await fetch('/api/wishlist', {
        headers: {
          'X-Session-ID': sessionId
        }
      });
      if (!response.ok) {
        throw new Error('Failed to fetch wishlist');
      }
      return response.json();
    }
  });

  const addItemMutation = useMutation({
    mutationFn: async (productId: number) => {
      const response = await apiRequest('POST', '/api/wishlist', { productId });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/wishlist'] });
    }
  });

  const removeItemMutation = useMutation({
    mutationFn: async (productId: number) => {
      const item = items.find((item: WishlistItem) => item.productId === productId);
      if (item) {
        const response = await apiRequest('DELETE', `/api/wishlist/${item.id}`);
        return response.json();
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/wishlist'] });
    }
  });

  const itemCount = items.length;
  
  const isInWishlist = (productId: number): boolean => {
    return items.some((item: WishlistItem) => item.productId === productId);
  };

  const toggleItem = async (productId: number) => {
    if (isInWishlist(productId)) {
      await removeItemMutation.mutateAsync(productId);
    } else {
      await addItemMutation.mutateAsync(productId);
    }
  };

  return {
    items,
    isLoading,
    itemCount,
    isInWishlist,
    addItem: async (productId: number) => {
      await addItemMutation.mutateAsync(productId);
    },
    removeItem: async (productId: number) => {
      await removeItemMutation.mutateAsync(productId);
    },
    toggleItem
  };
}
