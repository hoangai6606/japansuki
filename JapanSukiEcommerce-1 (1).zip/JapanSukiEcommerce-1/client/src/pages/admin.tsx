import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  Package, 
  Users, 
  ShoppingCart, 
  TrendingUp,
  Plus,
  Edit,
  Trash,
  Trash2,
  LogOut,
  Upload,
  BarChart,
  Search,
  Bell
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import BulkImport from '@/components/admin/bulk-import';
import NotificationCenter from '@/components/admin/notification-center';
import AnalyticsDashboard from '@/components/admin/analytics-dashboard';
import SearchBar from '@/components/admin/search-bar';
import type { Product, Category } from '@/lib/types';

export default function AdminDashboard() {
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [showProductDialog, setShowProductDialog] = useState(false);
  const [showCategoryDialog, setShowCategoryDialog] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Check admin authentication
  useEffect(() => {
    const token = localStorage.getItem('adminToken');
    if (!token) {
      setLocation('/admin/login');
    }
  }, [setLocation]);

  // Fetch data
  const { data: products = [], isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });

  const { data: categories = [], isLoading: categoriesLoading } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  const { data: orders = [], isLoading: ordersLoading } = useQuery<any[]>({
    queryKey: ['/api/admin/orders'],
  });

  const { data: users = [], isLoading: usersLoading } = useQuery<any[]>({
    queryKey: ['/api/admin/users'],
  });

  // Mutations
  const createProductMutation = useMutation({
    mutationFn: async (productData: any) => {
      const response = await fetch('/api/admin/products', {
        method: 'POST',
        body: JSON.stringify(productData),
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('adminToken')}`
        }
      });
      if (!response.ok) throw new Error('Failed to create product');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      setShowProductDialog(false);
      setEditingProduct(null);
      toast({ title: "Thành công", description: "Sản phẩm đã được tạo" });
    },
  });

  const updateProductMutation = useMutation({
    mutationFn: async ({ id, ...productData }: any) => {
      const response = await fetch(`/api/admin/products/${id}`, {
        method: 'PUT',
        body: JSON.stringify(productData),
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('adminToken')}`
        }
      });
      if (!response.ok) throw new Error('Failed to update product');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      setShowProductDialog(false);
      setEditingProduct(null);
      toast({ title: "Thành công", description: "Sản phẩm đã được cập nhật" });
    },
  });

  const deleteProductMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/admin/products/${id}`, {
        method: 'DELETE',
        headers: { 
          'Authorization': `Bearer ${localStorage.getItem('adminToken')}`
        }
      });
      if (!response.ok) throw new Error('Failed to delete product');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      toast({ title: "Thành công", description: "Sản phẩm đã được xóa" });
    },
  });

  // Category mutations
  const createCategoryMutation = useMutation({
    mutationFn: async (categoryData: any) => {
      const response = await fetch('/api/admin/categories', {
        method: 'POST',
        body: JSON.stringify(categoryData),
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('adminToken')}`
        }
      });
      if (!response.ok) throw new Error('Failed to create category');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/categories'] });
      setShowCategoryDialog(false);
      setEditingCategory(null);
      toast({ title: "Thành công", description: "Danh mục đã được tạo" });
    },
  });

  const updateCategoryMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      const response = await fetch(`/api/admin/categories/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data),
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('adminToken')}`
        }
      });
      if (!response.ok) throw new Error('Failed to update category');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/categories'] });
      setShowCategoryDialog(false);
      setEditingCategory(null);
      toast({ title: "Thành công", description: "Danh mục đã được cập nhật" });
    },
  });

  const deleteCategoryMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/admin/categories/${id}`, {
        method: 'DELETE',
        headers: { 
          'Authorization': `Bearer ${localStorage.getItem('adminToken')}`
        }
      });
      if (!response.ok) throw new Error('Failed to delete category');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/categories'] });
      toast({ title: "Thành công", description: "Danh mục đã được xóa" });
    },
  });

  // User mutations
  const updateUserMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      const response = await fetch(`/api/admin/users/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data),
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('adminToken')}`
        }
      });
      if (!response.ok) throw new Error('Failed to update user');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/users'] });
      toast({ title: "Thành công", description: "Tài khoản đã được cập nhật" });
    },
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/admin/users/${id}`, {
        method: 'DELETE',
        headers: { 
          'Authorization': `Bearer ${localStorage.getItem('adminToken')}`
        }
      });
      if (!response.ok) throw new Error('Failed to delete user');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/users'] });
      toast({ title: "Thành công", description: "Tài khoản đã được xóa" });
    },
  });

  const logout = () => {
    localStorage.removeItem('adminToken');
    setLocation('/admin/login');
  };

  const handleProductSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const productData = {
      name: formData.get('name'),
      slug: formData.get('slug'),
      description: formData.get('description'),
      shortDescription: formData.get('shortDescription'),
      price: formData.get('price'),
      originalPrice: formData.get('originalPrice'),
      stock: parseInt(formData.get('stock') as string),
      categoryId: parseInt(formData.get('categoryId') as string),
      brand: formData.get('brand'),
      weight: formData.get('weight'),
      origin: formData.get('origin'),
      imageUrl: formData.get('imageUrl'),
      isFeatured: formData.get('isFeatured') === 'true',
      isHot: formData.get('isHot') === 'true',
    };

    if (editingProduct) {
      updateProductMutation.mutate({ id: editingProduct.id, ...productData });
    } else {
      createProductMutation.mutate(productData);
    }
  };

  const handleCategorySubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const categoryData = {
      name: formData.get('name'),
      slug: formData.get('slug'),
      description: formData.get('description'),
      icon: formData.get('icon'),
      imageUrl: formData.get('imageUrl'),
      parentId: formData.get('parentId') && formData.get('parentId') !== 'none' ? parseInt(formData.get('parentId') as string) : null,
    };

    if (editingCategory) {
      updateCategoryMutation.mutate({ id: editingCategory.id, data: categoryData });
    } else {
      createCategoryMutation.mutate(categoryData);
    }
  };

  const handleUserUpdate = (userId: number, userData: any) => {
    updateUserMutation.mutate({ id: userId, data: userData });
  };

  // Dashboard stats
  const totalProducts = Array.isArray(products) ? products.length : 0;
  const totalOrders = Array.isArray(orders) ? orders.length : 0;
  const totalUsers = Array.isArray(users) ? users.length : 0;
  const totalRevenue = Array.isArray(orders) ? orders.reduce((sum: number, order: any) => sum + parseFloat(order.total || '0'), 0) : 0;

  if (productsLoading || categoriesLoading) {
    return <div className="flex items-center justify-center h-screen">Đang tải...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="flex items-center justify-between px-6 py-4">
          <h1 className="text-2xl font-bold text-gray-900">Quản trị JapanSuki</h1>
          <div className="flex items-center space-x-4">
            <span className="text-sm text-gray-600">Xin chào, Admin</span>
            <Button onClick={logout} variant="outline" size="sm">
              <LogOut className="w-4 h-4 mr-2" />
              Đăng xuất
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="p-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="dashboard">Tổng quan</TabsTrigger>
            <TabsTrigger value="products">Sản phẩm</TabsTrigger>
            <TabsTrigger value="import">Import</TabsTrigger>
            <TabsTrigger value="categories">Danh mục</TabsTrigger>
            <TabsTrigger value="orders">Đơn hàng</TabsTrigger>
            <TabsTrigger value="users">Người dùng</TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Tổng sản phẩm</CardTitle>
                  <Package className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{totalProducts}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Tổng đơn hàng</CardTitle>
                  <ShoppingCart className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{totalOrders}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Tổng người dùng</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{totalUsers}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Doanh thu</CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{totalRevenue.toLocaleString()}đ</div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Orders */}
            <Card>
              <CardHeader>
                <CardTitle>Đơn hàng gần đây</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Tổng tiền</TableHead>
                      <TableHead>Trạng thái</TableHead>
                      <TableHead>Ngày tạo</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {orders.slice(0, 5).map((order: any) => (
                      <TableRow key={order.id}>
                        <TableCell>#{order.id}</TableCell>
                        <TableCell>{parseFloat(order.total).toLocaleString()}đ</TableCell>
                        <TableCell>
                          <Badge variant={order.status === 'completed' ? 'default' : 'secondary'}>
                            {order.status}
                          </Badge>
                        </TableCell>
                        <TableCell>{new Date(order.createdAt).toLocaleDateString('vi-VN')}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Products Tab */}
          <TabsContent value="products" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Quản lý sản phẩm</h2>
              <Dialog open={showProductDialog} onOpenChange={setShowProductDialog}>
                <DialogTrigger asChild>
                  <Button onClick={() => setEditingProduct(null)}>
                    <Plus className="w-4 h-4 mr-2" />
                    Thêm sản phẩm
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>
                      {editingProduct ? 'Sửa sản phẩm' : 'Thêm sản phẩm mới'}
                    </DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleProductSubmit} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="name">Tên sản phẩm</Label>
                        <Input 
                          id="name" 
                          name="name" 
                          defaultValue={editingProduct?.name || ''} 
                          required 
                        />
                      </div>
                      <div>
                        <Label htmlFor="slug">Slug</Label>
                        <Input 
                          id="slug" 
                          name="slug" 
                          defaultValue={editingProduct?.slug || ''} 
                          required 
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="description">Mô tả chi tiết</Label>
                      <Textarea 
                        id="description" 
                        name="description" 
                        defaultValue={editingProduct?.description || ''} 
                      />
                    </div>

                    <div>
                      <Label htmlFor="shortDescription">Mô tả ngắn</Label>
                      <Input 
                        id="shortDescription" 
                        name="shortDescription" 
                        defaultValue={editingProduct?.shortDescription || ''} 
                      />
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <Label htmlFor="price">Giá bán</Label>
                        <Input 
                          id="price" 
                          name="price" 
                          type="number" 
                          defaultValue={editingProduct?.price || ''} 
                          required 
                        />
                      </div>
                      <div>
                        <Label htmlFor="originalPrice">Giá gốc</Label>
                        <Input 
                          id="originalPrice" 
                          name="originalPrice" 
                          type="number" 
                          defaultValue={editingProduct?.originalPrice || ''} 
                        />
                      </div>
                      <div>
                        <Label htmlFor="stock">Tồn kho</Label>
                        <Input 
                          id="stock" 
                          name="stock" 
                          type="number" 
                          defaultValue={editingProduct?.stock || 0} 
                          required 
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="categoryId">Danh mục</Label>
                        <Select name="categoryId" defaultValue={editingProduct?.categoryId?.toString()}>
                          <SelectTrigger>
                            <SelectValue placeholder="Chọn danh mục" />
                          </SelectTrigger>
                          <SelectContent>
                            {categories.map((category: Category) => (
                              <SelectItem key={category.id} value={category.id.toString()}>
                                {category.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="brand">Thương hiệu</Label>
                        <Input 
                          id="brand" 
                          name="brand" 
                          defaultValue={editingProduct?.brand || ''} 
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <Label htmlFor="weight">Khối lượng</Label>
                        <Input 
                          id="weight" 
                          name="weight" 
                          defaultValue={editingProduct?.weight || ''} 
                        />
                      </div>
                      <div>
                        <Label htmlFor="origin">Xuất xứ</Label>
                        <Input 
                          id="origin" 
                          name="origin" 
                          defaultValue={editingProduct?.origin || 'Nhật Bản'} 
                        />
                      </div>
                      <div>
                        <Label htmlFor="imageUrl">URL hình ảnh</Label>
                        <Input 
                          id="imageUrl" 
                          name="imageUrl" 
                          defaultValue={editingProduct?.imageUrl || ''} 
                        />
                      </div>
                    </div>

                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <input 
                          type="checkbox" 
                          id="isFeatured" 
                          name="isFeatured" 
                          value="true"
                          defaultChecked={editingProduct?.isFeatured || false} 
                        />
                        <Label htmlFor="isFeatured">Sản phẩm nổi bật</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input 
                          type="checkbox" 
                          id="isHot" 
                          name="isHot" 
                          value="true"
                          defaultChecked={editingProduct?.isHot || false} 
                        />
                        <Label htmlFor="isHot">Sản phẩm hot</Label>
                      </div>
                    </div>

                    <DialogFooter>
                      <Button type="submit" disabled={createProductMutation.isPending || updateProductMutation.isPending}>
                        {editingProduct ? 'Cập nhật' : 'Tạo mới'}
                      </Button>
                    </DialogFooter>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            <Card>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Hình ảnh</TableHead>
                      <TableHead>Tên sản phẩm</TableHead>
                      <TableHead>Danh mục</TableHead>
                      <TableHead>Giá</TableHead>
                      <TableHead>Tồn kho</TableHead>
                      <TableHead>Trạng thái</TableHead>
                      <TableHead>Thao tác</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {products.map((product: Product) => (
                      <TableRow key={product.id}>
                        <TableCell>
                          <img 
                            src={product.imageUrl || '/placeholder.jpg'} 
                            alt={product.name}
                            className="w-12 h-12 object-cover rounded"
                          />
                        </TableCell>
                        <TableCell className="font-medium">{product.name}</TableCell>
                        <TableCell>
                          {categories.find((c: Category) => c.id === product.categoryId)?.name}
                        </TableCell>
                        <TableCell>{parseFloat(product.price).toLocaleString()}đ</TableCell>
                        <TableCell>{product.stock}</TableCell>
                        <TableCell>
                          <div className="flex space-x-1">
                            {product.isFeatured && <Badge variant="secondary">Nổi bật</Badge>}
                            {product.isHot && <Badge variant="destructive">Hot</Badge>}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setEditingProduct(product);
                                setShowProductDialog(true);
                              }}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => deleteProductMutation.mutate(product.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Import Tab */}
          <TabsContent value="import">
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">Import sản phẩm</h2>
              <BulkImport onSuccess={() => queryClient.invalidateQueries({ queryKey: ['/api/products'] })} />
            </div>
          </TabsContent>

          {/* Other tabs content (Categories, Orders, Users) would be similar */}
          <TabsContent value="categories" className="space-y-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-7">
                <div>
                  <CardTitle>Quản lý danh mục</CardTitle>
                  <CardDescription>Danh sách các danh mục sản phẩm</CardDescription>
                </div>
                <Dialog open={showCategoryDialog} onOpenChange={setShowCategoryDialog}>
                  <DialogTrigger asChild>
                    <Button onClick={() => { setEditingCategory(null); setShowCategoryDialog(true); }}>
                      <Plus className="w-4 h-4 mr-2" />
                      Thêm danh mục
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[600px]">
                    <DialogHeader>
                      <DialogTitle>{editingCategory ? 'Chỉnh sửa danh mục' : 'Thêm danh mục mới'}</DialogTitle>
                    </DialogHeader>
                    <form onSubmit={handleCategorySubmit} className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="category-name">Tên danh mục</Label>
                          <Input 
                            id="category-name" 
                            name="name" 
                            defaultValue={editingCategory?.name || ''} 
                            required 
                          />
                        </div>
                        <div>
                          <Label htmlFor="category-slug">Slug</Label>
                          <Input 
                            id="category-slug" 
                            name="slug" 
                            defaultValue={editingCategory?.slug || ''} 
                            required 
                          />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="category-description">Mô tả</Label>
                        <Textarea 
                          id="category-description" 
                          name="description" 
                          defaultValue={editingCategory?.description || ''} 
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="category-icon">Icon</Label>
                          <Input 
                            id="category-icon" 
                            name="icon" 
                            defaultValue={editingCategory?.icon || ''} 
                            placeholder="🍜" 
                          />
                        </div>
                        <div>
                          <Label htmlFor="category-image">URL hình ảnh</Label>
                          <Input 
                            id="category-image" 
                            name="imageUrl" 
                            defaultValue={editingCategory?.imageUrl || ''} 
                            type="url" 
                          />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="category-parent">Danh mục cha</Label>
                        <Select name="parentId" defaultValue={editingCategory?.parentId?.toString() || 'none'}>
                          <SelectTrigger>
                            <SelectValue placeholder="Chọn danh mục cha (tùy chọn)" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none">Không có danh mục cha</SelectItem>
                            {categories.filter((cat: Category) => cat.id !== editingCategory?.id).map((category: Category) => (
                              <SelectItem key={category.id} value={category.id.toString()}>
                                {category.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <DialogFooter>
                        <Button type="submit" disabled={createCategoryMutation.isPending || updateCategoryMutation.isPending}>
                          {editingCategory ? 'Cập nhật' : 'Tạo danh mục'}
                        </Button>
                      </DialogFooter>
                    </form>
                  </DialogContent>
                </Dialog>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Tên danh mục</TableHead>
                      <TableHead>Slug</TableHead>
                      <TableHead>Mô tả</TableHead>
                      <TableHead>Icon</TableHead>
                      <TableHead>Thao tác</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {categories.map((category: Category) => (
                      <TableRow key={category.id}>
                        <TableCell>{category.id}</TableCell>
                        <TableCell className="font-medium">{category.name}</TableCell>
                        <TableCell className="text-sm text-gray-500">{category.slug}</TableCell>
                        <TableCell className="max-w-xs truncate">{category.description}</TableCell>
                        <TableCell className="text-lg">{category.icon}</TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setEditingCategory(category);
                                setShowCategoryDialog(true);
                              }}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => deleteCategoryMutation.mutate(category.id)}
                              disabled={deleteCategoryMutation.isPending}
                            >
                              <Trash className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="orders" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Quản lý đơn hàng</CardTitle>
                <CardDescription>Danh sách tất cả đơn hàng</CardDescription>
              </CardHeader>
              <CardContent>
                {ordersLoading ? (
                  <div>Đang tải đơn hàng...</div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    Chưa có đơn hàng nào trong hệ thống
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Quản lý người dùng</CardTitle>
                <CardDescription>Danh sách tất cả tài khoản thành viên</CardDescription>
              </CardHeader>
              <CardContent>
                {usersLoading ? (
                  <div>Đang tải người dùng...</div>
                ) : users && users.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>Tên đăng nhập</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Họ tên</TableHead>
                        <TableHead>Số điện thoại</TableHead>
                        <TableHead>Trạng thái</TableHead>
                        <TableHead>Ngày tạo</TableHead>
                        <TableHead>Thao tác</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {users.map((user: any) => (
                        <TableRow key={user.id}>
                          <TableCell>{user.id}</TableCell>
                          <TableCell className="font-medium">{user.username}</TableCell>
                          <TableCell>{user.email}</TableCell>
                          <TableCell>{user.fullName || 'Chưa cập nhật'}</TableCell>
                          <TableCell>{user.phone || 'Chưa có'}</TableCell>
                          <TableCell>
                            <span className={`px-2 py-1 rounded-full text-xs ${
                              user.isActive 
                                ? 'bg-green-100 text-green-800' 
                                : 'bg-red-100 text-red-800'
                            }`}>
                              {user.isActive ? 'Hoạt động' : 'Bị khóa'}
                            </span>
                          </TableCell>
                          <TableCell className="text-sm text-gray-500">
                            {user.createdAt ? new Date(user.createdAt).toLocaleDateString('vi-VN') : 'N/A'}
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button variant="outline" size="sm">
                                    <Edit className="w-4 h-4" />
                                  </Button>
                                </DialogTrigger>
                                <DialogContent className="sm:max-w-[500px]">
                                  <DialogHeader>
                                    <DialogTitle>Chỉnh sửa tài khoản thành viên</DialogTitle>
                                  </DialogHeader>
                                  <form 
                                    onSubmit={(e) => {
                                      e.preventDefault();
                                      const formData = new FormData(e.currentTarget);
                                      const userData = {
                                        username: formData.get('username'),
                                        email: formData.get('email'),
                                        fullName: formData.get('fullName'),
                                        phone: formData.get('phone'),
                                        address: formData.get('address'),
                                        isActive: formData.get('isActive') === 'true',
                                      };
                                      handleUserUpdate(user.id, userData);
                                    }} 
                                    className="space-y-4"
                                  >
                                    <div className="grid grid-cols-2 gap-4">
                                      <div>
                                        <Label htmlFor="user-username">Tên đăng nhập</Label>
                                        <Input 
                                          id="user-username" 
                                          name="username" 
                                          defaultValue={user.username || ''} 
                                          required 
                                        />
                                      </div>
                                      <div>
                                        <Label htmlFor="user-email">Email</Label>
                                        <Input 
                                          id="user-email" 
                                          name="email"                                          type="email"
                                          defaultValue={user.email || ''} 
                                          required 
                                        />
                                      </div>
                                    </div>

                                    <div className="grid grid-cols-2 gap-4">
                                      <div>
                                        <Label htmlFor="user-fullName">Họ tên</Label>
                                        <Input 
                                          id="user-fullName" 
                                          name="fullName" 
                                          defaultValue={user.fullName || ''} 
                                        />
                                      </div>
                                      <div>
                                        <Label htmlFor="user-phone">Số điện thoại</Label>
                                        <Input 
                                          id="user-phone" 
                                          name="phone" 
                                          defaultValue={user.phone || ''} 
                                        />
                                      </div>
                                    </div>

                                    <div>
                                      <Label htmlFor="user-address">Địa chỉ</Label>
                                      <Textarea 
                                        id="user-address" 
                                        name="address" 
                                        defaultValue={user.address || ''} 
                                      />
                                    </div>

                                    <div>
                                      <Label htmlFor="user-status">Trạng thái tài khoản</Label>
                                      <Select name="isActive" defaultValue={user.isActive?.toString() || 'true'}>
                                        <SelectTrigger>
                                          <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                          <SelectItem value="true">Hoạt động</SelectItem>
                                          <SelectItem value="false">Bị khóa</SelectItem>
                                        </SelectContent>
                                      </Select>
                                    </div>

                                    <DialogFooter>
                                      <Button type="submit" disabled={updateUserMutation.isPending}>
                                        Cập nhật tài khoản
                                      </Button>
                                    </DialogFooter>
                                  </form>
                                </DialogContent>
                              </Dialog>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => deleteUserMutation.mutate(user.id)}
                                disabled={deleteUserMutation.isPending}
                              >
                                <Trash className="w-4 h-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    Chưa có người dùng nào trong hệ thống
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}