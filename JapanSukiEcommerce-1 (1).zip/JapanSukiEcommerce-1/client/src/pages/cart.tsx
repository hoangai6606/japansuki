import { useState } from 'react';
import { Link } from 'wouter';
import { Trash2, Plus, Minus, ShoppingCart, ArrowLeft, CreditCard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { useCart } from '@/hooks/use-cart';
import { useToast } from '@/hooks/use-toast';
import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import Chatbot from '@/components/chat/chatbot';

export default function CartPage() {
  const { items, updateItem, removeItem, total, itemCount, clearCart } = useCart();
  const { toast } = useToast();
  const [couponCode, setCouponCode] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const formatPrice = (price: string) => {
    return parseInt(price).toLocaleString('vi-VN');
  };

  const handleUpdateQuantity = async (id: number, quantity: number) => {
    try {
      await updateItem(id, quantity);
    } catch (error) {
      toast({
        title: "Lỗi",
        description: "Không thể cập nhật số lượng sản phẩm.",
        variant: "destructive",
      });
    }
  };

  const handleRemoveItem = async (id: number) => {
    try {
      await removeItem(id);
      toast({
        title: "Đã xóa sản phẩm",
        description: "Sản phẩm đã được xóa khỏi giỏ hàng.",
      });
    } catch (error) {
      toast({
        title: "Lỗi",
        description: "Không thể xóa sản phẩm khỏi giỏ hàng.",
        variant: "destructive",
      });
    }
  };

  const handleClearCart = async () => {
    try {
      await clearCart();
      toast({
        title: "Đã xóa giỏ hàng",
        description: "Tất cả sản phẩm đã được xóa khỏi giỏ hàng.",
      });
    } catch (error) {
      toast({
        title: "Lỗi",
        description: "Không thể xóa giỏ hàng.",
        variant: "destructive",
      });
    }
  };

  const handleApplyCoupon = () => {
    if (!couponCode.trim()) {
      toast({
        title: "Lỗi",
        description: "Vui lòng nhập mã giảm giá.",
        variant: "destructive",
      });
      return;
    }
    
    toast({
      title: "Mã giảm giá không hợp lệ",
      description: "Mã giảm giá này không tồn tại hoặc đã hết hạn.",
      variant: "destructive",
    });
  };

  const shippingFee = total >= 500000 ? 0 : 30000;
  const finalTotal = total + shippingFee;

  if (items.length === 0) {
    return (
      <>
        <Header />
        <div className="min-h-screen bg-gray-50">
          <main className="container mx-auto px-4 py-16">
            <div className="text-center">
              <ShoppingCart className="w-24 h-24 text-gray-300 mx-auto mb-6" />
              <h1 className="text-3xl font-bold text-gray-900 mb-4">Giỏ hàng trống</h1>
              <p className="text-gray-600 mb-8">
                Bạn chưa có sản phẩm nào trong giỏ hàng. Hãy khám phá các sản phẩm tuyệt vời của chúng tôi!
              </p>
              <Link href="/">
                <Button className="cherry-gradient text-white px-8 py-3">
                  <ArrowLeft className="w-5 h-5 mr-2" />
                  Tiếp tục mua sắm
                </Button>
              </Link>
            </div>
          </main>
        </div>
        <Footer />
        <Chatbot />
      </>
    );
  }

  return (
    <>
      <Header />
      <div className="min-h-screen bg-gray-50">
        <main className="container mx-auto px-4 py-8">
          <div className="mb-6">
            <Link href="/" className="inline-flex items-center text-cherry hover:text-cherry-dark">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Tiếp tục mua sắm
            </Link>
          </div>

          <h1 className="text-3xl font-bold text-gray-900 mb-8">
            Giỏ hàng ({itemCount} sản phẩm)
          </h1>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-4">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold">Sản phẩm trong giỏ</h2>
                <Button
                  variant="outline"
                  onClick={handleClearCart}
                  className="text-red-600 hover:text-red-700"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Xóa tất cả
                </Button>
              </div>

              {items.map((item) => (
                <Card key={item.id}>
                  <CardContent className="p-6">
                    <div className="flex space-x-4">
                      <img
                        src={item.product.imageUrl || 'https://via.placeholder.com/120x120'}
                        alt={item.product.name}
                        className="w-24 h-24 object-cover rounded-md"
                      />
                      <div className="flex-1">
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="text-lg font-semibold text-gray-900 mb-2">
                              {item.product.name}
                            </h3>
                            <p className="text-gray-600 text-sm mb-2">
                              {item.product.shortDescription}
                            </p>
                            <div className="flex items-center space-x-2">
                              <span className="text-xl font-bold text-cherry">
                                {formatPrice(item.product.price)}₫
                              </span>
                              {item.product.originalPrice && (
                                <span className="text-gray-500 line-through">
                                  {formatPrice(item.product.originalPrice)}₫
                                </span>
                              )}
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleRemoveItem(item.id)}
                            className="text-red-500 hover:text-red-700 hover:bg-red-50"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>

                        <div className="flex items-center justify-between mt-4">
                          <div className="flex items-center space-x-3">
                            <span className="text-sm font-medium">Số lượng:</span>
                            <div className="flex items-center border border-gray-300 rounded-lg">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleUpdateQuantity(item.id, item.quantity - 1)}
                                disabled={item.quantity <= 1}
                                className="px-3 py-1 hover:bg-gray-100"
                              >
                                <Minus className="w-4 h-4" />
                              </Button>
                              <span className="px-4 py-1 border-x border-gray-300 min-w-[3rem] text-center">
                                {item.quantity}
                              </span>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleUpdateQuantity(item.id, item.quantity + 1)}
                                disabled={item.quantity >= item.product.stock}
                                className="px-3 py-1 hover:bg-gray-100"
                              >
                                <Plus className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                          <div className="text-right">
                            <span className="text-lg font-semibold">
                              {(parseInt(item.product.price) * item.quantity).toLocaleString('vi-VN')}₫
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <Card className="sticky top-4">
                <CardHeader>
                  <CardTitle>Tổng đơn hàng</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Coupon Code */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Mã giảm giá
                    </label>
                    <div className="flex space-x-2">
                      <Input
                        placeholder="Nhập mã giảm giá"
                        value={couponCode}
                        onChange={(e) => setCouponCode(e.target.value)}
                      />
                      <Button variant="outline" onClick={handleApplyCoupon}>
                        Áp dụng
                      </Button>
                    </div>
                  </div>

                  <Separator />

                  {/* Price Breakdown */}
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Tạm tính:</span>
                      <span>{total.toLocaleString('vi-VN')}₫</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Phí vận chuyển:</span>
                      <span>
                        {shippingFee === 0 ? (
                          <Badge variant="secondary">Miễn phí</Badge>
                        ) : (
                          `${shippingFee.toLocaleString('vi-VN')}₫`
                        )}
                      </span>
                    </div>
                    {total < 500000 && (
                      <p className="text-xs text-gray-600">
                        Mua thêm {(500000 - total).toLocaleString('vi-VN')}₫ để được miễn phí vận chuyển
                      </p>
                    )}
                  </div>

                  <Separator />

                  <div className="flex justify-between text-lg font-semibold">
                    <span>Tổng cộng:</span>
                    <span className="text-cherry">{finalTotal.toLocaleString('vi-VN')}₫</span>
                  </div>

                  <Link href="/checkout">
                    <Button 
                      className="w-full cherry-gradient py-3 text-lg font-semibold hover:opacity-90 transition-opacity text-[#000000]"
                      disabled={isProcessing}
                    >
                      <CreditCard className="w-5 h-5 mr-2" />
                      {isProcessing ? 'Đang xử lý...' : 'Thanh toán'}
                    </Button>
                  </Link>

                  <div className="text-center text-xs text-gray-500 space-y-1">
                    <p>✓ Thanh toán an toàn & bảo mật</p>
                    <p>✓ Hỗ trợ nhiều phương thức thanh toán</p>
                    <p>✓ Giao hàng toàn quốc</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </main>
      </div>
      <Footer />
      <Chatbot />
    </>
  );
}