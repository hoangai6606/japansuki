import { useState } from 'react';
import { Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Gift, Flame, Zap, ArrowRight, Shield, Truck, RotateCcw, Star, Timer, TrendingUp, Eye, Filter, ShoppingCart, Plus, Award, Heart, Users, Lock, Headphones, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import SakuraFooter from '@/components/layout/sakura-footer';

import Chatbot from '@/components/chat/chatbot';
import HeroSection from '@/components/hero/hero-section';
import ProductSection from '@/components/product/product-section';
import type { Category, Product } from '@/lib/types';

export default function Home() {
  const [copiedCoupon, setCopiedCoupon] = useState(false);

  // Fetch categories
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });



  const handleCopyCoupon = () => {
    navigator.clipboard.writeText('GZY1AOLYK2E0').then(() => {
      setCopiedCoupon(true);
      setTimeout(() => setCopiedCoupon(false), 2000);
    });
  };



  return (
    <div className="min-h-screen">
      {/* New Sakura-themed Hero Section */}
      <HeroSection />
      
      <main className="container mx-auto px-4 py-8">
        {/* New Sakura-themed Product Section */}
        <ProductSection />

        

        {/* Promotion Banner */}
        <section className="mb-12">
          <div className="cherry-gradient rounded-xl p-6 text-white">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Gift className="w-8 h-8 mr-4" />
                <div>
                  <h3 className="text-xl font-bold mb-1">FreeShip</h3>
                  <p className="text-sm opacity-90">NHẬP MÃ: GZY1AOLYK2E0 - Miễn phí vận chuyển</p>
                </div>
              </div>
              <Button
                onClick={handleCopyCoupon}
                className={`px-6 py-2 rounded-full font-semibold transition-all ${
                  copiedCoupon 
                    ? 'bg-green-500 text-white' 
                    : 'bg-white text-cherry hover:bg-gray-100'
                }`}
              >
                {copiedCoupon ? 'Đã sao chép!' : 'Sao chép mã'}
              </Button>
            </div>
          </div>
        </section>

        

        {/* Newsletter Subscription */}
        <section className="mb-12">
          <div className="cherry-gradient rounded-2xl p-8 text-white text-center">
            <h3 className="text-2xl font-bold mb-4 text-black">Đăng ký nhận tin khuyến mãi</h3>
            <p className="mb-6 opacity-90 text-black">Nhận thông tin sản phẩm mới và ưu đãi đặc biệt từ JapanSuki</p>
            <div className="flex max-w-md mx-auto">
              <input 
                type="email" 
                placeholder="Nhập email của bạn" 
                className="flex-1 px-4 py-3 rounded-l-full text-gray-700 focus:outline-none h-12"
              />
              <Button className="bg-black text-white px-6 py-3 rounded-r-full font-semibold hover:bg-gray-800 transition-colors h-12">
                Đăng ký
              </Button>
            </div>
          </div>
        </section>
      </main>

      <SakuraFooter />
      <Chatbot />
    </div>
  );
}
