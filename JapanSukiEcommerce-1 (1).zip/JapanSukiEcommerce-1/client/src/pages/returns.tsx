import { Link } from 'wouter';
import { ArrowLeft, RotateCcw, Package, Truck, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function ReturnsPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-cherry text-white py-12">
        <div className="container mx-auto px-4">
          <Link href="/">
            <Button variant="ghost" className="text-white mb-4 hover:bg-white/10">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Về trang chủ
            </Button>
          </Link>
          <h1 className="text-4xl font-bold mb-4">Chính sách đổi trả</h1>
          <p className="text-xl text-pink-100">
            Quy định đổi trả sản phẩm tại JapanSuki
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        {/* Overview */}
        <section className="mb-12">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-2xl">
                <RotateCcw className="w-6 h-6 mr-2 text-cherry" />
                Chính sách đổi trả
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 leading-relaxed">
                JapanSuki luôn đặt sự hài lòng của khách hàng lên hàng đầu. Chúng tôi hỗ trợ 
                đổi trả sản phẩm trong các trường hợp phù hợp để đảm bảo quyền lợi của khách hàng.
              </p>
            </CardContent>
          </Card>
        </section>

        {/* Return Conditions */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-8">Điều kiện đổi trả</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle className="text-green-600">Được đổi trả</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 text-gray-600">
                  <li className="flex items-start">
                    <span className="text-green-500 mr-2 mt-1">✓</span>
                    Sản phẩm lỗi từ nhà sản xuất
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-500 mr-2 mt-1">✓</span>
                    Giao sai sản phẩm so với đơn hàng
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-500 mr-2 mt-1">✓</span>
                    Sản phẩm bị hư hỏng trong vận chuyển
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-500 mr-2 mt-1">✓</span>
                    Sản phẩm không đúng mô tả
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-500 mr-2 mt-1">✓</span>
                    Còn nguyên bao bì, tem mác
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-red-600">Không được đổi trả</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 text-gray-600">
                  <li className="flex items-start">
                    <span className="text-red-500 mr-2 mt-1">✗</span>
                    Sản phẩm đã sử dụng
                  </li>
                  <li className="flex items-start">
                    <span className="text-red-500 mr-2 mt-1">✗</span>
                    Quá thời gian đổi trả
                  </li>
                  <li className="flex items-start">
                    <span className="text-red-500 mr-2 mt-1">✗</span>
                    Không có hóa đơn mua hàng
                  </li>
                  <li className="flex items-start">
                    <span className="text-red-500 mr-2 mt-1">✗</span>
                    Sản phẩm khuyến mãi, giảm giá đặc biệt
                  </li>
                  <li className="flex items-start">
                    <span className="text-red-500 mr-2 mt-1">✗</span>
                    Hư hỏng do người dùng
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Return Timeline */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-8">Thời gian đổi trả</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardContent className="p-6 text-center">
                <Package className="w-12 h-12 text-cherry mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">Thực phẩm</h3>
                <p className="text-gray-600">3 ngày từ ngày nhận</p>
                <p className="text-sm text-gray-500 mt-2">
                  Chỉ áp dụng khi sản phẩm lỗi
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <Package className="w-12 h-12 text-cherry mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">Mỹ phẩm</h3>
                <p className="text-gray-600">7 ngày từ ngày nhận</p>
                <p className="text-sm text-gray-500 mt-2">
                  Sản phẩm chưa bóc seal
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <Package className="w-12 h-12 text-cherry mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">Đồ gia dụng</h3>
                <p className="text-gray-600">15 ngày từ ngày nhận</p>
                <p className="text-sm text-gray-500 mt-2">
                  Đầy đủ phụ kiện đi kèm
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Return Process */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-8">Quy trình đổi trả</h2>
          <Card>
            <CardContent className="p-8">
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="bg-cherry text-white rounded-full w-8 h-8 flex items-center justify-center font-bold mr-4 mt-1">1</div>
                  <div>
                    <h3 className="font-semibold mb-2">Liên hệ yêu cầu đổi trả</h3>
                    <p className="text-gray-600">Gọi hotline 0384.323.829 hoặc email trong vòng thời gian quy định</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-cherry text-white rounded-full w-8 h-8 flex items-center justify-center font-bold mr-4 mt-1">2</div>
                  <div>
                    <h3 className="font-semibold mb-2">Cung cấp thông tin</h3>
                    <p className="text-gray-600">Gửi mã đơn hàng, hình ảnh sản phẩm và lý do đổi trả</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-cherry text-white rounded-full w-8 h-8 flex items-center justify-center font-bold mr-4 mt-1">3</div>
                  <div>
                    <h3 className="font-semibold mb-2">Xác nhận đổi trả</h3>
                    <p className="text-gray-600">Nhân viên xác nhận và hướng dẫn đóng gói, gửi hàng</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-cherry text-white rounded-full w-8 h-8 flex items-center justify-center font-bold mr-4 mt-1">4</div>
                  <div>
                    <h3 className="font-semibold mb-2">Gửi hàng về</h3>
                    <p className="text-gray-600">Khách hàng gửi sản phẩm về địa chỉ được cung cấp</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-cherry text-white rounded-full w-8 h-8 flex items-center justify-center font-bold mr-4 mt-1">5</div>
                  <div>
                    <h3 className="font-semibold mb-2">Xử lý đổi trả</h3>
                    <p className="text-gray-600">Kiểm tra và xử lý đổi mới hoặc hoàn tiền trong 5-7 ngày</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Shipping Info */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-8">Phí vận chuyển</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-green-600">
                  <Truck className="w-5 h-5 mr-2" />
                  Miễn phí vận chuyển
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-gray-600">
                  <li>• Lỗi từ JapanSuki</li>
                  <li>• Giao sai sản phẩm</li>
                  <li>• Sản phẩm bị hư hỏng</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-orange-600">
                  <Truck className="w-5 h-5 mr-2" />
                  Khách hàng chi trả
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-gray-600">
                  <li>• Đổi ý không muốn mua</li>
                  <li>• Chọn sai kích cỡ/màu sắc</li>
                  <li>• Lý do cá nhân khác</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Contact */}
        <section>
          <Card className="bg-cherry-gradient text-white">
            <CardContent className="p-8 text-center">
              <RefreshCw className="w-12 h-12 mx-auto mb-4" />
              <h2 className="text-2xl font-bold mb-4">Cần hỗ trợ đổi trả?</h2>
              <p className="mb-6">Liên hệ ngay với chúng tôi để được tư vấn</p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button className="bg-white text-cherry hover:bg-gray-100">
                  Hotline: 0384.323.829
                </Button>
                <Button variant="outline" className="border-white text-white hover:bg-white/10">
                  Email: info@japansuki.vn
                </Button>
              </div>
            </CardContent>
          </Card>
        </section>
      </div>
    </div>
  );
}