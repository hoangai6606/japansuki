import { useState } from 'react';
import { useParams, Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Heart, ShoppingCart, Plus, Minus, Share2, Truck, Shield, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from '@/components/ui/breadcrumb';
import { Separator } from '@/components/ui/separator';
import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import ProductGrid from '@/components/product/product-grid';
import Chatbot from '@/components/chat/chatbot';
import { useCart } from '@/hooks/use-cart';
import { useWishlist } from '@/hooks/use-wishlist';
import { useToast } from '@/hooks/use-toast';
import type { Product, Category } from '@/lib/types';

export default function ProductPage() {
  const { slug } = useParams();
  const [quantity, setQuantity] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedImage, setSelectedImage] = useState(0);
  
  const { addItem } = useCart();
  const { toggleItem, isInWishlist } = useWishlist();
  const { toast } = useToast();

  // Fetch product details
  const { data: product } = useQuery({
    queryKey: ['/api/products', slug],
    queryFn: async () => {
      const response = await fetch(`/api/products/${slug}`);
      if (!response.ok) throw new Error('Product not found');
      return response.json();
    },
    enabled: !!slug
  });

  // Fetch category info
  const { data: category } = useQuery({
    queryKey: ['/api/categories', product?.categoryId],
    queryFn: async () => {
      const response = await fetch(`/api/categories/${product.categoryId}`);
      if (!response.ok) throw new Error('Category not found');
      return response.json();
    },
    enabled: !!product?.categoryId
  });

  // Fetch related products
  const { data: relatedProducts = [] } = useQuery({
    queryKey: ['/api/products', { category: product?.categoryId, related: true }],
    queryFn: async () => {
      const response = await fetch(`/api/products?categoryId=${product.categoryId}&limit=4`);
      if (!response.ok) throw new Error('Failed to fetch related products');
      const products = await response.json();
      return products.filter((p: Product) => p.id !== product.id);
    },
    enabled: !!product?.categoryId
  });

  const handleAddToCart = async () => {
    if (!product) return;
    
    try {
      setIsLoading(true);
      await addItem(product.id, quantity);
      toast({
        title: "Đã thêm vào giỏ hàng",
        description: `${quantity} x ${product.name} đã được thêm vào giỏ hàng của bạn.`,
      });
    } catch (error) {
      toast({
        title: "Lỗi",
        description: "Không thể thêm sản phẩm vào giỏ hàng. Vui lòng thử lại.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleToggleWishlist = async () => {
    if (!product) return;
    
    try {
      await toggleItem(product.id);
      toast({
        title: isInWishlist(product.id) ? "Đã xóa khỏi yêu thích" : "Đã thêm vào yêu thích",
        description: `${product.name} ${isInWishlist(product.id) ? 'đã được xóa khỏi' : 'đã được thêm vào'} danh sách yêu thích.`,
      });
    } catch (error) {
      toast({
        title: "Lỗi",
        description: "Không thể cập nhật danh sách yêu thích. Vui lòng thử lại.",
        variant: "destructive",
      });
    }
  };

  const formatPrice = (price: string) => {
    return parseInt(price).toLocaleString('vi-VN');
  };

  const incrementQuantity = () => {
    if (product && quantity < product.stock) {
      setQuantity(prev => prev + 1);
    }
  };

  const decrementQuantity = () => {
    if (quantity > 1) {
      setQuantity(prev => prev - 1);
    }
  };

  if (!product) {
    return (
      <div className="min-h-screen page-gradient">
        <Header />
        <main className="container mx-auto px-4 py-8">
          <div className="text-center py-12">
            <h1 className="text-2xl font-bold text-gray-800 mb-4">Sản phẩm không tồn tại</h1>
            <p className="text-gray-600">Sản phẩm bạn tìm kiếm không tồn tại hoặc đã bị xóa.</p>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const images = product.images && product.images.length > 0 ? product.images : [product.imageUrl || 'https://via.placeholder.com/600x600'];

  return (
    <>
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <Breadcrumb className="mb-6">
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href="/">Trang chủ</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            {category && (
              <>
                <BreadcrumbItem>
                  <BreadcrumbLink href={`/category/${category.slug}`}>
                    {category.name}
                  </BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator />
              </>
            )}
            <BreadcrumbItem>
              <BreadcrumbPage>{product.name}</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-12">
          {/* Product Images */}
          <div className="space-y-4">
            <div className="aspect-square rounded-lg overflow-hidden bg-white border border-soft-petal">
              <img
                src={images[selectedImage]}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>
            
            {images.length > 1 && (
              <div className="flex space-x-2 overflow-x-auto">
                {images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    className={`flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 transition-colors ${
                      selectedImage === index ? 'border-cherry' : 'border-gray-200'
                    }`}
                  >
                    <img
                      src={image}
                      alt={`${product.name} ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-4">{product.name}</h1>
              
              {/* Badges */}
              <div className="flex flex-wrap gap-2 mb-4">
                {product.isFeatured && (
                  <Badge variant="secondary">Nổi bật</Badge>
                )}
                {product.isHot && (
                  <Badge variant="destructive">Hot</Badge>
                )}
                {product.soldCount && product.soldCount > 0 && (
                  <Badge variant="outline">Đã bán {product.soldCount} sp</Badge>
                )}
              </div>

              {/* Price */}
              <div className="flex items-center space-x-4 mb-6">
                <div className="flex items-center space-x-2">
                  <span className="text-4xl font-bold text-cherry">
                    {formatPrice(product.price)}₫
                  </span>
                  {product.originalPrice && (
                    <span className="text-xl text-gray-500 line-through">
                      {formatPrice(product.originalPrice)}₫
                    </span>
                  )}
                </div>
                <span className={`font-medium ${
                  product.stock > 0 ? 'text-green-600' : 'text-red-600'
                }`}>
                  {product.stock > 0 ? `Còn ${product.stock} sản phẩm` : 'Hết hàng'}
                </span>
              </div>

              {/* Short Description */}
              {product.shortDescription && (
                <p className="text-gray-600 text-lg mb-6">{product.shortDescription}</p>
              )}
            </div>

            {/* Product Details */}
            <div className="bg-gray-50 rounded-lg p-4 space-y-2">
              <h3 className="font-semibold text-gray-800">Thông tin sản phẩm:</h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-600">Xuất xứ:</span>
                  <span className="ml-2 font-medium">{product.origin || 'Nhật Bản'}</span>
                </div>
                {product.weight && (
                  <div>
                    <span className="text-gray-600">Trọng lượng:</span>
                    <span className="ml-2 font-medium">{product.weight}</span>
                  </div>
                )}
                {product.brand && (
                  <div>
                    <span className="text-gray-600">Thương hiệu:</span>
                    <span className="ml-2 font-medium">{product.brand}</span>
                  </div>
                )}
                <div>
                  <span className="text-gray-600">Mã sản phẩm:</span>
                  <span className="ml-2 font-medium">SP{product.id.toString().padStart(6, '0')}</span>
                </div>
              </div>
            </div>

            {/* Quantity and Actions */}
            <div className="space-y-4">
              <div className="flex items-center space-x-4">
                <span className="text-gray-700 font-medium">Số lượng:</span>
                <div className="flex items-center border border-gray-300 rounded-lg">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={decrementQuantity}
                    disabled={quantity <= 1}
                    className="px-3 py-1 hover:bg-gray-100"
                  >
                    <Minus className="w-4 h-4" />
                  </Button>
                  <span className="px-4 py-1 border-x border-gray-300 min-w-[3rem] text-center font-medium">
                    {quantity}
                  </span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={incrementQuantity}
                    disabled={quantity >= product.stock}
                    className="px-3 py-1 hover:bg-gray-100"
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  onClick={handleAddToCart}
                  disabled={isLoading || product.stock === 0}
                  className="flex-1 cherry-gradient py-3 text-lg font-semibold hover:opacity-90 transition-opacity text-[#000000]"
                  size="lg"
                >
                  {isLoading ? (
                    "Đang thêm..."
                  ) : (
                    <>
                      <ShoppingCart className="w-5 h-5 mr-2" />
                      Thêm vào giỏ hàng
                    </>
                  )}
                </Button>
                
                <div className="flex gap-2">
                  <Button
                    onClick={handleToggleWishlist}
                    variant="outline"
                    size="lg"
                    className="py-3 px-6"
                  >
                    <Heart className={`w-5 h-5 ${isInWishlist(product.id) ? 'fill-current text-red-500' : ''}`} />
                  </Button>
                  
                  <Button
                    variant="outline"
                    size="lg"
                    className="py-3 px-6"
                  >
                    <Share2 className="w-5 h-5" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Service Features */}
            <div className="border border-gray-200 rounded-lg p-4 space-y-3">
              <div className="flex items-center space-x-3 text-sm">
                <Truck className="w-5 h-5 text-green-600" />
                <span>Miễn phí vận chuyển cho đơn hàng trên 500.000₫</span>
              </div>
              <div className="flex items-center space-x-3 text-sm">
                <Shield className="w-5 h-5 text-blue-600" />
                <span>Bảo hành chính hãng từ nhà sản xuất</span>
              </div>
              <div className="flex items-center space-x-3 text-sm">
                <RefreshCw className="w-5 h-5 text-orange-600" />
                <span>Đổi trả trong 7 ngày nếu có lỗi từ nhà sản xuất</span>
              </div>
            </div>
          </div>
        </div>

        {/* Product Details Tabs */}
        <div className="mb-12">
          <Tabs defaultValue="description" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="description">Mô tả sản phẩm</TabsTrigger>
              <TabsTrigger value="specifications">Thông số kỹ thuật</TabsTrigger>
              <TabsTrigger value="reviews">Đánh giá (0)</TabsTrigger>
            </TabsList>
            
            <TabsContent value="description" className="mt-6">
              <div className="bg-white rounded-lg p-6 border border-soft-petal">
                <h3 className="text-xl font-semibold mb-4">Mô tả chi tiết</h3>
                <div className="prose max-w-none">
                  <p className="text-gray-700 leading-relaxed">
                    {product.description || 'Chưa có mô tả chi tiết cho sản phẩm này.'}
                  </p>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="specifications" className="mt-6">
              <div className="bg-white rounded-lg p-6 border border-soft-petal">
                <h3 className="text-xl font-semibold mb-4">Thông số kỹ thuật</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <div className="flex justify-between py-2 border-b border-gray-100">
                      <span className="text-gray-600">Xuất xứ:</span>
                      <span className="font-medium">{product.origin || 'Nhật Bản'}</span>
                    </div>
                    {product.weight && (
                      <div className="flex justify-between py-2 border-b border-gray-100">
                        <span className="text-gray-600">Trọng lượng:</span>
                        <span className="font-medium">{product.weight}</span>
                      </div>
                    )}
                    {product.brand && (
                      <div className="flex justify-between py-2 border-b border-gray-100">
                        <span className="text-gray-600">Thương hiệu:</span>
                        <span className="font-medium">{product.brand}</span>
                      </div>
                    )}
                    <div className="flex justify-between py-2 border-b border-gray-100">
                      <span className="text-gray-600">Tình trạng:</span>
                      <span className={`font-medium ${product.stock > 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {product.stock > 0 ? 'Còn hàng' : 'Hết hàng'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="reviews" className="mt-6">
              <div className="bg-white rounded-lg p-6 border border-soft-petal">
                <h3 className="text-xl font-semibold mb-4">Đánh giá khách hàng</h3>
                <div className="text-center py-12 text-gray-500">
                  <p>Chưa có đánh giá nào cho sản phẩm này.</p>
                  <p className="text-sm mt-2">Hãy trở thành người đầu tiên đánh giá sản phẩm!</p>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Sản phẩm liên quan</h2>
            <ProductGrid products={relatedProducts} columns={4} />
          </section>
        )}
      </main>

      <Footer />
      <Chatbot />
    </>
  );
}
