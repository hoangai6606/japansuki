import { Link } from 'wouter';
import { ArrowLeft, ShoppingCart, CreditCard, Truck, HeadphonesIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function GuidePage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-cherry text-white py-12">
        <div className="container mx-auto px-4">
          <Link href="/">
            <Button variant="ghost" className="text-white mb-4 hover:bg-white/10">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Về trang chủ
            </Button>
          </Link>
          <h1 className="text-4xl font-bold mb-4">Hướng dẫn mua hàng</h1>
          <p className="text-xl text-pink-100">
            Hướng dẫn chi tiết cách mua hàng tại JapanSuki
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        {/* Shopping Steps */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-8 text-center">Các bước mua hàng</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card className="text-center">
              <CardContent className="p-6">
                <ShoppingCart className="w-12 h-12 text-cherry mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">1. Chọn sản phẩm</h3>
                <p className="text-gray-600 text-sm">
                  Duyệt danh mục, tìm kiếm và chọn sản phẩm yêu thích
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="p-6">
                <ShoppingCart className="w-12 h-12 text-cherry mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">2. Thêm vào giỏ</h3>
                <p className="text-gray-600 text-sm">
                  Thêm sản phẩm vào giỏ hàng và kiểm tra thông tin
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="p-6">
                <CreditCard className="w-12 h-12 text-cherry mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">3. Thanh toán</h3>
                <p className="text-gray-600 text-sm">
                  Điền thông tin và chọn phương thức thanh toán
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="p-6">
                <Truck className="w-12 h-12 text-cherry mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">4. Nhận hàng</h3>
                <p className="text-gray-600 text-sm">
                  Theo dõi đơn hàng và nhận sản phẩm tại nhà
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Detailed Guide */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-8">Hướng dẫn chi tiết</h2>
          <div className="space-y-8">
            <Card>
              <CardHeader>
                <CardTitle>Bước 1: Tìm kiếm và chọn sản phẩm</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-2">Cách tìm sản phẩm:</h4>
                    <ul className="space-y-1 text-gray-600 ml-4">
                      <li>• Sử dụng thanh tìm kiếm ở đầu trang</li>
                      <li>• Duyệt theo danh mục: Thực phẩm, Mỹ phẩm, Giặt giũ, Nhà bếp, Mẹ & bé</li>
                      <li>• Xem sản phẩm nổi bật và khuyến mãi</li>
                      <li>• Sử dụng bộ lọc giá và thương hiệu</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">Xem thông tin sản phẩm:</h4>
                    <ul className="space-y-1 text-gray-600 ml-4">
                      <li>• Click vào sản phẩm để xem chi tiết</li>
                      <li>• Đọc mô tả, thành phần và hướng dẫn sử dụng</li>
                      <li>• Xem hình ảnh chi tiết từ nhiều góc độ</li>
                      <li>• Kiểm tra tình trạng còn hàng</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Bước 2: Thêm vào giỏ hàng</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-2">Thêm sản phẩm:</h4>
                    <ul className="space-y-1 text-gray-600 ml-4">
                      <li>• Chọn số lượng mong muốn</li>
                      <li>• Click nút "Thêm vào giỏ hàng"</li>
                      <li>• Kiểm tra giỏ hàng bằng cách click biểu tượng giỏ hàng</li>
                      <li>• Có thể cập nhật số lượng hoặc xóa sản phẩm trong giỏ</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">Mẹo mua hàng:</h4>
                    <ul className="space-y-1 text-gray-600 ml-4">
                      <li>• Thêm vào danh sách yêu thích để mua sau</li>
                      <li>• Kiểm tra mã giảm giá có sẵn</li>
                      <li>• Mua đủ số lượng để được miễn phí vận chuyển</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Bước 3: Thanh toán</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-2">Thông tin giao hàng:</h4>
                    <ul className="space-y-1 text-gray-600 ml-4">
                      <li>• Điền đầy đủ họ tên người nhận</li>
                      <li>• Số điện thoại liên hệ chính xác</li>
                      <li>• Địa chỉ giao hàng chi tiết (số nhà, đường, phường, quận/huyện, tỉnh/thành)</li>
                      <li>• Ghi chú đặc biệt nếu cần</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">Phương thức thanh toán:</h4>
                    <ul className="space-y-1 text-gray-600 ml-4">
                      <li>• Thanh toán khi nhận hàng (COD)</li>
                      <li>• Chuyển khoản ngân hàng</li>
                      <li>• Ví điện tử: MoMo, ZaloPay</li>
                      <li>• Thẻ ATM/Visa/Mastercard qua VNPay</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Bước 4: Theo dõi và nhận hàng</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-2">Theo dõi đơn hàng:</h4>
                    <ul className="space-y-1 text-gray-600 ml-4">
                      <li>• Nhận SMS/Email xác nhận đơn hàng</li>
                      <li>• Kiểm tra trạng thái đơn hàng trên website</li>
                      <li>• Nhận thông báo khi hàng được giao</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">Nhận hàng:</h4>
                    <ul className="space-y-1 text-gray-600 ml-4">
                      <li>• Kiểm tra sản phẩm trước khi thanh toán (COD)</li>
                      <li>• Đối chiếu với đơn hàng đã đặt</li>
                      <li>• Giữ lại hóa đơn để bảo hành</li>
                      <li>• Liên hệ ngay nếu có vấn đề</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Payment Methods */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-8">Phương thức thanh toán</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Thanh toán trực tuyến</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-cherry rounded-full mr-3"></span>
                    <span>VNPay - Thẻ ATM/Visa/Mastercard</span>
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-cherry rounded-full mr-3"></span>
                    <span>Ví MoMo</span>
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-cherry rounded-full mr-3"></span>
                    <span>Ví ZaloPay</span>
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-cherry rounded-full mr-3"></span>
                    <span>Chuyển khoản ngân hàng</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Thanh toán khi nhận hàng</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-cherry rounded-full mr-3"></span>
                    <span>Thanh toán bằng tiền mặt</span>
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-cherry rounded-full mr-3"></span>
                    <span>Kiểm tra hàng trước khi trả tiền</span>
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-cherry rounded-full mr-3"></span>
                    <span>Phí COD: 20,000 VNĐ</span>
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-cherry rounded-full mr-3"></span>
                    <span>Miễn phí COD cho đơn trên 500,000 VNĐ</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Contact Support */}
        <section>
          <Card className="bg-cherry-gradient text-white">
            <CardContent className="p-8 text-center">
              <HeadphonesIcon className="w-12 h-12 mx-auto mb-4" />
              <h2 className="text-2xl font-bold mb-4">Cần hỗ trợ mua hàng?</h2>
              <p className="mb-6">Đội ngũ tư vấn của chúng tôi sẵn sàng hỗ trợ bạn 24/7</p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button className="bg-white text-cherry hover:bg-gray-100">
                  Hotline: 0384.323.829
                </Button>
                <Button variant="outline" className="border-white text-white hover:bg-white/10">
                  Chat với tư vấn viên
                </Button>
              </div>
            </CardContent>
          </Card>
        </section>
      </div>
    </div>
  );
}