import { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Bot, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { useWebSocket } from '@/hooks/use-websocket';
import { sessionManager, type ChatMessage } from '@/lib/types';

export default function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [inputMessage, setInputMessage] = useState('');
  const sessionId = sessionManager.getSessionId();
  const { isConnected, sendMessage, messages, clearMessages } = useWebSocket(sessionId);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto scroll to bottom when new messages arrive
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  // Focus input when chat opens
  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);

  // Initialize with welcome message if no messages
  useEffect(() => {
    if (isOpen && messages.length === 0) {
      const welcomeMessage: ChatMessage = {
        id: 'welcome',
        role: 'assistant',
        content: 'Xin chào! Tôi là AI hỗ trợ của JapanSuki. Tôi có thể giúp bạn tìm sản phẩm, thông tin đơn hàng và các câu hỏi về sản phẩm Nhật Bản. Bạn cần hỗ trợ gì không?',
        timestamp: new Date(),
        suggestions: [
          'Sản phẩm nào bán chạy nhất?',
          'Chính sách giao hàng như thế nào?',
          'Làm sao để sử dụng mã giảm giá?'
        ]
      };
      // Add welcome message to local state without sending to server
      messages.length === 0 && setIsOpen(isOpen);
    }
  }, [isOpen, messages.length]);

  const handleSendMessage = () => {
    if (!inputMessage.trim() || !isConnected) return;

    sendMessage(inputMessage);
    setInputMessage('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    setInputMessage(suggestion);
    handleSendMessage();
  };

  const toggleChat = () => {
    setIsOpen(!isOpen);
  };

  const closeChat = () => {
    setIsOpen(false);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Chat Window */}
      {isOpen && (
        <div className="absolute bottom-16 right-0 w-80 sm:w-96 bg-white rounded-2xl shadow-2xl border border-soft-petal overflow-hidden animate-in slide-in-from-bottom-2">
          {/* Chat Header */}
          <div className="cherry-gradient text-white p-4 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Bot className="w-5 h-5" />
              <div>
                <span className="font-semibold">AI Hỗ trợ JapanSuki</span>
                <div className="flex items-center space-x-1 text-xs opacity-90">
                  <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-400' : 'bg-red-400'}`}></div>
                  <span>{isConnected ? 'Đang hoạt động' : 'Mất kết nối'}</span>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={clearMessages}
                className="text-pink-200 hover:text-white hover:bg-white/20 p-1"
                title="Xóa lịch sử chat"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                </svg>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={closeChat}
                className="text-pink-200 hover:text-white hover:bg-white/20 p-1"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Chat Messages */}
          <ScrollArea className="h-80 p-4">
            <div className="space-y-4">
              {/* Welcome message */}
              {messages.length === 0 && (
                <div className="flex items-start space-x-3">
                  <div className="bg-cherry text-white p-2 rounded-full">
                    <Bot className="w-4 h-4" />
                  </div>
                  <div className="bg-gray-100 p-3 rounded-lg rounded-tl-none max-w-xs">
                    <p className="text-sm text-gray-800">
                      Xin chào! Tôi là AI hỗ trợ của JapanSuki. Tôi có thể giúp bạn tìm sản phẩm, thông tin đơn hàng và các câu hỏi về sản phẩm Nhật Bản. Bạn cần hỗ trợ gì không?
                    </p>
                    <div className="flex flex-wrap gap-1 mt-3">
                      {['Sản phẩm nào bán chạy nhất?', 'Chính sách giao hàng như thế nào?'].map((suggestion) => (
                        <Button
                          key={suggestion}
                          variant="outline"
                          size="sm"
                          onClick={() => handleSuggestionClick(suggestion)}
                          className="text-xs h-auto py-1 px-2 border-cherry text-cherry hover:bg-cherry hover:text-white"
                        >
                          {suggestion}
                        </Button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Chat messages */}
              {messages.map((message) => (
                <div
                  className={`flex items-start space-x-3 ${
                    message.role === 'user' ? 'justify-end' : ''
                  }`}
                >
                  {message.role === 'assistant' && (
                    <div className="bg-red-500 text-white p-2 rounded-full">
                      <Bot className="w-4 h-4" />
                    </div>
                  )}

                  <div
                    className={`p-3 rounded-lg max-w-xs ${
                      message.role === 'user'
                        ? 'bg-cherry text-white rounded-tr-none'
                        : 'bg-gray-100 text-black rounded-tl-none'
                    }`}
                  >
                    <p className="text-sm whitespace-pre-wrap text-black">{message.content}</p>

                    {/* Suggestions */}
                    {message.role === 'assistant' && message.suggestions && message.suggestions.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-3">
                        {message.suggestions.map((suggestion, index) => (
                          <Button
                            key={index}
                            variant="outline"
                            size="sm"
                            onClick={() => handleSuggestionClick(suggestion)}
                            className="text-xs h-auto py-1 px-2 border-cherry text-cherry hover:bg-cherry hover:text-white"
                          >
                            {suggestion}
                          </Button>
                        ))}
                      </div>
                    )}
                  </div>

                  {message.role === 'user' && (
                    <div className="bg-gray-200 text-gray-700 p-2 rounded-full">
                      <User className="w-4 h-4" />
                    </div>
                  )}
                </div>
              ))}

              <div ref={messagesEndRef} />
            </div>
          </ScrollArea>

          {/* Chat Input */}
          <div className="p-4 border-t border-gray-200">
            {!isConnected && (
              <div className="mb-2">
                <Badge variant="destructive" className="text-xs">
                  Mất kết nối - đang thử kết nối lại...
                </Badge>
              </div>
            )}

            <div className="flex space-x-2">
              <Input
                ref={inputRef}
                type="text"
                placeholder="Nhập câu hỏi của bạn..."
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                disabled={!isConnected}
                className="flex-1 border-gray-300 focus:border-cherry text-sm"
              />
              <Button
                onClick={handleSendMessage}
                disabled={!inputMessage.trim() || !isConnected}
                className="cherry-gradient text-white hover:opacity-90 transition-opacity px-3"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>

            <div className="flex flex-wrap gap-2 mt-3">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleSuggestionClick('Sản phẩm nào bán chạy?')}
                disabled={!isConnected}
                className="text-xs h-auto py-1 px-2 border-cherry text-cherry hover:bg-cherry hover:text-white"
              >
                Sản phẩm nào bán chạy?
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleSuggestionClick('Chính sách giao hàng?')}
                disabled={!isConnected}
                className="text-xs h-auto py-1 px-2 border-cherry text-cherry hover:bg-cherry hover:text-white"
              >
                Chính sách giao hàng?
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Chat Toggle Button */}
      <Button
        onClick={toggleChat}
        className="cherry-gradient p-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 animate-pulse hover:animate-none text-[#f94c64] bg-[#fefdfe]"
        size="lg"
      >
        {isOpen ? (
          <X className="w-6 h-6" />
        ) : (
          <MessageCircle className="w-6 h-6" />
        )}
      </Button>
    </div>
  );
}