import { useState, useEffect, useRef } from 'react';
import { Link } from 'wouter';
import { 
  Mail, Phone, MapPin, Send, Check, AlertCircle,
  Facebook, Instagram, MessageCircle, Music,
  Shield, Award, CheckCircle, CreditCard
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

// Sakura Petal Component for decorative animation
const SakuraPetal = ({ delay = 0, position = { left: '10%' } }: { 
  delay?: number; 
  position?: { left: string; right?: string } 
}) => (
  <div 
    className="sakura-petal-footer absolute pointer-events-none text-white opacity-10"
    style={{ 
      animationDelay: `${delay}s`,
      ...position
    }}
  >
    🌸
  </div>
);

// Newsletter Form Component
const NewsletterForm = () => {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !email.includes('@')) {
      setStatus('error');
      setErrorMessage('Vui lòng nhập email hợp lệ');
      return;
    }

    setStatus('loading');
    
    // Simulate API call
    setTimeout(() => {
      setStatus('success');
      setEmail('');
      setTimeout(() => setStatus('idle'), 3000);
    }, 1500);
  };

  return (
    <form onSubmit={handleSubmit} className="newsletter-form space-y-3">
      <div className="relative">
        <Input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Nhập địa chỉ email của bạn"
          className={`newsletter-input w-full px-4 py-3 bg-white/10 border-2 border-white/20 rounded-lg text-white placeholder:text-white/70 transition-all duration-200 ${
            status === 'error' ? 'border-red-400 shake' : ''
          }`}
          disabled={status === 'loading' || status === 'success'}
        />
        {status === 'success' && (
          <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
            <Check className="w-5 h-5 text-green-400" />
          </div>
        )}
      </div>
      
      <Button
        type="submit"
        disabled={status === 'loading' || status === 'success'}
        className={`newsletter-submit w-full py-3 rounded-lg font-medium transition-all duration-200 ${
          status === 'success' 
            ? 'bg-green-500 hover:bg-green-500' 
            : 'bg-gradient-to-r from-white/20 to-white/10 hover:from-white/30 hover:to-white/20 border border-white/30'
        } text-white`}
      >
        {status === 'loading' && (
          <div className="flex items-center justify-center">
            <div className="newsletter-loading w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
            Đang gửi...
          </div>
        )}
        {status === 'success' && (
          <div className="flex items-center justify-center">
            <Check className="w-4 h-4 mr-2" />
            Đăng ký thành công!
          </div>
        )}
        {(status === 'idle' || status === 'error') && (
          <div className="flex items-center justify-center">
            <Send className="w-4 h-4 mr-2" />
            Đăng ký nhận tin
          </div>
        )}
      </Button>
      
      {status === 'error' && (
        <div className="flex items-center text-red-300 text-sm">
          <AlertCircle className="w-4 h-4 mr-2" />
          {errorMessage}
        </div>
      )}
      
      {status === 'success' && (
        <div className="sakura-success text-green-300 text-sm text-center">
          🌸 Cảm ơn bạn đã đăng ký!
        </div>
      )}
    </form>
  );
};

// Social Media Icons Component
const SocialMediaIcons = () => {
  const socialLinks = [
    { 
      icon: Facebook, 
      href: 'https://facebook.com/japansuki', 
      label: 'Facebook',
      hoverColor: 'hover:bg-blue-600'
    },
    { 
      icon: Instagram, 
      href: 'https://instagram.com/japansuki', 
      label: 'Instagram',
      hoverColor: 'hover:bg-gradient-to-br hover:from-purple-600 hover:to-pink-600'
    },
    { 
      icon: MessageCircle, 
      href: 'https://threads.net/@japansuki', 
      label: 'Threads',
      hoverColor: 'hover:bg-gray-800'
    },
    { 
      icon: Music, 
      href: 'https://tiktok.com/@japansuki', 
      label: 'TikTok',
      hoverColor: 'hover:bg-black'
    }
  ];

  return (
    <div className="social-media-icons flex gap-3 justify-center lg:justify-start">
      {socialLinks.map((social, index) => (
        <a
          key={social.label}
          href={social.href}
          target="_blank"
          rel="noopener noreferrer"
          className={`social-icon group relative w-10 h-10 rounded-full bg-white/10 flex items-center justify-center transition-all duration-300 hover:scale-115 hover:rotate-5 ${social.hoverColor}`}
          aria-label={social.label}
        >
          <social.icon className="w-5 h-5 text-white transition-colors duration-300" />
          <div className="social-circle absolute inset-0 bg-white/20 rounded-full scale-0 group-hover:scale-100 transition-transform duration-300 -z-10"></div>
        </a>
      ))}
    </div>
  );
};

// Trust Signals Component
const TrustSignals = () => {
  const badges = [
    { icon: Shield, label: 'SSL Secure', description: 'Bảo mật SSL' },
    { icon: Award, label: 'JAS Organic', description: 'Chứng nhận hữu cơ' },
    { icon: CheckCircle, label: 'HACCP Safe', description: 'An toàn thực phẩm' },
    { icon: CreditCard, label: 'VN Pay', description: 'Thanh toán an toàn' }
  ];

  return (
    <div className="trust-signals grid grid-cols-2 lg:grid-cols-4 gap-4 pt-6 border-t border-white/20">
      {badges.map((badge, index) => (
        <div key={index} className="trust-badge flex flex-col items-center text-center">
          <badge.icon className="w-6 h-6 text-white/80 mb-1" />
          <span className="text-xs text-white/90 font-medium">{badge.label}</span>
          <span className="text-xs text-white/70">{badge.description}</span>
        </div>
      ))}
    </div>
  );
};

// Main Sakura Footer Component
export default function SakuraFooter() {
  const [isVisible, setIsVisible] = useState(false);
  const footerRef = useRef<HTMLElement>(null);

  // Intersection Observer for reveal animation
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      {
        threshold: 0.1,
        rootMargin: '50px'
      }
    );

    if (footerRef.current) {
      observer.observe(footerRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const quickLinks = [
    { href: '/privacy', label: 'Chính sách bảo mật' },
    { href: '/terms', label: 'Điều khoản dịch vụ' },
    { href: '/faq', label: 'Câu hỏi thường gặp' },
    { href: '/shipping', label: 'Thông tin vận chuyển' },
    { href: '/returns', label: 'Đổi trả & Hoàn tiền' }
  ];

  return (
    <footer 
      ref={footerRef}
      className={`sakura-footer relative min-h-[20vh] bg-gradient-to-br from-sakura-secondary to-sakura-primary overflow-hidden transition-all duration-800 ${
        isVisible ? 'footer-visible' : 'footer-hidden'
      }`}
    >
      {/* Decorative Sakura Petals */}
      <div className="sakura-decoration absolute inset-0 pointer-events-none">
        <SakuraPetal delay={0} position={{ left: '5%' }} />
        <SakuraPetal delay={3} position={{ left: '25%' }} />
        <SakuraPetal delay={6} position={{ left: '45%' }} />
        <SakuraPetal delay={9} position={{ left: '65%' }} />
        <SakuraPetal delay={12} position={{ left: '85%' }} />
      </div>

      {/* Sakura Pattern Border */}
      <div className="sakura-pattern-border absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-white/30 to-transparent"></div>

      <div className="container mx-auto px-6 py-12 relative z-10">
        {/* Main Footer Content */}
        <div className="footer-grid grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {/* Column 1 - Brand Identity */}
          <div className="brand-column space-y-4">
            <div className="brand-logo flex items-center gap-2 mb-4">
              <span className="text-3xl">🌸</span>
              <span className="text-2xl font-bold text-white">JapanSuki</span>
            </div>
            <p className="brand-tagline text-lg font-medium text-white mb-3">
              Trái tim Nhật Bản, bàn ăn thế giới
            </p>
            <p className="brand-description text-sm text-white/80 leading-relaxed">
              Mang đến hương vị đích thực Nhật Bản với những sản phẩm chất lượng cao nhất từ xứ sở hoa anh đào.
            </p>
          </div>

          {/* Column 2 - Quick Links */}
          <div className="links-column space-y-4">
            <h3 className="footer-heading text-lg font-semibold text-white mb-4">
              Liên kết nhanh
            </h3>
            <nav className="footer-nav space-y-2">
              {quickLinks.map((link, index) => (
                <Link key={index} href={link.href}>
                  <div className="footer-link block text-white/90 hover:text-white transition-all duration-200 text-sm group cursor-pointer">
                    <span className="font-medium">{link.label}</span>
                  </div>
                </Link>
              ))}
            </nav>
          </div>

          {/* Column 3 - Contact Information */}
          <div className="contact-column space-y-4">
            <h3 className="footer-heading text-lg font-semibold text-white mb-4">
              Thông tin liên hệ
            </h3>
            <div className="contact-info space-y-3">
              <div className="contact-item flex items-start gap-3">
                <Mail className="w-5 h-5 text-white/80 mt-0.5 flex-shrink-0" />
                <div>
                  <a 
                    href="mailto:support@sakura-mart.jp" 
                    className="footer-link text-white/90 hover:text-white text-sm transition-colors duration-200"
                  >
                    support@sakura-mart.jp
                  </a>
                </div>
              </div>
              
              <div className="contact-item flex items-start gap-3">
                <Phone className="w-5 h-5 text-white/80 mt-0.5 flex-shrink-0" />
                <div>
                  <a 
                    href="tel:+84357566911" 
                    className="footer-link text-white/90 hover:text-white text-sm transition-colors duration-200"
                  >
                    +84 357 566 911
                  </a>
                </div>
              </div>
              
              <div className="contact-item flex items-start gap-3">
                <MapPin className="w-5 h-5 text-white/80 mt-0.5 flex-shrink-0" />
                <div>
                  <address className="text-white/90 text-sm not-italic leading-relaxed">
                    145/11 Le Duc Tho, Go Vap district,<br />
                    Ho Chi Minh City, Vietnam
                  </address>
                </div>
              </div>
            </div>
          </div>

          {/* Column 4 - Newsletter & Social */}
          <div className="newsletter-column space-y-6">
            <div>
              <h3 className="footer-heading text-lg font-semibold text-white mb-4">
                Đăng ký nhận tin
              </h3>
              <p className="text-sm text-white/80 mb-4">
                Nhận tin tức mới nhất về sản phẩm và khuyến mãi
              </p>
              <NewsletterForm />
            </div>
            
            <div>
              <h3 className="footer-heading text-lg font-semibold text-white mb-4">
                Theo dõi chúng tôi
              </h3>
              <SocialMediaIcons />
            </div>
          </div>
        </div>

        {/* Trust Signals */}
        <TrustSignals />

        {/* Bottom Copyright */}
        <div className="footer-bottom mt-8 pt-6 border-t border-white/20 text-center">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-white/80">
              © 2025 JapanSuki. Bảo lưu mọi quyền.
            </p>
            <div className="guarantee-badge flex items-center gap-2 text-sm text-white/90">
              <CheckCircle className="w-4 h-4" />
              <span>Cam kết chất lượng 100%</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}