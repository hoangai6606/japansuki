import { Link } from 'wouter';
import { Phone, Mail, MapPin, Facebook, Instagram, Youtube } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-white text-black mt-16 border-t border-gray-200">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center mb-4">
              <span className="mr-2 text-cherry">🌸</span>
              <h3 className="text-xl font-bold text-black">JapanSuki</h3>
            </div>
            <p className="text-gray-600 mb-4 text-sm leading-relaxed">
              Cửa hàng hàng Nhật nội địa chính hãng, cung cấp những sản phẩm chất lượng cao từ Nhật Bản với giá cả phải chăng.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-500 hover:text-cherry transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-500 hover:text-cherry transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-500 hover:text-cherry transition-colors">
                <Youtube className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4">Liên kết nhanh</h4>
            <ul className="space-y-2 text-sm">
              <li><Link href="/about" className="text-gray-600 hover:text-cherry transition-colors">Về chúng tôi</Link></li>
              <li><Link href="/warranty" className="text-gray-600 hover:text-cherry transition-colors">Chính sách bảo hành</Link></li>
              <li><Link href="/returns" className="text-gray-600 hover:text-cherry transition-colors">Chính sách đổi trả</Link></li>
              <li><Link href="/guide" className="text-gray-600 hover:text-cherry transition-colors">Hướng dẫn mua hàng</Link></li>
            </ul>
          </div>

          {/* Product Categories */}
          <div>
            <h4 className="font-semibold mb-4">Danh mục sản phẩm</h4>
            <ul className="space-y-2 text-sm">
              <li><Link href="/category/thuc-pham" className="text-gray-600 hover:text-cherry transition-colors">Thực phẩm</Link></li>
              <li><Link href="/category/my-pham" className="text-gray-600 hover:text-cherry transition-colors">Mỹ phẩm</Link></li>
              <li><Link href="/category/giat-giu-ve-sinh" className="text-gray-600 hover:text-cherry transition-colors">Giặt giũ vệ sinh</Link></li>
              <li><Link href="/category/nha-bep" className="text-gray-600 hover:text-cherry transition-colors">Nhà bếp</Link></li>
              <li><Link href="/category/me-be" className="text-gray-600 hover:text-cherry transition-colors">Mẹ & bé</Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-semibold mb-4">Thông tin liên hệ</h4>
            <div className="space-y-3 text-sm">
              <div className="flex items-center">
                <Phone className="w-4 h-4 mr-3 text-cherry" />
                <span className="text-gray-600">0384.323.829</span>
              </div>
              <div className="flex items-center">
                <Mail className="w-4 h-4 mr-3 text-cherry" />
                <span className="text-gray-600">info@japansuki.vn</span>
              </div>
              <div className="flex items-start">
                <MapPin className="w-4 h-4 mr-3 text-cherry mt-1" />
                <span className="text-gray-600">123 Đường ABC, Quận 1, TP.HCM</span>
              </div>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-gray-300 mt-8 pt-8 text-center">
          <p className="text-gray-600 text-sm">
            © 2024 JapanSuki. Tất cả quyền được bảo lưu.
          </p>
        </div>
      </div>
    </footer>
  );
}
