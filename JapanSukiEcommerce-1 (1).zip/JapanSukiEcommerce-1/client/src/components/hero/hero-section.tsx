import { useState, useEffect, useRef } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { ShoppingBag, UserPlus } from 'lucide-react';

// Sakura Petal Component
const SakuraPetal = ({ delay = 0 }: { delay?: number }) => (
  <div 
    className="sakura-petal absolute pointer-events-none"
    style={{ 
      animationDelay: `${delay}s`,
      left: `${Math.random() * 100}%`
    }}
  >
    🌸
  </div>
);

// Navigation Component
const Navigation = () => (
  <nav className="flex items-center justify-between w-full max-w-7xl mx-auto px-6 py-4 relative z-20">
    <div className="flex items-center space-x-2">
      <span className="text-2xl">🌸</span>
      <span className="text-xl font-bold text-gray-900">JapanSuki</span>
    </div>
    <div className="hidden md:flex items-center space-x-8">
      <Link href="/" className="text-gray-700 hover:text-sakura-primary transition-colors font-medium">
        Trang chủ
      </Link>
      <Link href="/category/thuc-pham" className="text-gray-700 hover:text-sakura-primary transition-colors font-medium">
        Sản phẩm
      </Link>
      <Link href="/about" className="text-gray-700 hover:text-sakura-primary transition-colors font-medium">
        Về chúng tôi
      </Link>
      <Link href="/contact" className="text-gray-700 hover:text-sakura-primary transition-colors font-medium">
        Liên hệ
      </Link>
    </div>
  </nav>
);

// Typing Effect Hook
const useTypingEffect = (texts: string[], speed = 100, pause = 2000) => {
  const [displayText, setDisplayText] = useState('');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);
  const [showCursor, setShowCursor] = useState(true);

  useEffect(() => {
    const currentText = texts[currentIndex];
    
    const timeout = setTimeout(() => {
      if (!isDeleting) {
        if (displayText.length < currentText.length) {
          setDisplayText(currentText.substring(0, displayText.length + 1));
        } else {
          setTimeout(() => setIsDeleting(true), pause);
        }
      } else {
        if (displayText.length > 0) {
          setDisplayText(currentText.substring(0, displayText.length - 1));
        } else {
          setIsDeleting(false);
          setCurrentIndex((prev) => (prev + 1) % texts.length);
        }
      }
    }, isDeleting ? speed / 2 : speed);

    return () => clearTimeout(timeout);
  }, [displayText, currentIndex, isDeleting, texts, speed, pause]);

  useEffect(() => {
    const cursorInterval = setInterval(() => {
      setShowCursor(prev => !prev);
    }, 500);
    return () => clearInterval(cursorInterval);
  }, []);

  return { displayText, showCursor };
};

// Main Hero Section Component
export default function HeroSection() {
  const [currentHeroIndex, setCurrentHeroIndex] = useState(0);
  const [isReducedMotion, setIsReducedMotion] = useState(false);
  
  const heroMessages = [
    "Hương vị Nhật Bản đến toàn thế giới",
    "Chất lượng cao cấp từ xứ sở hoa anh đào",
    "Cuộc sống ăn uống an toàn, yên tâm"
  ];

  const { displayText, showCursor } = useTypingEffect([
    "Khám phá hàng ngàn sản phẩm chính hãng từ Nhật Bản",
    "Sản phẩm nhập khẩu trực tiếp từ Nhật Bản",
    "Chất lượng cao cấp - Giá cả hợp lý"
  ]);

  // Check for reduced motion preference
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    setIsReducedMotion(mediaQuery.matches);
    
    const handler = (e: MediaQueryListEvent) => setIsReducedMotion(e.matches);
    mediaQuery.addEventListener('change', handler);
    return () => mediaQuery.removeEventListener('change', handler);
  }, []);

  // Hero text rotation
  useEffect(() => {
    if (isReducedMotion) return;
    
    const interval = setInterval(() => {
      setCurrentHeroIndex((prev) => (prev + 1) % heroMessages.length);
    }, 3500);
    
    return () => clearInterval(interval);
  }, [heroMessages.length, isReducedMotion]);

  return (
    <div className="hero-section min-h-screen relative overflow-hidden">
      {/* Animated Background Gradient */}
      <div className="hero-background absolute inset-0" />
      
      {/* Floating Sakura Petals */}
      {!isReducedMotion && (
        <div className="sakura-container absolute inset-0 pointer-events-none">
          {[...Array(12)].map((_, i) => (
            <SakuraPetal key={i} delay={i * 2} />
          ))}
        </div>
      )}

      {/* Subtle Background Pattern */}
      <div className="sakura-pattern absolute inset-0 opacity-5" />

      {/* Header Navigation */}
      <header className="relative z-20">
        <Navigation />
      </header>

      {/* Main Hero Content */}
      <main className="hero-content relative z-10 flex items-center justify-center min-h-[calc(100vh-80px)] px-6">
        <div className="text-center max-w-4xl mx-auto space-y-8">
          {/* Animated Hero Title */}
          <div className="hero-title-container">
            <h1 className="hero-title text-5xl md:text-7xl font-bold text-gray-900 leading-tight mb-4">
              <span className="hero-text-animated block" key={currentHeroIndex}>
                {heroMessages[currentHeroIndex]}
              </span>
            </h1>
          </div>

          {/* Typing Effect Subtitle */}
          <div className="hero-subtitle">
            <p className="text-xl md:text-2xl text-gray-700 min-h-[2em] flex items-center justify-center">
              <span className="typing-text">
                {displayText}
                <span className={`typing-cursor ${showCursor ? 'visible' : 'invisible'}`}>|</span>
              </span>
            </p>
          </div>

          {/* CTA Buttons */}
          <div className="hero-cta flex flex-col sm:flex-row gap-6 justify-center items-center pt-8">
            <Link href="/category/thuc-pham">
              <Button className="cta-button cta-primary group px-8 py-4 text-lg font-semibold rounded-full">
                <ShoppingBag className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform" />
                <span>Bắt đầu mua sắm</span>
              </Button>
            </Link>
            
            <Link href="/register">
              <Button className="cta-button cta-secondary group px-8 py-4 text-lg font-semibold rounded-full">
                <UserPlus className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform" />
                <span>Đăng ký ngay</span>
              </Button>
            </Link>
          </div>

          {/* Trust Indicators */}
          <div className="hero-trust-indicators pt-12">
            <div className="flex flex-wrap justify-center items-center gap-8 text-sm text-gray-600">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                <span>100% Chính hãng từ Nhật Bản</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></span>
                <span>Miễn phí vận chuyển từ 99k</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 bg-purple-500 rounded-full animate-pulse"></span>
                <span>Đổi trả trong 7 ngày</span>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Intersection Observer Trigger for Scroll Animations */}
      <div className="scroll-trigger absolute bottom-10 left-1/2 transform -translate-x-1/2">
        <div className="scroll-indicator animate-bounce">
          <div className="w-6 h-10 border-2 border-gray-400 rounded-full flex justify-center">
            <div className="w-1 h-3 bg-gray-400 rounded-full mt-2 animate-pulse"></div>
          </div>
        </div>
      </div>
    </div>
  );
}