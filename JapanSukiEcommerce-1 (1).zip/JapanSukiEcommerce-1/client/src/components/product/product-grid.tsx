import { useState } from 'react';
import ProductCard from './product-card';
import QuickViewModal from './quick-view-modal';
import type { Product } from '@/lib/types';

interface ProductGridProps {
  products: Product[];
  columns?: 2 | 3 | 4 | 5 | 6;
  showQuickView?: boolean;
}

export default function ProductGrid({ 
  products, 
  columns = 4, 
  showQuickView = true 
}: ProductGridProps) {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const getGridColumns = () => {
    switch (columns) {
      case 2: return 'grid-cols-2';
      case 3: return 'grid-cols-2 md:grid-cols-3';
      case 4: return 'grid-cols-2 md:grid-cols-3 lg:grid-cols-4';
      case 5: return 'grid-cols-2 md:grid-cols-3 lg:grid-cols-5';
      case 6: return 'grid-cols-2 md:grid-cols-3 lg:grid-cols-6';
      default: return 'grid-cols-2 md:grid-cols-3 lg:grid-cols-4';
    }
  };

  const handleQuickView = (product: Product) => {
    setSelectedProduct(product);
  };

  const closeQuickView = () => {
    setSelectedProduct(null);
  };

  if (products.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="text-gray-500 text-lg mb-2">Không có sản phẩm nào</div>
        <div className="text-gray-400 text-sm">Thử tìm kiếm với từ khóa khác hoặc xem các danh mục khác</div>
      </div>
    );
  }

  return (
    <>
      <div className={`grid ${getGridColumns()} gap-4 md:gap-6`}>
        {products.map((product) => (
          <ProductCard
            key={product.id}
            product={product}
            onQuickView={showQuickView ? handleQuickView : undefined}
          />
        ))}
      </div>

      {showQuickView && selectedProduct && (
        <QuickViewModal
          product={selectedProduct}
          isOpen={!!selectedProduct}
          onClose={closeQuickView}
        />
      )}
    </>
  );
}
