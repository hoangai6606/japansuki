import { useState, useEffect, useRef } from 'react';
import { Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { 
  Search, Filter, ShoppingCart, Plus, Minus, Eye, Heart, 
  Star, X, ChevronDown, Grid, List, SlidersHorizontal 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { useCart } from '@/hooks/use-cart';
import { useWishlist } from '@/hooks/use-wishlist';
import type { Product, Category } from '@/lib/types';



// Product Card Component
const ProductCard = ({ product, onAddToCart, onQuickView, isInCart, cartQuantity }: {
  product: any;
  onAddToCart: (id: number, quantity: number) => void;
  onQuickView: (product: any) => void;
  isInCart: boolean;
  cartQuantity: number;
}) => {
  const [quantity, setQuantity] = useState(1);
  const [isHovered, setIsHovered] = useState(false);
  const [showQuantitySelector, setShowQuantitySelector] = useState(isInCart);
  const { toggleItem, isInWishlist } = useWishlist();

  const handleAddToCart = () => {
    onAddToCart(product.id, quantity);
    setShowQuantitySelector(true);
  };

  const handleQuantityChange = (delta: number) => {
    const newQuantity = Math.max(1, Math.min(product.stock, quantity + delta));
    setQuantity(newQuantity);
    if (isInCart) {
      onAddToCart(product.id, newQuantity);
    }
  };

  const getStockStatus = () => {
    if (product.stock > 20) return { color: 'bg-green-500', text: 'Còn hàng' };
    if (product.stock > 5) return { color: 'bg-orange-500', text: 'Sắp hết' };
    return { color: 'bg-red-500', text: 'Ít hàng' };
  };

  const stockStatus = getStockStatus();

  return (
    <Card 
      className="product-card group cursor-pointer"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <CardContent className="p-0">
        {/* Product Image */}
        <div className="product-image-container relative overflow-hidden rounded-t-lg">
          <img
            src={product.image}
            alt={`${product.name} - ${product.nameVi}`}
            className="product-image w-full h-48 object-cover transition-transform duration-300"
            loading="lazy"
          />
          
          {/* Overlay Actions */}
          <div className="product-overlay absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-2">
            <Button
              size="sm"
              variant="secondary"
              className="sakura-button-overlay"
              onClick={() => onQuickView(product)}
            >
              <Eye className="w-4 h-4" />
            </Button>
            <Button
              size="sm"
              variant="secondary"
              className={`sakura-button-overlay ${isInWishlist(product.id) ? 'text-red-500' : ''}`}
              onClick={() => toggleItem(product.id)}
            >
              <Heart className={`w-4 h-4 ${isInWishlist(product.id) ? 'fill-current' : ''}`} />
            </Button>
          </div>

          {/* Stock Status Badge */}
          <div className="absolute top-2 left-2">
            <Badge className={`${stockStatus.color} text-white text-xs px-2 py-1`}>
              {stockStatus.text}
            </Badge>
          </div>

          {/* Origin Badge */}
          {product.origin && (
            <div className="absolute top-2 right-2">
              <Badge variant="secondary" className="bg-white/90 text-gray-700 text-xs px-2 py-1">
                {product.origin}
              </Badge>
            </div>
          )}
        </div>

        {/* Product Info */}
        <div className="p-4">
          <div className="mb-2">
            <h3 className="product-name font-medium text-gray-900 text-sm mb-1 line-clamp-2">
              {product.name}
            </h3>
            {product.shortDescription && (
              <p className="text-gray-600 text-xs line-clamp-1">
                {product.shortDescription}
              </p>
            )}
          </div>

          <div className="mb-3">
            <div className="flex items-center gap-1 mb-1">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-3 h-3 fill-yellow-400 text-yellow-400" />
              ))}
              <span className="text-xs text-gray-500 ml-1">(4.8)</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="product-price text-lg font-bold text-sakura-primary">
                {parseInt(product.price).toLocaleString('vi-VN')}đ
              </span>
              <Badge variant="outline" className="text-xs">
                {product.category}
              </Badge>
            </div>
          </div>

          {/* Add to Cart / Quantity Selector */}
          <div className="add-to-cart-container">
            {!showQuantitySelector ? (
              <Button
                onClick={handleAddToCart}
                className="add-to-cart-button w-full bg-gradient-to-r from-sakura-primary to-sakura-tertiary hover:from-sakura-tertiary hover:to-sakura-primary text-white font-medium py-2 rounded-lg transition-all duration-200"
              >
                <ShoppingCart className="w-4 h-4 mr-2" />
                Thêm vào giỏ
              </Button>
            ) : (
              <div className="quantity-selector flex items-center justify-between bg-sakura-light rounded-lg p-2">
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => handleQuantityChange(-1)}
                  className="h-8 w-8 p-0 hover:bg-sakura-secondary"
                >
                  <Minus className="w-3 h-3" />
                </Button>
                <span className="font-medium text-gray-900 px-3">
                  {isInCart ? cartQuantity : quantity}
                </span>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => handleQuantityChange(1)}
                  className="h-8 w-8 p-0 hover:bg-sakura-secondary"
                >
                  <Plus className="w-3 h-3" />
                </Button>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

// Loading Skeleton Component
const ProductSkeleton = () => (
  <Card className="sakura-shimmer">
    <CardContent className="p-0">
      <div className="h-48 bg-gray-200 rounded-t-lg"></div>
      <div className="p-4 space-y-2">
        <div className="h-4 bg-gray-200 rounded w-3/4"></div>
        <div className="h-3 bg-gray-200 rounded w-1/2"></div>
        <div className="h-6 bg-gray-200 rounded w-1/3"></div>
        <div className="h-10 bg-gray-200 rounded"></div>
      </div>
    </CardContent>
  </Card>
);

// Filter Sidebar Component  
const FilterSidebar = ({ isOpen, onClose, filters, onFiltersChange, categories }: {
  isOpen: boolean;
  onClose: () => void;
  filters: any;
  onFiltersChange: (filters: any) => void;
  categories: Category[];
}) => {
  const categoryOptions = ['Tất cả', ...categories.map(cat => cat.name)];
  const priceRanges = [
    { label: 'Dưới 50.000đ', value: [0, 50000] },
    { label: '50.000đ - 100.000đ', value: [50000, 100000] },
    { label: '100.000đ - 200.000đ', value: [100000, 200000] },
    { label: 'Trên 200.000đ', value: [200000, Infinity] }
  ];

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <div className={`
        filter-sidebar fixed lg:sticky top-0 left-0 h-full lg:h-auto w-80 lg:w-72 
        bg-white border-r border-gray-200 z-50 transform transition-transform duration-300
        ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        <div className="p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Bộ lọc</h3>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={onClose}
              className="lg:hidden"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>

          {/* Categories */}
          <div className="mb-6">
            <h4 className="font-medium text-gray-900 mb-3">Danh mục</h4>
            <div className="space-y-2">
              {categoryOptions.map(category => (
                <label key={category} className="flex items-center">
                  <input
                    type="radio"
                    name="category"
                    checked={filters.category === category}
                    onChange={() => onFiltersChange({ ...filters, category })}
                    className="w-4 h-4 text-sakura-primary focus:ring-sakura-primary"
                  />
                  <span className="ml-2 text-sm text-gray-700">{category}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Price Range */}
          <div className="mb-6">
            <h4 className="font-medium text-gray-900 mb-3">Khoảng giá</h4>
            <div className="space-y-2">
              {priceRanges.map((range, index) => (
                <label key={index} className="flex items-center">
                  <input
                    type="radio"
                    name="priceRange"
                    checked={JSON.stringify(filters.priceRange) === JSON.stringify(range.value)}
                    onChange={() => onFiltersChange({ ...filters, priceRange: range.value })}
                    className="w-4 h-4 text-sakura-primary focus:ring-sakura-primary"
                  />
                  <span className="ml-2 text-sm text-gray-700">{range.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Origin */}
          <div className="mb-6">
            <h4 className="font-medium text-gray-900 mb-3">Xuất xứ</h4>
            <div className="space-y-2">
              {['Tất cả', 'Hokkaido', 'Tokyo', 'Kyoto', 'Osaka'].map(origin => (
                <label key={origin} className="flex items-center">
                  <input
                    type="radio"
                    name="origin"
                    checked={filters.origin === origin}
                    onChange={() => onFiltersChange({ ...filters, origin })}
                    className="w-4 h-4 text-sakura-primary focus:ring-sakura-primary"
                  />
                  <span className="ml-2 text-sm text-gray-700">{origin}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Clear Filters */}
          <Button
            variant="outline"
            onClick={() => onFiltersChange({ category: 'Tất cả', priceRange: null, origin: 'Tất cả' })}
            className="w-full border-sakura-primary text-sakura-primary hover:bg-sakura-light"
          >
            Xóa bộ lọc
          </Button>
        </div>
      </div>
    </>
  );
};

// Quick View Modal Component
const QuickViewModal = ({ product, isOpen, onClose, categories }: {
  product: any;
  isOpen: boolean;
  onClose: () => void;
  categories: Category[];
}) => {
  if (!isOpen || !product) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="quick-view-modal bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-semibold text-gray-900">Xem nhanh sản phẩm</h3>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <img
                src={product.imageUrl || 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=300&h=300&fit=crop&auto=format'}
                alt={product.name}
                className="w-full h-64 object-cover rounded-lg"
              />
            </div>
            <div>
              <h4 className="text-lg font-medium text-gray-900 mb-2">{product.name}</h4>
              {product.description && (
                <p className="text-gray-600 mb-4">{product.description}</p>
              )}
              <div className="space-y-2 text-sm">
                {product.origin && (
                  <p><span className="font-medium">Xuất xứ:</span> {product.origin}</p>
                )}
                <p><span className="font-medium">Danh mục:</span> {categories.find(cat => cat.id === product.categoryId)?.name || 'Khác'}</p>
                <p><span className="font-medium">Tồn kho:</span> {product.stock} sản phẩm</p>
                {product.brand && (
                  <p><span className="font-medium">Thương hiệu:</span> {product.brand}</p>
                )}
              </div>
              <div className="mt-4">
                <span className="text-2xl font-bold text-sakura-primary">
                  {parseInt(product.price).toLocaleString('vi-VN')}đ
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Main Product Section Component
export default function ProductSection() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    category: 'Tất cả',
    priceRange: null,
    origin: 'Tất cả'
  });
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState('name');
  const [isLoading, setIsLoading] = useState(false);
  const [quickViewProduct, setQuickViewProduct] = useState<any>(null);
  
  const { addItem, items } = useCart();
  
  // Fetch products from API
  const { data: allProducts = [], isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });

  // Fetch categories
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });
  
  // Filter and search products
  const filteredProducts = allProducts.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         (product.description && product.description.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesCategory = filters.category === 'Tất cả' || 
                        categories.find(cat => cat.id === product.categoryId)?.name === filters.category;
    
    const matchesPrice = !filters.priceRange || 
                        (parseInt(product.price) >= filters.priceRange[0] && 
                         parseInt(product.price) <= filters.priceRange[1]);
    
    const matchesOrigin = filters.origin === 'Tất cả' || (product.origin && product.origin === filters.origin);
    
    return matchesSearch && matchesCategory && matchesPrice && matchesOrigin;
  });

  const handleAddToCart = async (productId: number, quantity: number) => {
    try {
      await addItem(productId, quantity);
      // Add cart bounce animation
      const cartIcon = document.querySelector('.cart-icon');
      if (cartIcon) {
        cartIcon.classList.add('cart-bounce');
        setTimeout(() => cartIcon.classList.remove('cart-bounce'), 800);
      }
    } catch (error) {
      console.error('Failed to add to cart:', error);
    }
  };

  const getCartQuantity = (productId: number) => {
    const cartItem = items.find(item => item.productId === productId);
    return cartItem ? cartItem.quantity : 0;
  };

  const isInCart = (productId: number) => {
    return items.some(item => item.productId === productId);
  };

  return (
    <div className="product-section">
      {/* Search Bar */}
      <div className="search-container bg-white rounded-2xl shadow-lg p-6 mb-8">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="search-input-container relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              type="text"
              placeholder="Tìm kiếm sản phẩm Nhật Bản..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="search-input pl-10 pr-4 py-3 border-2 border-gray-200 focus:border-sakura-primary focus:ring-0 rounded-xl"
            />
          </div>
          
          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={() => setIsFilterOpen(true)}
              className="lg:hidden border-sakura-primary text-sakura-primary hover:bg-sakura-light"
            >
              <SlidersHorizontal className="w-4 h-4 mr-2" />
              Bộ lọc
            </Button>
            
            <div className="flex items-center gap-2">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('grid')}
                className="p-2"
              >
                <Grid className="w-4 h-4" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('list')}
                className="p-2"
              >
                <List className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="flex gap-8">
        {/* Filter Sidebar */}
        <FilterSidebar
          isOpen={isFilterOpen}
          onClose={() => setIsFilterOpen(false)}
          filters={filters}
          onFiltersChange={setFilters}
          categories={categories}
        />

        {/* Product Grid */}
        <div className="flex-1">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900">
              Sản phẩm Nhật Bản ({filteredProducts.length})
            </h2>
            
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="sort-select px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sakura-primary focus:border-transparent"
            >
              <option value="name">Tên A-Z</option>
              <option value="price-asc">Giá thấp đến cao</option>
              <option value="price-desc">Giá cao đến thấp</option>
              <option value="stock">Tồn kho</option>
            </select>
          </div>

          {/* Loading State */}
          {(isLoading || productsLoading) ? (
            <div className={`product-grid ${
              viewMode === 'grid' 
                ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6'
                : 'space-y-4'
            }`}>
              {[...Array(8)].map((_, index) => (
                <ProductSkeleton key={index} />
              ))}
            </div>
          ) : (
            /* Product Grid */
            <div className={`product-grid ${
              viewMode === 'grid' 
                ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6'
                : 'space-y-4'
            }`}>
              {filteredProducts.map((product, index) => (
                <div
                  key={product.id}
                  className="product-item"
                  style={{ animationDelay: `${index * 60}ms` }}
                >
                  <ProductCard
                    product={product}
                    onAddToCart={handleAddToCart}
                    onQuickView={setQuickViewProduct}
                    isInCart={isInCart(product.id)}
                    cartQuantity={getCartQuantity(product.id)}
                  />
                </div>
              ))}
            </div>
          )}

          {/* No Results */}
          {!isLoading && !productsLoading && filteredProducts.length === 0 && (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">🌸</div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                Không tìm thấy sản phẩm
              </h3>
              <p className="text-gray-600">
                Thử điều chỉnh bộ lọc hoặc từ khóa tìm kiếm
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Quick View Modal */}
      <QuickViewModal
        product={quickViewProduct}
        isOpen={!!quickViewProduct}
        onClose={() => setQuickViewProduct(null)}
        categories={categories}
      />
    </div>
  );
}