import { useState } from 'react';
import { Link } from 'wouter';
import { Heart, ShoppingCart, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useCart } from '@/hooks/use-cart';
import { useWishlist } from '@/hooks/use-wishlist';
import { useToast } from '@/hooks/use-toast';
import type { Product } from '@/lib/types';

interface ProductCardProps {
  product: Product;
  onQuickView?: (product: Product) => void;
}

export default function ProductCard({ product, onQuickView }: ProductCardProps) {
  const [isLoading, setIsLoading] = useState(false);
  const { addItem } = useCart();
  const { toggleItem, isInWishlist } = useWishlist();
  const { toast } = useToast();

  const handleAddToCart = async () => {
    try {
      setIsLoading(true);
      await addItem(product.id);
      toast({
        title: "Đã thêm vào giỏ hàng",
        description: `${product.name} đã được thêm vào giỏ hàng của bạn.`,
      });
    } catch (error) {
      toast({
        title: "Lỗi",
        description: "Không thể thêm sản phẩm vào giỏ hàng. Vui lòng thử lại.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleToggleWishlist = async () => {
    try {
      await toggleItem(product.id);
      toast({
        title: isInWishlist(product.id) ? "Đã xóa khỏi yêu thích" : "Đã thêm vào yêu thích",
        description: `${product.name} ${isInWishlist(product.id) ? 'đã được xóa khỏi' : 'đã được thêm vào'} danh sách yêu thích.`,
      });
    } catch (error) {
      toast({
        title: "Lỗi",
        description: "Không thể cập nhật danh sách yêu thích. Vui lòng thử lại.",
        variant: "destructive",
      });
    }
  };

  const formatPrice = (price: string) => {
    return parseInt(price).toLocaleString('vi-VN');
  };

  return (
    <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow border border-soft-petal overflow-hidden group">
      <div className="relative">
        <Link href={`/product/${product.slug}`}>
          <img
            src={product.imageUrl || 'https://via.placeholder.com/400x300'}
            alt={product.name}
            className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
          />
        </Link>
        
        {/* Wishlist Button */}
        <button
          onClick={handleToggleWishlist}
          className={`absolute top-3 right-3 transition-colors ${
            isInWishlist(product.id) ? 'text-red-500' : 'text-gray-400 hover:text-red-500'
          }`}
        >
          <Heart className={`w-5 h-5 ${isInWishlist(product.id) ? 'fill-current' : ''}`} />
        </button>

        {/* Badges */}
        <div className="absolute bottom-3 left-3 space-y-1">
          {product.isHot && (
            <Badge variant="destructive" className="text-xs">
              Hot
            </Badge>
          )}
          {product.soldCount && product.soldCount > 0 && (
            <Badge variant="secondary" className="text-xs bg-blue-500 text-white">
              Đã bán {product.soldCount} sp
            </Badge>
          )}
        </div>

        {/* Quick View Button */}
        {onQuickView && (
          <button
            onClick={() => onQuickView(product)}
            className="absolute top-3 left-3 bg-white/80 hover:bg-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
          >
            <Eye className="w-4 h-4 text-gray-600" />
          </button>
        )}
      </div>

      <div className="p-4">
        <Link href={`/product/${product.slug}`}>
          <h3 className="font-semibold text-gray-800 mb-2 line-clamp-2 hover:text-cherry transition-colors">
            {product.name}
          </h3>
        </Link>

        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <span className="text-xl font-bold text-cherry">
              {formatPrice(product.price)}₫
            </span>
            {product.originalPrice && (
              <span className="text-sm text-gray-500 line-through">
                {formatPrice(product.originalPrice)}₫
              </span>
            )}
          </div>
          <span className={`text-sm font-medium ${
            product.stock > 0 ? 'text-green-600' : 'text-red-600'
          }`}>
            {product.stock > 0 ? 'Còn hàng' : 'Hết hàng'}
          </span>
        </div>

        <div className="flex space-x-2">
          {onQuickView && (
            <Button
              onClick={() => onQuickView(product)}
              variant="outline"
              size="sm"
              className="flex-1 text-cherry border-cherry hover:bg-cherry hover:text-white"
            >
              Xem nhanh
            </Button>
          )}
          <Button
            onClick={handleAddToCart}
            disabled={isLoading || product.stock === 0}
            size="sm"
            className={`${onQuickView ? '' : 'flex-1'} cherry-gradient text-white hover:opacity-90 transition-opacity`}
          >
            {isLoading ? (
              "Đang thêm..."
            ) : onQuickView ? (
              <ShoppingCart className="w-4 h-4" />
            ) : (
              "Mua ngay"
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
