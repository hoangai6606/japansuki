import { useState, useEffect } from 'react';
import { io, type Socket } from 'socket.io-client';
import { Bell, X, Package, AlertTriangle, Upload, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';

interface Notification {
  id: string;
  type: 'newOrder' | 'lowStock' | 'importStatus' | 'notification';
  message?: string;
  data?: any;
  timestamp: string;
  read: boolean;
}

export default function NotificationCenter() {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const token = localStorage.getItem('adminToken');
    if (!token) return;

    // Initialize socket connection
    const newSocket = io({
      auth: { token },
      path: '/socket.io'
    });

    newSocket.on('connect', () => {
      console.log('Connected to notification service');
      newSocket.emit('subscribe-notifications');
    });

    newSocket.on('newOrder', (data) => {
      const notification: Notification = {
        id: `order-${Date.now()}`,
        type: 'newOrder',
        data: data.data,
        timestamp: data.timestamp,
        read: false
      };
      
      setNotifications(prev => [notification, ...prev]);
      toast({
        title: "Đơn hàng mới",
        description: `Đơn hàng #${data.data.id} vừa được tạo`,
      });
    });

    newSocket.on('lowStock', (data) => {
      const notification: Notification = {
        id: `stock-${Date.now()}`,
        type: 'lowStock',
        data: data.data,
        timestamp: data.timestamp,
        read: false
      };
      
      setNotifications(prev => [notification, ...prev]);
      toast({
        title: "Cảnh báo tồn kho thấp",
        description: `${data.data.name} chỉ còn ${data.data.stock} sản phẩm`,
        variant: "destructive"
      });
    });

    newSocket.on('importStatus', (data) => {
      const notification: Notification = {
        id: `import-${data.jobId}`,
        type: 'importStatus',
        data: data.status,
        timestamp: data.timestamp,
        read: false
      };
      
      setNotifications(prev => [notification, ...prev]);
      
      if (data.status.returnvalue) {
        toast({
          title: "Import hoàn thành",
          description: `${data.status.returnvalue.success} sản phẩm đã được import thành công`,
        });
      }
    });

    newSocket.on('notification', (data) => {
      const notification: Notification = {
        id: `notif-${Date.now()}`,
        type: 'notification',
        message: data.message,
        timestamp: data.timestamp,
        read: false
      };
      
      setNotifications(prev => [notification, ...prev]);
      toast({
        title: "Thông báo",
        description: data.message,
        variant: data.level === 'error' ? 'destructive' : undefined
      });
    });

    setSocket(newSocket);

    return () => {
      newSocket.disconnect();
    };
  }, [toast]);

  const markAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(notif => 
        notif.id === id ? { ...notif, read: true } : notif
      )
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev => 
      prev.map(notif => ({ ...notif, read: true }))
    );
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'newOrder': return <Package className="w-4 h-4 text-blue-500" />;
      case 'lowStock': return <AlertTriangle className="w-4 h-4 text-red-500" />;
      case 'importStatus': return <Upload className="w-4 h-4 text-green-500" />;
      default: return <CheckCircle className="w-4 h-4 text-gray-500" />;
    }
  };

  const formatNotificationMessage = (notification: Notification) => {
    switch (notification.type) {
      case 'newOrder':
        return `Đơn hàng mới #${notification.data?.id || 'N/A'}`;
      case 'lowStock':
        return `Tồn kho thấp: ${notification.data?.name || 'Sản phẩm'} (${notification.data?.stock || 0} còn lại)`;
      case 'importStatus':
        return `Import hoàn thành: ${notification.data?.returnvalue?.success || 0} thành công, ${notification.data?.returnvalue?.failed || 0} thất bại`;
      default:
        return notification.message || 'Thông báo mới';
    }
  };

  return (
    <div className="relative">
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setIsOpen(!isOpen)}
        className="relative"
      >
        <Bell className="w-5 h-5" />
        {unreadCount > 0 && (
          <Badge className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-red-500 text-white text-xs flex items-center justify-center">
            {unreadCount > 99 ? '99+' : unreadCount}
          </Badge>
        )}
      </Button>

      {isOpen && (
        <Card className="absolute right-0 top-full mt-2 w-80 max-h-96 overflow-hidden z-50 shadow-lg">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm">Thông báo</CardTitle>
              <div className="flex items-center space-x-2">
                {unreadCount > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={markAllAsRead}
                    className="text-xs"
                  >
                    Đánh dấu đã đọc
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsOpen(false)}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          
          <CardContent className="p-0 max-h-80 overflow-y-auto">
            {notifications.length === 0 ? (
              <div className="p-4 text-center text-gray-500 text-sm">
                Không có thông báo nào
              </div>
            ) : (
              <div className="space-y-1">
                {notifications.slice(0, 20).map((notification) => (
                  <div
                    key={notification.id}
                    className={`p-3 border-b border-gray-100 cursor-pointer hover:bg-gray-50 ${
                      !notification.read ? 'bg-blue-50' : ''
                    }`}
                    onClick={() => markAsRead(notification.id)}
                  >
                    <div className="flex items-start space-x-2">
                      {getNotificationIcon(notification.type)}
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900 truncate">
                          {formatNotificationMessage(notification)}
                        </p>
                        <p className="text-xs text-gray-500">
                          {new Date(notification.timestamp).toLocaleString('vi-VN')}
                        </p>
                      </div>
                      {!notification.read && (
                        <div className="w-2 h-2 bg-blue-500 rounded-full flex-shrink-0" />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}