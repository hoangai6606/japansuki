
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Upload, Download, FileText } from 'lucide-react';

interface BulkImportProps {
  onSuccess: () => void;
}

export default function BulkImport({ onSuccess }: BulkImportProps) {
  const [importData, setImportData] = useState('');
  const [isImporting, setIsImporting] = useState(false);
  const { toast } = useToast();

  const sampleData = `[
  {
    "name": "Bánh quy socola Nhật Bản",
    "slug": "banh-quy-socola-nhat-ban",
    "description": "Bánh quy socola thơm ngon từ Nhật Bản",
    "shortDescription": "Bánh quy socola giòn tan",
    "price": "45000",
    "originalPrice": "50000",
    "stock": 100,
    "categoryId": 6,
    "brand": "Bourbon",
    "weight": "120g",
    "origin": "Nhật Bản",
    "imageUrl": "https://images.unsplash.com/photo-1558961363-fa8fdf82db35",
    "isFeatured": false,
    "isHot": true
  }
]`;

  const handleImport = async () => {
    try {
      setIsImporting(true);
      
      const products = JSON.parse(importData);
      if (!Array.isArray(products)) {
        throw new Error('Dữ liệu phải là một mảng sản phẩm');
      }

      const response = await fetch('/api/admin/products/bulk-import', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('adminToken')}`
        },
        body: JSON.stringify({ products })
      });

      if (!response.ok) {
        throw new Error('Không thể import sản phẩm');
      }

      const result = await response.json();
      
      toast({
        title: "Import thành công",
        description: `Đã import ${result.imported}/${result.total} sản phẩm`,
      });

      setImportData('');
      onSuccess();
    } catch (error) {
      console.error('Import error:', error);
      toast({
        title: "Lỗi import",
        description: error instanceof Error ? error.message : "Không thể import sản phẩm",
        variant: "destructive",
      });
    } finally {
      setIsImporting(false);
    }
  };

  const downloadSample = () => {
    const blob = new Blob([sampleData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'sample-products.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const exportExistingProducts = async () => {
    try {
      const response = await fetch('/api/products');
      const products = await response.json();
      
      const exportData = products.map((product: any) => ({
        name: product.name,
        slug: product.slug + '-copy',
        description: product.description,
        shortDescription: product.shortDescription,
        price: product.price,
        originalPrice: product.originalPrice,
        stock: product.stock,
        categoryId: product.categoryId,
        brand: product.brand,
        weight: product.weight,
        origin: product.origin,
        imageUrl: product.imageUrl,
        isFeatured: product.isFeatured,
        isHot: product.isHot
      }));

      const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'existing-products.json';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      toast({
        title: "Lỗi",
        description: "Không thể export sản phẩm hiện có",
        variant: "destructive",
      });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Upload className="w-5 h-5 mr-2" />
          Import sản phẩm hàng loạt
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <p className="text-sm text-gray-600">
            Nhập dữ liệu JSON để thêm nhiều sản phẩm cùng lúc
          </p>
          <div className="flex space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={downloadSample}
              className="flex items-center"
            >
              <Download className="w-4 h-4 mr-1" />
              Tải mẫu
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setImportData(sampleData)}
              className="flex items-center"
            >
              <FileText className="w-4 h-4 mr-1" />
              Dùng mẫu
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={exportExistingProducts}
              className="flex items-center"
            >
              <Upload className="w-4 h-4 mr-1" />
              Export hiện có
            </Button>
          </div>
        </div>
        
        <Textarea
          placeholder="Nhập dữ liệu JSON..."
          value={importData}
          onChange={(e) => setImportData(e.target.value)}
          rows={12}
          className="font-mono text-sm"
        />
        
        <div className="flex justify-end space-x-2">
          <Button
            variant="outline"
            onClick={() => setImportData('')}
          >
            Xóa
          </Button>
          <Button
            onClick={handleImport}
            disabled={!importData.trim() || isImporting}
            className="bg-green-600 hover:bg-green-700"
          >
            {isImporting ? 'Đang import...' : 'Import sản phẩm'}
          </Button>
        </div>

        <div className="bg-gray-50 p-4 rounded-lg">
          <h4 className="font-semibold mb-2">Hướng dẫn:</h4>
          <ul className="text-sm text-gray-600 space-y-1">
            <li>• Dữ liệu phải ở định dạng JSON array</li>
            <li>• Trường bắt buộc: name, slug, price, stock, categoryId</li>
            <li>• slug phải là duy nhất cho mỗi sản phẩm</li>
            <li>• categoryId phải tồn tại trong hệ thống</li>
            <li>• price và originalPrice là chuỗi số (VD: "45000")</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
