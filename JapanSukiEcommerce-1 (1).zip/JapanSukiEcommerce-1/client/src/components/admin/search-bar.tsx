import { useState, useRef, useEffect } from 'react';
import { Search, X, Package, Users, ShoppingCart, Tags } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

// Mock Algolia search implementation
interface SearchResult {
  id: string;
  type: 'product' | 'order' | 'user' | 'category';
  title: string;
  subtitle?: string;
  description?: string;
  metadata?: any;
}

interface SearchBarProps {
  onResultSelect?: (result: SearchResult) => void;
  placeholder?: string;
  className?: string;
}

export default function SearchBar({ onResultSelect, placeholder = "Tìm kiếm sản phẩm, đơn hàng, khách hàng...", className }: SearchBarProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Mock search function (replace with actual Algolia search)
  const performSearch = async (searchQuery: string): Promise<SearchResult[]> => {
    if (!searchQuery.trim()) return [];

    setIsLoading(true);
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 300));

      // Mock search results - replace with actual Algolia search
      const mockResults: SearchResult[] = [
        {
          id: '1',
          type: 'product',
          title: 'Bánh quy Bourbon socola',
          subtitle: 'Thực phẩm',
          description: 'Bánh quy hình gấu với nhân socola thơm ngon',
          metadata: { price: 45000, stock: 25 }
        },
        {
          id: '2',
          type: 'order',
          title: 'Đơn hàng #12345',
          subtitle: 'Nguyễn Văn A',
          description: 'Tổng: 350.000đ - Đang xử lý',
          metadata: { total: 350000, status: 'processing' }
        },
        {
          id: '3',
          type: 'user',
          title: 'Nguyễn Văn A',
          subtitle: 'nguyenvana@email.com',
          description: 'Khách hàng thường xuyên - 15 đơn hàng',
          metadata: { orderCount: 15, totalSpent: 2500000 }
        },
        {
          id: '4',
          type: 'category',
          title: 'Thực phẩm',
          subtitle: '45 sản phẩm',
          description: 'Danh mục sản phẩm thực phẩm Nhật Bản',
          metadata: { productCount: 45 }
        }
      ].filter(result => 
        result.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        result.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        result.subtitle?.toLowerCase().includes(searchQuery.toLowerCase())
      );

      return mockResults;
    } catch (error) {
      console.error('Search error:', error);
      return [];
    } finally {
      setIsLoading(false);
    }
  };

  // Debounced search
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (query.trim()) {
        performSearch(query).then(setResults);
      } else {
        setResults([]);
      }
    }, 300);

    return () => clearTimeout(timeoutId);
  }, [query]);

  // Handle click outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getResultIcon = (type: string) => {
    switch (type) {
      case 'product': return <Package className="w-4 h-4 text-blue-500" />;
      case 'order': return <ShoppingCart className="w-4 h-4 text-green-500" />;
      case 'user': return <Users className="w-4 h-4 text-purple-500" />;
      case 'category': return <Tags className="w-4 h-4 text-orange-500" />;
      default: return <Search className="w-4 h-4 text-gray-500" />;
    }
  };

  const getResultTypeBadge = (type: string) => {
    const variants = {
      product: 'bg-blue-100 text-blue-800',
      order: 'bg-green-100 text-green-800',
      user: 'bg-purple-100 text-purple-800',
      category: 'bg-orange-100 text-orange-800'
    };

    const labels = {
      product: 'Sản phẩm',
      order: 'Đơn hàng',
      user: 'Khách hàng',
      category: 'Danh mục'
    };

    return (
      <Badge variant="secondary" className={variants[type as keyof typeof variants]}>
        {labels[type as keyof typeof labels]}
      </Badge>
    );
  };

  const handleResultClick = (result: SearchResult) => {
    setQuery(result.title);
    setIsOpen(false);
    onResultSelect?.(result);
  };

  const clearSearch = () => {
    setQuery('');
    setResults([]);
    setIsOpen(false);
    inputRef.current?.focus();
  };

  return (
    <div ref={searchRef} className={`relative ${className}`}>
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
        <Input
          ref={inputRef}
          type="text"
          placeholder={placeholder}
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          className="pl-10 pr-10"
        />
        {query && (
          <Button
            variant="ghost"
            size="sm"
            onClick={clearSearch}
            className="absolute right-1 top-1/2 transform -translate-y-1/2 h-8 w-8 p-0"
          >
            <X className="w-4 h-4" />
          </Button>
        )}
      </div>

      {isOpen && (query || results.length > 0) && (
        <Card className="absolute top-full left-0 right-0 mt-1 z-50 shadow-lg max-h-96 overflow-hidden">
          <CardContent className="p-0">
            {isLoading ? (
              <div className="p-4 text-center">
                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-500 mx-auto"></div>
                <p className="text-sm text-gray-500 mt-2">Đang tìm kiếm...</p>
              </div>
            ) : results.length > 0 ? (
              <div className="max-h-80 overflow-y-auto">
                {results.map((result) => (
                  <div
                    key={`${result.type}-${result.id}`}
                    onClick={() => handleResultClick(result)}
                    className="p-4 hover:bg-gray-50 cursor-pointer border-b border-gray-100 last:border-b-0"
                  >
                    <div className="flex items-start space-x-3">
                      {getResultIcon(result.type)}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <p className="text-sm font-medium text-gray-900 truncate">
                            {result.title}
                          </p>
                          {getResultTypeBadge(result.type)}
                        </div>
                        {result.subtitle && (
                          <p className="text-xs text-gray-600 mb-1">
                            {result.subtitle}
                          </p>
                        )}
                        {result.description && (
                          <p className="text-xs text-gray-500 line-clamp-2">
                            {result.description}
                          </p>
                        )}
                        {result.metadata && (
                          <div className="flex items-center space-x-2 mt-2">
                            {result.type === 'product' && (
                              <>
                                <span className="text-xs text-green-600 font-medium">
                                  {new Intl.NumberFormat('vi-VN', {
                                    style: 'currency',
                                    currency: 'VND'
                                  }).format(result.metadata.price)}
                                </span>
                                <span className="text-xs text-gray-500">
                                  Kho: {result.metadata.stock}
                                </span>
                              </>
                            )}
                            {result.type === 'order' && (
                              <>
                                <span className="text-xs text-green-600 font-medium">
                                  {new Intl.NumberFormat('vi-VN', {
                                    style: 'currency',
                                    currency: 'VND'
                                  }).format(result.metadata.total)}
                                </span>
                                <Badge variant="outline" className="text-xs">
                                  {result.metadata.status}
                                </Badge>
                              </>
                            )}
                            {result.type === 'user' && (
                              <span className="text-xs text-gray-500">
                                {result.metadata.orderCount} đơn hàng
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : query ? (
              <div className="p-4 text-center">
                <Search className="w-8 h-8 text-gray-300 mx-auto mb-2" />
                <p className="text-sm text-gray-500">
                  Không tìm thấy kết quả cho "{query}"
                </p>
              </div>
            ) : null}
          </CardContent>
        </Card>
      )}
    </div>
  );
}